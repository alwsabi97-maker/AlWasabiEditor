package com.alwsabi.editor.ui.components

import android.graphics.Color
import android.graphics.Typeface
import android.text.Html
import android.text.Layout
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.AlignmentSpan
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.text.style.UnderlineSpan
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatAlignLeft
import androidx.compose.material.icons.filled.FormatAlignRight
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatUnderlined
import androidx.compose.material.icons.filled.FormatColorText
import androidx.compose.material.icons.filled.TextDecrease
import androidx.compose.material.icons.filled.TextIncrease
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

/**
 * مربع نص مستقل في ترويسة الاختبار.
 * html يحمل التنسيق حتى يبقى كل مربع مستقلاً عن بقية الصفحة.
 */
data class ExamHeaderBox(
    val id: String,
    val html: String
)

fun defaultExamHeaderBoxes(): List<ExamHeaderBox> = listOf(
    ExamHeaderBox(
        "right",
        "<div dir=\"rtl\"><b>الصف : ثالث الثانوي (علمي)</b><br/><b>المادة : الكيمياء</b><br/>التاريخ :<br/><b>الزمن : ساعتان</b><br/><b>الفترة : الأولى</b></div>"
    ),
    ExamHeaderBox(
        "middle",
        "<div dir=\"rtl\"><b>امتحان نهاية الفصل الدراسي الأول</b><br/>من العام الدراسي 1448هـ</div>"
    ),
    ExamHeaderBox(
        "left",
        "<div dir=\"rtl\"><b>الجمهورية اليمنية</b><br/>وزارة التربية والتعليم<br/>مكتب التربية والتعليم محافظة ........<br/>مكتب التربية والتعليم بمديرية ........<br/>مدرسة ........</div>"
    )
)

private fun htmlToSpannable(html: String): Spannable {
    @Suppress("DEPRECATION")
    val spanned = if (android.os.Build.VERSION.SDK_INT >= 24) {
        Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY)
    } else {
        Html.fromHtml(html)
    }
    return SpannableStringBuilder(spanned)
}

@Composable
fun ExamHeaderBoxes(
    boxes: List<ExamHeaderBox>,
    onEdit: (ExamHeaderBox) -> Unit,
    modifier: Modifier = Modifier
) {
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl
    ) {
        Row(
            modifier = modifier
                .fillMaxWidth()
                .height(128.dp)
                .background(androidx.compose.ui.graphics.Color.White)
                .border(1.dp, androidx.compose.ui.graphics.Color.Black),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val right = boxes.firstOrNull { it.id == "right" } ?: ExamHeaderBox("right", "")
            val middle = boxes.firstOrNull { it.id == "middle" } ?: ExamHeaderBox("middle", "")
            val left = boxes.firstOrNull { it.id == "left" } ?: ExamHeaderBox("left", "")

            HeaderPreviewBox(right, onEdit, Modifier.weight(1f))
            HeaderPreviewBox(middle, onEdit, Modifier.weight(1f))
            HeaderPreviewBox(left, onEdit, Modifier.weight(1f))
        }
    }
}

@Composable
private fun HeaderPreviewBox(
    box: ExamHeaderBox,
    onEdit: (ExamHeaderBox) -> Unit,
    modifier: Modifier
) {
    AndroidView(
        modifier = modifier
            .height(126.dp)
            .clickable { onEdit(box) }
            .padding(5.dp),
        factory = { context ->
            TextView(context).apply {
                setTextIsSelectable(false)
                gravity = Gravity.CENTER
                textDirection = android.view.View.TEXT_DIRECTION_RTL
                layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
                setTextColor(Color.BLACK)
                textSize = 12f
                setPadding(6, 4, 6, 4)
                setBackgroundColor(Color.TRANSPARENT)
            }
        },
        update = { view ->
            view.text = htmlToSpannable(box.html)
        }
    )
}

@Composable
fun HeaderBoxEditDialog(
    box: ExamHeaderBox,
    onDismiss: () -> Unit,
    onSave: (ExamHeaderBox) -> Unit
) {
    val context = LocalContext.current
    var working by remember(box.id, box.html) { mutableStateOf(htmlToSpannable(box.html)) }
    var fontSize by remember(box.id) { mutableIntStateOf(16) }
    var showColors by remember { mutableStateOf(false) }
    var showFonts by remember { mutableStateOf(false) }
    var editRef by remember { mutableStateOf<EditText?>(null) }

    fun selection(): Pair<Int, Int> {
        val edit = editRef ?: return 0 to 0
        return edit.selectionStart.coerceAtLeast(0) to edit.selectionEnd.coerceAtLeast(0)
    }

    fun applySpan(action: (SpannableStringBuilder, Int, Int) -> Unit) {
        val edit = editRef ?: return
        val start = edit.selectionStart.coerceAtLeast(0)
        val end = edit.selectionEnd.coerceAtLeast(0)
        if (start == end) return
        val text = SpannableStringBuilder(edit.text)
        action(text, start, end)
        working = text
        edit.setText(text, TextView.BufferType.SPANNABLE)
        edit.setSelection(start, end)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعديل مربع الترويسة") },
        text = {
            Column(Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    IconButton(onClick = {
                        applySpan { text, s, e ->
                            val spans = text.getSpans(s, e, StyleSpan::class.java)
                            if (spans.any { it.style == Typeface.BOLD }) {
                                spans.filter { it.style == Typeface.BOLD }.forEach(text::removeSpan)
                            } else text.setSpan(StyleSpan(Typeface.BOLD), s, e, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                        }
                    }) { Icon(Icons.Default.FormatBold, "عريض") }

                    IconButton(onClick = {
                        applySpan { text, s, e ->
                            val spans = text.getSpans(s, e, StyleSpan::class.java)
                            if (spans.any { it.style == Typeface.ITALIC }) {
                                spans.filter { it.style == Typeface.ITALIC }.forEach(text::removeSpan)
                            } else text.setSpan(StyleSpan(Typeface.ITALIC), s, e, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                        }
                    }) { Icon(Icons.Default.FormatItalic, "مائل") }

                    IconButton(onClick = {
                        applySpan { text, s, e ->
                            if (text.getSpans(s, e, UnderlineSpan::class.java).isNotEmpty()) {
                                text.getSpans(s, e, UnderlineSpan::class.java).forEach(text::removeSpan)
                            } else text.setSpan(UnderlineSpan(), s, e, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                        }
                    }) { Icon(Icons.Default.FormatUnderlined, "تسطير") }

                    IconButton(onClick = {
                        applySpan { text, s, e ->
                            text.getSpans(s, e, AlignmentSpan.Standard::class.java).forEach(text::removeSpan)
                            text.setSpan(AlignmentSpan.Standard(Layout.Alignment.ALIGN_NORMAL), s, e, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                        }
                    }) { Icon(Icons.Default.FormatAlignRight, "يمين") }

                    IconButton(onClick = {
                        applySpan { text, s, e ->
                            text.getSpans(s, e, AlignmentSpan.Standard::class.java).forEach(text::removeSpan)
                            text.setSpan(AlignmentSpan.Standard(Layout.Alignment.ALIGN_CENTER), s, e, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                        }
                    }) { Icon(Icons.Default.FormatAlignCenter, "وسط") }

                    IconButton(onClick = {
                        applySpan { text, s, e ->
                            text.getSpans(s, e, AlignmentSpan.Standard::class.java).forEach(text::removeSpan)
                            text.setSpan(AlignmentSpan.Standard(Layout.Alignment.ALIGN_OPPOSITE), s, e, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                        }
                    }) { Icon(Icons.Default.FormatAlignLeft, "يسار") }

                    IconButton(onClick = {
                        fontSize = (fontSize + 1).coerceAtMost(48)
                        applySpan { text, s, e ->
                            text.getSpans(s, e, RelativeSizeSpan::class.java).forEach(text::removeSpan)
                            text.setSpan(RelativeSizeSpan(fontSize / 16f), s, e, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                        }
                    }) { Icon(Icons.Default.TextIncrease, "تكبير") }

                    IconButton(onClick = {
                        fontSize = (fontSize - 1).coerceAtLeast(8)
                        applySpan { text, s, e ->
                            text.getSpans(s, e, RelativeSizeSpan::class.java).forEach(text::removeSpan)
                            text.setSpan(RelativeSizeSpan(fontSize / 16f), s, e, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                        }
                    }) { Icon(Icons.Default.TextDecrease, "تصغير") }

                    IconButton(onClick = { showFonts = true }) {
                        Text("A", style = MaterialTheme.typography.titleMedium)
                    }

                    IconButton(onClick = { showColors = true }) {
                        Icon(Icons.Default.FormatColorText, "لون النص")
                    }
                }

                androidx.compose.material3.DropdownMenu(
                    expanded = showFonts,
                    onDismissRequest = { showFonts = false }
                ) {
                    listOf("sans-serif", "serif", "monospace", "sans-serif-condensed").forEach { family ->
                        androidx.compose.material3.DropdownMenuItem(
                            text = { Text(family) },
                            onClick = {
                                applySpan { text, s, e ->
                                    text.getSpans(s, e, TypefaceSpan::class.java).forEach(text::removeSpan)
                                    text.setSpan(TypefaceSpan(family), s, e, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                                }
                                showFonts = false
                            }
                        )
                    }
                }

                Text("حجم الخط: $fontSize", style = MaterialTheme.typography.bodySmall)

                Spacer(Modifier.height(4.dp))

                AndroidView(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(250.dp)
                        .border(1.dp, MaterialTheme.colorScheme.outline),
                    factory = {
                        EditText(context).apply {
                            setText(working, TextView.BufferType.SPANNABLE)
                            textSize = fontSize.toFloat()
                            gravity = Gravity.TOP or Gravity.START
                            textDirection = android.view.View.TEXT_DIRECTION_RTL
                            layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
                            isSingleLine = false
                            setPadding(12, 12, 12, 12)
                            setBackgroundColor(Color.WHITE)
                            editRef = this
                        }
                    },
                    update = { edit ->
                        if (edit.text.toString() != working.toString()) {
                            edit.setText(working, TextView.BufferType.SPANNABLE)
                        }
                        edit.textSize = fontSize.toFloat()
                        editRef = edit
                    }
                )

                Spacer(Modifier.height(6.dp))
                Text("حدّد النص داخل هذا المربع ثم استخدم أدوات التنسيق أعلاه.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            Button(onClick = {
                val text = editRef?.text ?: working
                val html = android.text.Html.toHtml(text, android.text.Html.TO_HTML_PARAGRAPH_LINES_CONSECUTIVE)
                onSave(box.copy(html = html))
            }) { Text("حفظ") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )

    if (showColors) {
        ColorPickerDialog(
            title = "لون نص المربع",
            onColorSelected = { color ->
                applySpan { text, s, e ->
                    text.getSpans(s, e, ForegroundColorSpan::class.java).forEach(text::removeSpan)
                    text.setSpan(ForegroundColorSpan(color), s, e, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                showColors = false
            },
            onDismiss = { showColors = false }
        )
    }
}
