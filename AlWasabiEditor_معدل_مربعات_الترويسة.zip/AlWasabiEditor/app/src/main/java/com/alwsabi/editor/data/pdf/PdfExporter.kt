package com.alwsabi.editor.data.pdf

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.text.Html
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * يصدّر الاختبار إلى PDF مع ترويسة مكوّنة من ثلاثة مربعات نص مستقلة.
 * كل مربع يحتفظ بتنسيقه (عريض/مائل/تسطير/لون/محاذاة) عبر HTML.
 */
class PdfExporter(private val context: Context) {

    private val pageWidthPx = 595
    private val pageHeightPx = 842
    private val marginPx = 40
    private val headerTop = 30
    private val headerBottom = 155
    private val contentTop = 170

    suspend fun exportToPdf(
        text: CharSequence,
        fontSizePx: Float,
        isRtl: Boolean,
        outputFileName: String,
        headerBoxes: Map<String, String> = emptyMap()
    ): Result<File> =
        withContext(Dispatchers.Default) {
            try {
                val document = PdfDocument()
                val textPaint = TextPaint().apply {
                    isAntiAlias = true
                    textSize = fontSizePx
                    color = android.graphics.Color.BLACK
                }

                val contentWidth = pageWidthPx - (marginPx * 2)
                val fullLayout = StaticLayout.Builder
                    .obtain(text, 0, text.length, textPaint, contentWidth)
                    .setAlignment(if (isRtl) Layout.Alignment.ALIGN_NORMAL else Layout.Alignment.ALIGN_NORMAL)
                    .setLineSpacing(1.1f, 1.15f)
                    .setIncludePad(false)
                    .build()

                var currentLine = 0
                var pageNumber = 1
                val totalLines = fullLayout.lineCount

                // حتى المستند الفارغ يحصل على صفحة واحدة.
                val pageCountTarget = if (totalLines == 0) 1 else Int.MAX_VALUE

                while (currentLine < totalLines || (pageNumber == 1 && pageCountTarget == 1)) {
                    val pageInfo = PdfDocument.PageInfo.Builder(
                        pageWidthPx, pageHeightPx, pageNumber
                    ).create()
                    val page = document.startPage(pageInfo)
                    val canvas = page.canvas

                    drawBorder(canvas)
                    drawHeaderBoxes(canvas, headerBoxes, textPaint)

                    canvas.save()
                    canvas.translate(marginPx.toFloat(), contentTop.toFloat())

                    val availableHeight = pageHeightPx - contentTop - marginPx
                    var linesOnPage = 0

                    while (currentLine + linesOnPage < totalLines) {
                        val index = currentLine + linesOnPage
                        val lineTop = fullLayout.getLineTop(index)
                        val lineBottom = fullLayout.getLineBottom(index)
                        if (lineBottom - lineTop > availableHeight && linesOnPage == 0) {
                            linesOnPage = 1
                            break
                        }
                        if (lineBottom > availableHeight) break
                        linesOnPage++
                    }

                    if (linesOnPage > 0) {
                        val startOffset = fullLayout.getLineStart(currentLine)
                        val endLineIndex = (currentLine + linesOnPage - 1).coerceAtMost(totalLines - 1)
                        val endOffset = fullLayout.getLineEnd(endLineIndex)
                        val pageText = text.subSequence(startOffset, endOffset)
                        val pageLayout = StaticLayout.Builder
                            .obtain(pageText, 0, pageText.length, textPaint, contentWidth)
                            .setAlignment(if (isRtl) Layout.Alignment.ALIGN_NORMAL else Layout.Alignment.ALIGN_NORMAL)
                            .setLineSpacing(1.1f, 1.15f)
                            .setIncludePad(false)
                            .build()
                        pageLayout.draw(canvas)
                        currentLine += linesOnPage
                    }

                    canvas.restore()
                    document.finishPage(page)
                    pageNumber++

                    if (pageNumber > 500) break
                    if (totalLines == 0) break
                }

                val outDir = File(context.cacheDir, "shared").apply { mkdirs() }
                val outFile = File(outDir, outputFileName)
                FileOutputStream(outFile).use { document.writeTo(it) }
                document.close()

                Result.success(outFile)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    private fun drawBorder(canvas: android.graphics.Canvas) {
        val borderPaint = Paint().apply {
            style = Paint.Style.STROKE
            color = android.graphics.Color.DKGRAY
            strokeWidth = 1.5f
            isAntiAlias = true
        }
        val outerInset = 14f
        val innerInset = 20f
        canvas.drawRect(
            outerInset, outerInset,
            pageWidthPx - outerInset, pageHeightPx - outerInset,
            borderPaint
        )
        canvas.drawRect(
            innerInset, innerInset,
            pageWidthPx - innerInset, pageHeightPx - innerInset,
            borderPaint
        )
    }

    private fun drawHeaderBoxes(
        canvas: android.graphics.Canvas,
        headerBoxes: Map<String, String>,
        basePaint: TextPaint
    ) {
        val left = 38f
        val right = (pageWidthPx - 38f)
        val width = (right - left) / 3f
        val top = headerTop.toFloat()
        val bottom = headerBottom.toFloat()

        val borderPaint = Paint().apply {
            style = Paint.Style.STROKE
            color = android.graphics.Color.DKGRAY
            strokeWidth = 1.2f
            isAntiAlias = true
        }

        // من اليمين إلى اليسار: الصف | عنوان الامتحان | بيانات الوزارة.
        val rightBox = android.graphics.RectF(right - width, top, right, bottom)
        val middleBox = android.graphics.RectF(right - (width * 2), top, right - width, bottom)
        val leftBox = android.graphics.RectF(left, top, right - (width * 2), bottom)

        canvas.drawRect(rightBox, borderPaint)
        canvas.drawRect(middleBox, borderPaint)
        canvas.drawRect(leftBox, borderPaint)

        drawHeaderText(canvas, headerBoxes["right"], rightBox, basePaint)
        drawHeaderText(canvas, headerBoxes["middle"], middleBox, basePaint)
        drawHeaderText(canvas, headerBoxes["left"], leftBox, basePaint)
    }

    private fun drawHeaderText(
        canvas: android.graphics.Canvas,
        html: String?,
        rect: android.graphics.RectF,
        basePaint: TextPaint
    ) {
        if (html.isNullOrBlank()) return

        @Suppress("DEPRECATION")
        val spanned = if (android.os.Build.VERSION.SDK_INT >= 24) {
            Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY)
        } else {
            Html.fromHtml(html)
        }

        val paint = TextPaint(basePaint).apply {
            textSize = 11.5f
            color = android.graphics.Color.BLACK
        }

        val width = (rect.width() - 10f).toInt().coerceAtLeast(20)
        val layout = StaticLayout.Builder
            .obtain(spanned, 0, spanned.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(1.0f, 1.0f)
            .setIncludePad(true)
            .build()

        canvas.save()
        val x = rect.left + 5f
        val y = rect.top + ((rect.height() - layout.height) / 2f).coerceAtLeast(4f)
        canvas.translate(x, y)
        layout.draw(canvas)
        canvas.restore()
    }
}
