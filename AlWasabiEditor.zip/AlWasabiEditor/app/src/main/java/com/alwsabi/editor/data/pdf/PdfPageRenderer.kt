package com.alwsabi.editor.data.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * يعرض صفحات ملف PDF كصور Bitmap باستخدام android.graphics.pdf.PdfRenderer
 * وهو API أصلي مستقر بدون مكتبات خارجية.
 */
class PdfPageRenderer(private val context: Context) {

    private var fileDescriptor: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null

    suspend fun open(uri: Uri): Result<Int> = withContext(Dispatchers.IO) {
        try {
            close()
            val pfd = context.contentResolver.openFileDescriptor(uri, "r")
                ?: return@withContext Result.failure(IllegalStateException("تعذر فتح الملف"))
            fileDescriptor = pfd
            val r = PdfRenderer(pfd)
            renderer = r
            Result.success(r.pageCount)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun renderPage(index: Int, targetWidthPx: Int): Result<Bitmap> = withContext(Dispatchers.IO) {
        try {
            val r = renderer ?: return@withContext Result.failure(IllegalStateException("لم يتم فتح الملف"))
            if (index < 0 || index >= r.pageCount) {
                return@withContext Result.failure(IllegalArgumentException("رقم صفحة غير صحيح"))
            }
            r.openPage(index).use { page ->
                val scale = targetWidthPx.toFloat() / page.width.toFloat()
                val height = (page.height * scale).toInt().coerceAtLeast(1)
                val bitmap = Bitmap.createBitmap(targetWidthPx, height, Bitmap.Config.ARGB_8888)
                bitmap.eraseColor(android.graphics.Color.WHITE)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                Result.success(bitmap)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun close() {
        try {
            renderer?.close()
        } catch (_: Exception) {
        }
        try {
            fileDescriptor?.close()
        } catch (_: Exception) {
        }
        renderer = null
        fileDescriptor = null
    }
}
