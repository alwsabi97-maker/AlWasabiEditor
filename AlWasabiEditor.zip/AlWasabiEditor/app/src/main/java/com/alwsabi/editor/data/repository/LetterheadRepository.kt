package com.alwsabi.editor.data.repository

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.letterheadDataStore by preferencesDataStore(name = "alwasabi_letterhead")

/** بيانات المدرسة الثابتة (لا تتغيّر من اختبار لآخر). */
data class FixedLetterhead(
    val governorate: String = "",
    val directorate: String = "",
    val schoolName: String = "",
    val isSet: Boolean = false
)

/**
 * يخزّن بيانات الترويسة الثابتة (محافظة/مديرية/مدرسة) لمرة واحدة، لتُدرج
 * تلقائيًا في أي مستند جديد بدون الحاجة لإعادة كتابتها كل مرة.
 */
class LetterheadRepository(private val context: Context) {

    private object Keys {
        val GOVERNORATE = stringPreferencesKey("lh_governorate")
        val DIRECTORATE = stringPreferencesKey("lh_directorate")
        val SCHOOL = stringPreferencesKey("lh_school")
        val IS_SET = stringPreferencesKey("lh_is_set")
    }

    val fixedLetterheadFlow: Flow<FixedLetterhead> = context.letterheadDataStore.data.map { prefs ->
        FixedLetterhead(
            governorate = prefs[Keys.GOVERNORATE] ?: "",
            directorate = prefs[Keys.DIRECTORATE] ?: "",
            schoolName = prefs[Keys.SCHOOL] ?: "",
            isSet = prefs[Keys.IS_SET] == "true"
        )
    }

    suspend fun getFixedLetterheadOnce(): FixedLetterhead = fixedLetterheadFlow.first()

    suspend fun saveFixedLetterhead(governorate: String, directorate: String, schoolName: String) {
        context.letterheadDataStore.edit { prefs ->
            prefs[Keys.GOVERNORATE] = governorate
            prefs[Keys.DIRECTORATE] = directorate
            prefs[Keys.SCHOOL] = schoolName
            prefs[Keys.IS_SET] = "true"
        }
    }

    suspend fun clearFixedLetterhead() {
        context.letterheadDataStore.edit { prefs ->
            prefs[Keys.IS_SET] = "false"
        }
    }
}
