package com.alwsabi.editor.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.alwsabi.editor.data.model.AppSettings
import com.alwsabi.editor.ui.screens.about.AboutScreen
import com.alwsabi.editor.ui.screens.editor.EditorScreen
import com.alwsabi.editor.ui.screens.home.HomeScreen
import com.alwsabi.editor.ui.screens.pdf.PdfViewerScreen
import com.alwsabi.editor.ui.screens.settings.SettingsScreen
import com.alwsabi.editor.ui.screens.settings.SettingsViewModel

/**
 * رسم بياني تنقل مركزي واحد يربط كل الشاشات ببعضها بأمان (Type-Safe إلى حد كبير
 * عبر sealed class Screen)، مع تمرير Uri الملف المفتوح كمعامل مُرمّز.
 */
@Composable
fun AlWasabiNavGraph() {
    val navController = rememberNavController()
    val settingsViewModel: SettingsViewModel = viewModel()
    val appSettings by settingsViewModel.settings.collectAsState()

    NavHost(navController = navController, startDestination = Screen.Home.route) {

        composable(Screen.Home.route) {
            HomeScreen(
                onNewDocument = {
                    navController.navigate(Screen.Editor.buildRoute())
                },
                onFileOpened = { uriString ->
                    val encoded = Uri.encode(uriString)
                    navController.navigate(Screen.Editor.buildRoute(encoded))
                },
                onOpenRecent = { uriString ->
                    val encoded = Uri.encode(uriString)
                    navController.navigate(Screen.Editor.buildRoute(encoded))
                },
                onSettings = { navController.navigate(Screen.Settings.route) },
                onAbout = { navController.navigate(Screen.About.route) }
            )
        }

        composable(
            route = Screen.Editor.route,
            arguments = listOf(
                navArgument(Screen.Editor.argUri) {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                }
            )
        ) { backStackEntry ->
            val encodedUri = backStackEntry.arguments?.getString(Screen.Editor.argUri)
            val decodedUri = encodedUri?.let { Uri.decode(it) }
            EditorScreen(
                documentUriToOpen = decodedUri,
                appSettings = appSettings,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(onNavigateBack = { navController.popBackStack() })
        }

        composable(Screen.About.route) {
            AboutScreen(onNavigateBack = { navController.popBackStack() })
        }

        composable(
            route = Screen.PdfViewer.route,
            arguments = listOf(navArgument(Screen.PdfViewer.argUri) { type = NavType.StringType })
        ) { backStackEntry ->
            val encodedUri = backStackEntry.arguments?.getString(Screen.PdfViewer.argUri).orEmpty()
            PdfViewerScreen(
                pdfUri = Uri.decode(encodedUri),
                onNavigateBack = { navController.popBackStack() },
                onShare = { }
            )
        }
    }
}
