package com.alwsabi.editor.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke

/**
 * يرسم إطارًا زخرفيًا (خط متعرج/Zigzag) حول حواف صفحة المستند، يعطي
 * إحساس "ورقة اختبار رسمية" — مرسوم بالكامل بكود أصلي (Canvas)
 * وليس صورة منسوخة من أي مصدر آخر.
 */
@Composable
fun DecorativePageBorder(
    modifier: Modifier = Modifier,
    color: Color,
    zigzagSize: Float = 10f,
    strokeWidth: Float = 2f
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val stroke = Stroke(width = strokeWidth)

        fun drawZigzagLine(start: Offset, end: Offset, horizontal: Boolean) {
            val path = androidx.compose.ui.graphics.Path()
            path.moveTo(start.x, start.y)
            if (horizontal) {
                var x = start.x
                var up = true
                while (x < end.x) {
                    val nextX = (x + zigzagSize).coerceAtMost(end.x)
                    val y = if (up) start.y - zigzagSize / 2 else start.y + zigzagSize / 2
                    path.lineTo(nextX, y)
                    x = nextX
                    up = !up
                }
            } else {
                var y = start.y
                var right = true
                while (y < end.y) {
                    val nextY = (y + zigzagSize).coerceAtMost(end.y)
                    val x = if (right) start.x + zigzagSize / 2 else start.x - zigzagSize / 2
                    path.lineTo(x, nextY)
                    y = nextY
                    right = !right
                }
            }
            drawPath(path, color = color, style = stroke)
        }

        val margin = 12f
        drawZigzagLine(Offset(margin, margin), Offset(size.width - margin, margin), horizontal = true)
        drawZigzagLine(Offset(margin, size.height - margin), Offset(size.width - margin, size.height - margin), horizontal = true)
        drawZigzagLine(Offset(margin, margin), Offset(margin, size.height - margin), horizontal = false)
        drawZigzagLine(Offset(size.width - margin, margin), Offset(size.width - margin, size.height - margin), horizontal = false)
    }
}
