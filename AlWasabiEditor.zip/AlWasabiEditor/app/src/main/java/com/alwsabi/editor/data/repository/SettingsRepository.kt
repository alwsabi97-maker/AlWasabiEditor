package com.alwsabi.editor.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.alwsabi.editor.data.model.AppSettings
import com.alwsabi.editor.data.model.EditorFontFamily
import com.alwsabi.editor.data.model.TextDirectionSetting
import com.alwsabi.editor.data.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "alwasabi_settings")

/**
 * يخزّن ويقرأ تفضيلات المستخدم (المظهر، حجم الخط، نوع الخط، الاتجاه، الحفظ التلقائي)
 * باستخدام Jetpack DataStore بدلاً من SharedPreferences القديمة.
 */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val FONT_SIZE = intPreferencesKey("default_font_size")
        val TEXT_DIRECTION = stringPreferencesKey("text_direction")
        val AUTO_SAVE = booleanPreferencesKey("auto_save_enabled")
        val FONT_FAMILY = stringPreferencesKey("editor_font_family")
    }

    val settingsFlow: Flow<AppSettings> = context.settingsDataStore.data.map { prefs ->
        AppSettings(
            themeMode = prefs[Keys.THEME_MODE]?.let {
                runCatching { ThemeMode.valueOf(it) }.getOrDefault(ThemeMode.SYSTEM)
            } ?: ThemeMode.SYSTEM,
            defaultFontSize = prefs[Keys.FONT_SIZE] ?: 18,
            textDirection = prefs[Keys.TEXT_DIRECTION]?.let {
                runCatching { TextDirectionSetting.valueOf(it) }.getOrDefault(TextDirectionSetting.RTL)
            } ?: TextDirectionSetting.RTL,
            autoSaveEnabled = prefs[Keys.AUTO_SAVE] ?: true,
            fontFamily = prefs[Keys.FONT_FAMILY]?.let {
                runCatching { EditorFontFamily.valueOf(it) }.getOrDefault(EditorFontFamily.DEFAULT)
            } ?: EditorFontFamily.DEFAULT
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.settingsDataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setDefaultFontSize(size: Int) {
        context.settingsDataStore.edit { it[Keys.FONT_SIZE] = size }
    }

    suspend fun setTextDirection(direction: TextDirectionSetting) {
        context.settingsDataStore.edit { it[Keys.TEXT_DIRECTION] = direction.name }
    }

    suspend fun setAutoSaveEnabled(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.AUTO_SAVE] = enabled }
    }

    suspend fun setFontFamily(family: EditorFontFamily) {
        context.settingsDataStore.edit { it[Keys.FONT_FAMILY] = family.name }
    }
}
