package com.alwsabi.editor.data.model

/** أوضاع المظهر المتاحة في التطبيق. */
enum class ThemeMode {
    LIGHT, DARK, SYSTEM
}

/** اتجاه النص الافتراضي في المحرر. */
enum class TextDirectionSetting {
    RTL, LTR
}

/** إعدادات التطبيق الكاملة كما يتم تخزينها في DataStore. */
data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val defaultFontSize: Int = 18,
    val textDirection: TextDirectionSetting = TextDirectionSetting.RTL,
    val autoSaveEnabled: Boolean = true
)
