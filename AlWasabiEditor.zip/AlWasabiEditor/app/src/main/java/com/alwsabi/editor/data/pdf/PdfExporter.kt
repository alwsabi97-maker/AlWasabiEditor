package com.alwsabi.editor.data.pdf

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * يصدّر نص المستند (بما فيه بيانات الاختبار، لأنها جزء طبيعي من النص
 * نفسه) إلى ملف PDF بصيغة A4 حقيقية، مع إطار بسيط حول كل صفحة.
 * التقسيم بين الصفحات يُحسب بالنسبة لبداية كل صفحة على حدة (وليس بداية
 * المستند كامل) — هذا التصحيح الأساسي لمنع تضخّم عدد الصفحات.
 */
class PdfExporter(private val context: Context) {

    private val pageWidthPx = 595  // A4 عند 72dpi
    private val pageHeightPx = 842
    private val marginPx = 40

    suspend fun exportToPdf(text: CharSequence, fontSizePx: Float, isRtl: Boolean, outputFileName: String): Result<File> =
        withContext(Dispatchers.Default) {
            try {
                val document = PdfDocument()
                val textPaint = TextPaint().apply {
                    isAntiAlias = true
                    textSize = fontSizePx
                    color = android.graphics.Color.BLACK
                }

                val contentWidth = pageWidthPx - (marginPx * 2)
                val fullLayout = StaticLayout.Builder
                    .obtain(text, 0, text.length, textPaint, contentWidth)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setLineSpacing(1.1f, 1.15f)
                    .setIncludePad(false)
                    .build()

                var currentLine = 0
                var pageNumber = 1
                val totalLines = fullLayout.lineCount

                while (currentLine < totalLines || pageNumber == 1) {
                    val pageInfo = PdfDocument.PageInfo.Builder(pageWidthPx, pageHeightPx, pageNumber).create()
                    val page = document.startPage(pageInfo)
                    val canvas = page.canvas

                    val borderPaint = Paint().apply {
                        style = Paint.Style.STROKE
                        color = android.graphics.Color.DKGRAY
                        strokeWidth = 1.5f
                        isAntiAlias = true
                    }
                    canvas.drawRect(14f, 14f, pageWidthPx - 14f, pageHeightPx - 14f, borderPaint)
                    canvas.drawRect(20f, 20f, pageWidthPx - 20f, pageHeightPx - 20f, borderPaint)

                    canvas.translate(marginPx.toFloat(), marginPx.toFloat())

                    val availableHeight = pageHeightPx - (marginPx * 2)
                    var linesOnPage = 0
                    val pageStartTop = if (currentLine < totalLines) fullLayout.getLineTop(currentLine) else 0

                    while (currentLine + linesOnPage < totalLines) {
                        val index = currentLine + linesOnPage
                        val lineBottomRelative = fullLayout.getLineBottom(index) - pageStartTop
                        if (lineBottomRelative > availableHeight) {
                            if (linesOnPage == 0) linesOnPage = 1
                            break
                        }
                        linesOnPage++
                    }

                    if (linesOnPage > 0) {
                        val startOffset = fullLayout.getLineStart(currentLine)
                        val endLineIndex = (currentLine + linesOnPage - 1).coerceAtMost(totalLines - 1)
                        val endOffset = fullLayout.getLineEnd(endLineIndex)
                        val pageText = text.subSequence(startOffset, endOffset)
                        val pageLayout = StaticLayout.Builder
                            .obtain(pageText, 0, pageText.length, textPaint, contentWidth)
                            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                            .setLineSpacing(1.1f, 1.15f)
                            .setIncludePad(false)
                            .build()
                        pageLayout.draw(canvas)
                        currentLine += linesOnPage
                    }

                    document.finishPage(page)
                    pageNumber++
                    if (pageNumber > 500) break
                    if (totalLines == 0) break
                }

                val outDir = File(context.cacheDir, "shared").apply { mkdirs() }
                val outFile = File(outDir, outputFileName)
                FileOutputStream(outFile).use { document.writeTo(it) }
                document.close()

                Result.success(outFile)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
}
