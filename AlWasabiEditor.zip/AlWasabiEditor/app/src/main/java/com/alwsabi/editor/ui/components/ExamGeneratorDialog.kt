package com.alwsabi.editor.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.alwsabi.editor.R

enum class ExamQuestionType { TRUE_FALSE, MCQ, IMAGE_ONLY }

private val questionCountOptions = listOf(1, 2, 3, 4, 5, 10, 15, 20, 25, 30)

/** عنصر محتوى واحد سيُدرج بالمستند: إما نص أو صورة، بالترتيب. */
sealed class ExamInsertOp {
    data class Txt(val text: String) : ExamInsertOp()
    data class Img(val uri: Uri, val maxWidthPx: Int = 500) : ExamInsertOp()
}

/** أحجام جاهزة للصور المُدرجة (صغير/متوسط/كبير) بالبكسل. */
enum class ImageSizeOption(val label: String, val maxWidthPx: Int) {
    SMALL("صغير", 300),
    MEDIUM("متوسط", 500),
    LARGE("كبير", 800)
}

private class ChoiceDraft {
    var text by mutableStateOf("")
    var imageUri by mutableStateOf<Uri?>(null)
    var imageSize by mutableStateOf(ImageSizeOption.MEDIUM)
}

private class QuestionDraft {
    var text by mutableStateOf("")
    var imageUri by mutableStateOf<Uri?>(null)
    var imageSize by mutableStateOf(ImageSizeOption.MEDIUM)
    val choices = listOf(ChoiceDraft(), ChoiceDraft(), ChoiceDraft(), ChoiceDraft())
}

/**
 * محرر أسئلة كامل الشاشة: يختار المستخدم النوع والعدد أولاً، ثم يكتب كل
 * فقرة على حدة (نص/صورة للسؤال نفسه، ونص/صورة لكل خيار من الخيارات الأربعة
 * في حالة الاختيار من متعدد)، وأخيرًا تُدرج كل الفقرات بالترتيب داخل المستند.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExamGeneratorDialog(
    onDismiss: () -> Unit,
    onInsertSequence: (List<ExamInsertOp>) -> Unit
) {
    var step by remember { mutableStateOf(1) }
    var selectedType by remember { mutableStateOf(ExamQuestionType.TRUE_FALSE) }
    var selectedCount by remember { mutableStateOf(3) }
    var customCountText by remember { mutableStateOf("") }
    var useCustomCount by remember { mutableStateOf(false) }
    var generateAnswerSheet by remember { mutableStateOf(false) }
    val drafts = remember { mutableStateListOf<QuestionDraft>() }

    var subjectText by remember { mutableStateOf("") }
    var gradeText by remember { mutableStateOf("") }
    var semesterText by remember { mutableStateOf("") }
    var yearText by remember { mutableStateOf("") }
    var examDateText by remember { mutableStateOf("") }
    var durationText by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                TopAppBar(title = { Text(stringResource(R.string.exam_generator_title)) })
            }
        ) { padding ->
            if (step == 1) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(16.dp)
                        .verticalScroll(androidx.compose.foundation.rememberScrollState())
                        .navigationBarsPadding()
                ) {
                    Text("بيانات الاختبار", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = subjectText, onValueChange = { subjectText = it },
                        label = { Text("المادة") }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp), singleLine = true
                    )
                    OutlinedTextField(
                        value = gradeText, onValueChange = { gradeText = it },
                        label = { Text("الصف") }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp), singleLine = true
                    )
                    Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                        OutlinedTextField(
                            value = semesterText, onValueChange = { semesterText = it },
                            label = { Text("الفصل الدراسي") }, modifier = Modifier.weight(1f), singleLine = true
                        )
                        Spacer(Modifier.padding(horizontal = 4.dp))
                        OutlinedTextField(
                            value = yearText, onValueChange = { yearText = it },
                            label = { Text("العام الدراسي") }, modifier = Modifier.weight(1f), singleLine = true
                        )
                    }

                    Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                        OutlinedTextField(
                            value = examDateText, onValueChange = { examDateText = it },
                            label = { Text("تاريخ الامتحان") }, modifier = Modifier.weight(1f), singleLine = true
                        )
                        Spacer(Modifier.padding(horizontal = 4.dp))
                        OutlinedTextField(
                            value = durationText, onValueChange = { durationText = it },
                            label = { Text("الزمن") }, modifier = Modifier.weight(1f), singleLine = true
                        )
                    }

                    Spacer(Modifier.height(16.dp))
                    Text(stringResource(R.string.exam_generator_type_label), style = MaterialTheme.typography.titleMedium)
                    QuestionTypeRow(
                        label = stringResource(R.string.exam_type_true_false),
                        selected = selectedType == ExamQuestionType.TRUE_FALSE,
                        onClick = { selectedType = ExamQuestionType.TRUE_FALSE }
                    )
                    QuestionTypeRow(
                        label = stringResource(R.string.exam_type_mcq),
                        selected = selectedType == ExamQuestionType.MCQ,
                        onClick = { selectedType = ExamQuestionType.MCQ }
                    )
                    QuestionTypeRow(
                        label = "سؤال صورة مستقل",
                        selected = selectedType == ExamQuestionType.IMAGE_ONLY,
                        onClick = { selectedType = ExamQuestionType.IMAGE_ONLY }
                    )

                    Spacer(Modifier.height(16.dp))
                    Text(stringResource(R.string.exam_generator_count_label), style = MaterialTheme.typography.titleMedium)
                    Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                        questionCountOptions.take(5).forEach { count ->
                            CountChip(count, selectedCount == count && !useCustomCount) {
                                selectedCount = count; useCustomCount = false
                            }
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                        questionCountOptions.drop(5).forEach { count ->
                            CountChip(count, selectedCount == count && !useCustomCount) {
                                selectedCount = count; useCustomCount = false
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = useCustomCount, onClick = { useCustomCount = true })
                        Text(stringResource(R.string.exam_generator_other))
                        Spacer(Modifier.padding(horizontal = 4.dp))
                        if (useCustomCount) {
                            OutlinedTextField(
                                value = customCountText,
                                onValueChange = { customCountText = it.filter { c -> c.isDigit() } },
                                modifier = Modifier.height(56.dp)
                            )
                        }
                    }

                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = generateAnswerSheet, onCheckedChange = { generateAnswerSheet = it })
                        Text("توليد بطاقة إجابة تلقائيًا")
                    }

                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val count = if (useCustomCount) {
                                customCountText.toIntOrNull()?.coerceIn(1, 200) ?: 1
                            } else selectedCount
                            drafts.clear()
                            repeat(count) { drafts.add(QuestionDraft()) }
                            step = 2
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("التالي: كتابة الفقرات")
                    }
                    TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.exam_generator_cancel))
                    }
                }
            } else {
                Column(modifier = Modifier.fillMaxSize().padding(padding)) {
                    LazyColumn(
                        modifier = Modifier.weight(1f).padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(drafts.size) { index ->
                            QuestionDraftCard(
                                index = index,
                                type = selectedType,
                                draft = drafts[index]
                            )
                        }
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(12.dp)
                    ) {
                        TextButton(onClick = { step = 1 }, modifier = Modifier.weight(1f)) {
                            Text("رجوع")
                        }
                        Button(
                            onClick = {
                                val header = buildHeaderBlock(subjectText, gradeText, semesterText, yearText, examDateText, durationText)
                                val ops = mutableListOf<ExamInsertOp>()
                                if (header.isNotBlank()) ops.add(ExamInsertOp.Txt(header))
                                ops.addAll(buildInsertSequence(selectedType, drafts))
                                if (generateAnswerSheet) ops.add(ExamInsertOp.Txt(buildAnswerSheet(selectedType, drafts.size)))
                                onInsertSequence(ops)
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(stringResource(R.string.exam_generator_insert))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuestionTypeRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label)
    }
}

@Composable
private fun CountChip(count: Int, selected: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .padding(end = 6.dp)
            .clickable(onClick = onClick),
        colors = androidx.compose.material3.CardDefaults.cardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(10.dp)
    ) {
        Text(
            count.toString(),
            modifier = Modifier
                .padding(horizontal = 10.dp, vertical = 8.dp),
            color = if (selected) androidx.compose.ui.graphics.Color.White else MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun QuestionDraftCard(index: Int, type: ExamQuestionType, draft: QuestionDraft) {
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) draft.imageUri = uri
    }

    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text("الفقرة ${index + 1}", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))

            if (type != ExamQuestionType.IMAGE_ONLY) {
                OutlinedTextField(
                    value = draft.text,
                    onValueChange = { draft.text = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("نص السؤال") }
                )
            }

            Spacer(Modifier.height(6.dp))
            AttachImageRow(
                hasImage = draft.imageUri != null,
                label = if (type == ExamQuestionType.IMAGE_ONLY) "اختر صورة السؤال" else "إضافة صورة للسؤال (اختياري)",
                selectedSize = draft.imageSize,
                onPick = { imagePicker.launch("image/*") },
                onRemove = { draft.imageUri = null },
                onSizeSelected = { draft.imageSize = it }
            )

            if (type == ExamQuestionType.MCQ) {
                Spacer(Modifier.height(10.dp))
                val letters = listOf("أ", "ب", "ج", "د")
                draft.choices.forEachIndexed { i, choice ->
                    ChoiceEditorRow(letter = letters[i], choice = choice)
                    Spacer(Modifier.height(6.dp))
                }
            }
        }
    }
}

@Composable
private fun ChoiceEditorRow(letter: String, choice: ChoiceDraft) {
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) choice.imageUri = uri
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        OutlinedTextField(
            value = choice.text,
            onValueChange = { choice.text = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("خيار ($letter)") },
            singleLine = true
        )
        Spacer(Modifier.height(4.dp))
        AttachImageRow(
            hasImage = choice.imageUri != null,
            label = "صورة لهذا الخيار (اختياري)",
            selectedSize = choice.imageSize,
            onPick = { imagePicker.launch("image/*") },
            onRemove = { choice.imageUri = null },
            onSizeSelected = { choice.imageSize = it }
        )
    }
}

@Composable
private fun AttachImageRow(
    hasImage: Boolean,
    label: String,
    selectedSize: ImageSizeOption,
    onPick: () -> Unit,
    onRemove: () -> Unit,
    onSizeSelected: (ImageSizeOption) -> Unit
) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (hasImage) {
                Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text(" تم إرفاق صورة", style = MaterialTheme.typography.bodyMedium)
                IconButton(onClick = onRemove) {
                    Icon(Icons.Default.Close, contentDescription = "إزالة الصورة")
                }
            } else {
                IconButton(onClick = onPick) {
                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = label)
                }
                Text(label, style = MaterialTheme.typography.bodyMedium)
            }
        }
        if (hasImage) {
            Row(
                modifier = Modifier.padding(start = 8.dp, top = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("حجم الصورة: ", style = MaterialTheme.typography.bodySmall)
                ImageSizeOption.entries.forEach { option ->
                    val selected = option == selectedSize
                    Card(
                        modifier = Modifier
                            .padding(end = 4.dp)
                            .clickable { onSizeSelected(option) },
                        shape = RoundedCornerShape(8.dp),
                        colors = androidx.compose.material3.CardDefaults.cardColors(
                            containerColor = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Text(
                            option.label,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (selected) androidx.compose.ui.graphics.Color.White else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

/** يبني كتلة عنوان الاختبار (المادة/الصف/الفصل/العام/التاريخ/الزمن) إن وُجدت بياناتها. */
private fun buildHeaderBlock(
    subject: String, grade: String, semester: String, year: String,
    examDate: String = "", duration: String = ""
): String {
    if (subject.isBlank() && grade.isBlank() && semester.isBlank() && year.isBlank() &&
        examDate.isBlank() && duration.isBlank()
    ) return ""
    val builder = StringBuilder()
    builder.append("اختبار مادة: ${subject.ifBlank { "..." }}\n")
    builder.append("الصف: ${grade.ifBlank { "..." }}    الفصل الدراسي: ${semester.ifBlank { "..." }}    العام الدراسي: ${year.ifBlank { "..." }}\n")
    if (examDate.isNotBlank() || duration.isNotBlank()) {
        builder.append("تاريخ الامتحان: ${examDate.ifBlank { "..." }}    الزمن: ${duration.ifBlank { "..." }}\n")
    }
    builder.append("--------------------------------------------------\n\n")
    return builder.toString()
}

/** يولّد بطاقة إجابة نصية بسيطة (جدول أرقام + خانات اختيار) حسب نوع الأسئلة وعددها. */
private fun buildAnswerSheet(type: ExamQuestionType, count: Int): String {
    val builder = StringBuilder()
    builder.append("\n\n===== بطاقة الإجابة =====\n\n")
    when (type) {
        ExamQuestionType.TRUE_FALSE -> {
            for (i in 1..count) {
                builder.append("$i.   ( صح )      ( خطأ )\n")
            }
        }
        ExamQuestionType.MCQ -> {
            for (i in 1..count) {
                builder.append("$i.   ( أ )   ( ب )   ( ج )   ( د )\n")
            }
        }
        ExamQuestionType.IMAGE_ONLY -> {
            for (i in 1..count) {
                builder.append("$i.   ..........................\n")
            }
        }
    }
    return builder.toString()
}

/** يحوّل مسودات الأسئلة إلى قائمة عمليات إدراج مرتّبة (نص/صورة) تُطبَّق بالتتابع. */
private fun buildInsertSequence(type: ExamQuestionType, drafts: List<QuestionDraft>): List<ExamInsertOp> {
    val ops = mutableListOf<ExamInsertOp>()
    val letters = listOf("أ", "ب", "ج", "د")

    val boxLine = "―".repeat(40)

    drafts.forEachIndexed { index, draft ->
        val number = index + 1
        when (type) {
            ExamQuestionType.TRUE_FALSE -> {
                // كل فقرة داخل "صندوق" (خط فاصل أعلى وأسفل)، والإجابة ( صح / خطأ ) بنهاية الفقرة
                ops.add(ExamInsertOp.Txt("$boxLine\n"))
                ops.add(ExamInsertOp.Txt("$number.  ${draft.text}\n"))
                draft.imageUri?.let { ops.add(ExamInsertOp.Img(it, draft.imageSize.maxWidthPx)) }
                ops.add(ExamInsertOp.Txt("الإجابة:     (   صح   )        (   خطأ   )\n"))
                ops.add(ExamInsertOp.Txt("$boxLine\n\n"))
            }
            ExamQuestionType.MCQ -> {
                ops.add(ExamInsertOp.Txt("$boxLine\n"))
                ops.add(ExamInsertOp.Txt("$number.  ${draft.text}\n"))
                draft.imageUri?.let { ops.add(ExamInsertOp.Img(it, draft.imageSize.maxWidthPx)) }
                draft.choices.forEachIndexed { i, choice ->
                    ops.add(ExamInsertOp.Txt("     ${letters[i]}) ${choice.text}\n"))
                    choice.imageUri?.let { ops.add(ExamInsertOp.Img(it, choice.imageSize.maxWidthPx)) }
                }
                ops.add(ExamInsertOp.Txt("الإجابة:  (   أ   )  (   ب   )  (   ج   )  (   د   )\n"))
                ops.add(ExamInsertOp.Txt("$boxLine\n\n"))
            }
            ExamQuestionType.IMAGE_ONLY -> {
                ops.add(ExamInsertOp.Txt("$boxLine\n$number.\n"))
                draft.imageUri?.let { ops.add(ExamInsertOp.Img(it, draft.imageSize.maxWidthPx)) }
                ops.add(ExamInsertOp.Txt("$boxLine\n\n"))
            }
        }
    }
    return ops
}
