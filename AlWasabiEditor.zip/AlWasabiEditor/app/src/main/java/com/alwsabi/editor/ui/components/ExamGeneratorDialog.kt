package com.alwsabi.editor.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

enum class ExamQuestionType { TRUE_FALSE, MCQ }

private val questionCountOptions = listOf(1, 2, 3, 4, 5, 10, 15, 20, 25, 30)

private class QuestionDraft {
    var text by mutableStateOf("")
    var choiceA by mutableStateOf("")
    var choiceB by mutableStateOf("")
    var choiceC by mutableStateOf("")
    var choiceD by mutableStateOf("")
}

/**
 * مولّد أسئلة مبسّط: يختار النوع والعدد، يكتب كل فقرة في حقل مستقل، وأخيرًا
 * يُدرج كل الأسئلة (مع بطاقة إجابة اختيارية) داخل المستند. بدون أي تعقيد
 * إضافي (لا صور، لا أحجام متغيرة) تفاديًا لمصادر الأخطاء السابقة.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExamGeneratorDialog(
    onDismiss: () -> Unit,
    onInsert: (String) -> Unit
) {
    var step by remember { mutableStateOf(1) }
    var selectedType by remember { mutableStateOf(ExamQuestionType.TRUE_FALSE) }
    var selectedCount by remember { mutableStateOf(5) }
    var customCountText by remember { mutableStateOf("") }
    var useCustomCount by remember { mutableStateOf(false) }
    var generateAnswerSheet by remember { mutableStateOf(true) }
    val drafts = remember { mutableStateListOf<QuestionDraft>() }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = { TopAppBar(title = { Text("إنشاء أسئلة اختبار") }) }
        ) { padding ->
            if (step == 1) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                        .navigationBarsPadding()
                ) {
                    Text("نوع السؤال", style = MaterialTheme.typography.titleMedium)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = selectedType == ExamQuestionType.TRUE_FALSE, onClick = { selectedType = ExamQuestionType.TRUE_FALSE })
                        Text("صح / خطأ")
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = selectedType == ExamQuestionType.MCQ, onClick = { selectedType = ExamQuestionType.MCQ })
                        Text("اختيار من متعدد")
                    }

                    Text("عدد الأسئلة", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
                    Row { questionCountOptions.take(5).forEach { c -> CountChip(c, !useCustomCount && selectedCount == c) { selectedCount = c; useCustomCount = false } } }
                    Row { questionCountOptions.drop(5).forEach { c -> CountChip(c, !useCustomCount && selectedCount == c) { selectedCount = c; useCustomCount = false } } }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = useCustomCount, onClick = { useCustomCount = true })
                        Text("غير ذلك")
                        if (useCustomCount) {
                            OutlinedTextField(
                                value = customCountText,
                                onValueChange = { customCountText = it.filter { c -> c.isDigit() } },
                                modifier = Modifier.padding(start = 8.dp)
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 12.dp)) {
                        Checkbox(checked = generateAnswerSheet, onCheckedChange = { generateAnswerSheet = it })
                        Text("توليد بطاقة إجابة تلقائيًا")
                    }

                    Button(
                        onClick = {
                            val count = if (useCustomCount) customCountText.toIntOrNull()?.coerceIn(1, 200) ?: 1 else selectedCount
                            drafts.clear()
                            repeat(count) { drafts.add(QuestionDraft()) }
                            step = 2
                        },
                        modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
                    ) { Text("التالي: كتابة الفقرات") }
                    TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("إلغاء") }
                }
            } else {
                Column(modifier = Modifier.fillMaxSize().padding(padding)) {
                    LazyColumn(
                        modifier = Modifier.weight(1f).padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(drafts.size) { index ->
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("السؤال ${index + 1}", style = MaterialTheme.typography.titleMedium)
                                    OutlinedTextField(
                                        value = drafts[index].text,
                                        onValueChange = { drafts[index].text = it },
                                        label = { Text("نص السؤال") },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    if (selectedType == ExamQuestionType.MCQ) {
                                        OutlinedTextField(drafts[index].choiceA, { drafts[index].choiceA = it }, label = { Text("أ") }, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(drafts[index].choiceB, { drafts[index].choiceB = it }, label = { Text("ب") }, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(drafts[index].choiceC, { drafts[index].choiceC = it }, label = { Text("ج") }, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(drafts[index].choiceD, { drafts[index].choiceD = it }, label = { Text("د") }, modifier = Modifier.fillMaxWidth())
                                    }
                                }
                            }
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(12.dp)) {
                        TextButton(onClick = { step = 1 }, modifier = Modifier.weight(1f)) { Text("رجوع") }
                        Button(
                            onClick = { onInsert(buildExamText(selectedType, drafts, generateAnswerSheet)) },
                            modifier = Modifier.weight(1f)
                        ) { Text("إدراج في المستند") }
                    }
                }
            }
        }
    }
}

@Composable
private fun CountChip(count: Int, selected: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.padding(end = 6.dp).clickable(onClick = onClick),
        colors = androidx.compose.material3.CardDefaults.cardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Text(count.toString(), modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            color = if (selected) androidx.compose.ui.graphics.Color.White else MaterialTheme.colorScheme.onSurface)
    }
}

private fun buildExamText(type: ExamQuestionType, drafts: List<QuestionDraft>, withAnswerSheet: Boolean): String {
    val boxLine = "―".repeat(40)
    val body = StringBuilder()
    drafts.forEachIndexed { i, d ->
        val n = i + 1
        body.append("$boxLine\n")
        body.append("$n.  ${d.text}\n")
        if (type == ExamQuestionType.TRUE_FALSE) {
            body.append("الإجابة:     (   صح   )        (   خطأ   )\n")
        } else {
            body.append("     أ) ${d.choiceA}\n")
            body.append("     ب) ${d.choiceB}\n")
            body.append("     ج) ${d.choiceC}\n")
            body.append("     د) ${d.choiceD}\n")
            body.append("الإجابة:  (   أ   )  (   ب   )  (   ج   )  (   د   )\n")
        }
        body.append("$boxLine\n\n")
    }
    if (withAnswerSheet) {
        body.append("\n===== بطاقة الإجابة =====\n\n")
        drafts.forEachIndexed { i, _ ->
            val n = i + 1
            body.append(
                if (type == ExamQuestionType.TRUE_FALSE) "$n.   ( صح )      ( خطأ )\n"
                else "$n.   ( أ )   ( ب )   ( ج )   ( د )\n"
            )
        }
    }
    return body.toString()
}
