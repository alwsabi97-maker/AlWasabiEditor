package com.alwsabi.editor.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.alwsabi.editor.R

enum class ExamQuestionType { TRUE_FALSE, MCQ }

private val questionCountOptions = listOf(1, 2, 3, 4, 5, 10, 15, 20, 25, 30)

/**
 * صندوق حواري لإنشاء أسئلة اختبار جاهزة (صح/خطأ أو اختيار من متعدد)
 * وإدراجها مباشرة داخل نص المستند الحالي بصيغة منسّقة وجاهزة للطباعة.
 */
@Composable
fun ExamGeneratorDialog(
    onDismiss: () -> Unit,
    onInsert: (String) -> Unit
) {
    var selectedType by remember { mutableStateOf(ExamQuestionType.TRUE_FALSE) }
    var selectedCount by remember { mutableStateOf(3) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.exam_generator_title)) },
        text = {
            Column {
                Text(stringResource(R.string.exam_generator_type_label))
                Row(modifier = Modifier.padding(vertical = 4.dp)) {
                    RadioButton(
                        selected = selectedType == ExamQuestionType.TRUE_FALSE,
                        onClick = { selectedType = ExamQuestionType.TRUE_FALSE }
                    )
                    Text(
                        stringResource(R.string.exam_type_true_false),
                        modifier = Modifier.padding(top = 12.dp, end = 12.dp)
                    )
                    RadioButton(
                        selected = selectedType == ExamQuestionType.MCQ,
                        onClick = { selectedType = ExamQuestionType.MCQ }
                    )
                    Text(
                        stringResource(R.string.exam_type_mcq),
                        modifier = Modifier.padding(top = 12.dp)
                    )
                }

                Text(
                    stringResource(R.string.exam_generator_count_label),
                    modifier = Modifier.padding(top = 12.dp)
                )
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    items(questionCountOptions) { count ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedCount == count,
                                onClick = { selectedCount = count }
                            )
                            Text(count.toString())
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onInsert(buildExamTemplate(selectedType, selectedCount))
            }) {
                Text(stringResource(R.string.exam_generator_insert))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.exam_generator_cancel))
            }
        }
    )
}

/**
 * يبني نص الأسئلة الجاهز حسب النوع والعدد، بترقيم عربي تلقائي.
 */
private fun buildExamTemplate(type: ExamQuestionType, count: Int): String {
    val builder = StringBuilder()
    for (i in 1..count) {
        when (type) {
            ExamQuestionType.TRUE_FALSE -> {
                builder.append("(   )  $i.  ................................................\n\n")
            }
            ExamQuestionType.MCQ -> {
                builder.append("$i.  ................................................\n")
                builder.append("     أ) .........        ب) .........\n")
                builder.append("     ج) .........        د) .........\n\n")
            }
        }
    }
    return builder.toString()
}
