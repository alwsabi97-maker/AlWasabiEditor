package com.alwsabi.editor.ui.screens.students

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.alwsabi.editor.data.model.StudentRecord
import com.alwsabi.editor.data.repository.StudentsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class StudentsViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = StudentsRepository(application)

    val students: StateFlow<List<StudentRecord>> = repository.studentsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addStudent(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch { repository.addStudent(name.trim()) }
    }

    fun removeStudent(name: String) {
        viewModelScope.launch { repository.removeStudent(name) }
    }
}
