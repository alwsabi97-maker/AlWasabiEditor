package com.alwsabi.editor.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.alwsabi.editor.data.model.ExamMetadata

/**
 * صندوق بسيط لإدخال بيانات ترويسة الاختبار — حقول نص عادية فقط، بدون أي
 * تنسيق HTML أو خطوط أو محاذاة مخصصة، لضمان نتيجة ثابتة ومضمونة دائمًا.
 */
@Composable
fun ExamMetadataDialog(
    initial: ExamMetadata,
    onDismiss: () -> Unit,
    onConfirm: (ExamMetadata) -> Unit
) {
    var schoolName by remember { mutableStateOf(initial.schoolName) }
    var governorate by remember { mutableStateOf(initial.governorate) }
    var directorate by remember { mutableStateOf(initial.directorate) }
    var subject by remember { mutableStateOf(initial.subject) }
    var grade by remember { mutableStateOf(initial.grade) }
    var semester by remember { mutableStateOf(initial.semester.ifBlank { "الأول" }) }
    var year by remember { mutableStateOf(initial.year) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("بيانات الاختبار") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = schoolName, onValueChange = { schoolName = it },
                    label = { Text("اسم المدرسة") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = governorate, onValueChange = { governorate = it },
                    label = { Text("المحافظة") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = directorate, onValueChange = { directorate = it },
                    label = { Text("المديرية") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = subject, onValueChange = { subject = it },
                    label = { Text("المادة") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = grade, onValueChange = { grade = it },
                    label = { Text("الصف الدراسي") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Text("الفصل الدراسي")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = semester == "الأول", onClick = { semester = "الأول" })
                    Text("الأول")
                    RadioButton(selected = semester == "الثاني", onClick = { semester = "الثاني" })
                    Text("الثاني")
                }
                OutlinedTextField(
                    value = year, onValueChange = { year = it },
                    label = { Text("العام الدراسي") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onConfirm(
                    ExamMetadata(schoolName, governorate, directorate, subject, grade, semester, year)
                )
            }) { Text("حفظ وإدراج") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
