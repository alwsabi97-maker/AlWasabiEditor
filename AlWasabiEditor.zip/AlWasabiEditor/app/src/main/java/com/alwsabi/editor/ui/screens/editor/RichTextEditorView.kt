package com.alwsabi.editor.ui.screens.editor

import android.graphics.Typeface
import android.text.Editable
import android.text.Layout
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.TextWatcher
import android.text.style.AlignmentSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView

/**
 * حالة التحديد الحالية (بداية/نهاية) لتطبيق التنسيقات عليها.
 */
data class SelectionRange(val start: Int, val end: Int) {
    fun isValid() = start in 0..end
}

/**
 * تحكم يُمرَّر للواجهة الخارجية للتفاعل مع محرر النص الغني:
 * تطبيق تنسيقات، الحصول على النص الحالي، ضبط نص جديد، البحث والاستبدال.
 */
class RichEditorController(private val editTextProvider: () -> EditText?) {

    fun getEditText(): EditText? = editTextProvider()

    fun currentSpannable(): Spannable? = getEditText()?.text

    fun currentSelection(): SelectionRange {
        val et = getEditText() ?: return SelectionRange(0, 0)
        return SelectionRange(et.selectionStart.coerceAtLeast(0), et.selectionEnd.coerceAtLeast(0))
    }

    fun setText(text: CharSequence) {
        val et = getEditText() ?: return
        et.setText(text)
        et.setSelection(et.text?.length ?: 0)
    }

    fun toggleBold() = toggleStyle(Typeface.BOLD)
    fun toggleItalic() = toggleStyle(Typeface.ITALIC)

    private fun toggleStyle(style: Int) {
        val et = getEditText() ?: return
        val sel = currentSelection()
        if (!sel.isValid() || sel.start == sel.end) return
        val spannable = et.text ?: return

        val existing = spannable.getSpans(sel.start, sel.end, StyleSpan::class.java)
        val hasStyle = existing.any { it.style == style }

        if (hasStyle) {
            existing.filter { it.style == style }.forEach { spannable.removeSpan(it) }
        } else {
            spannable.setSpan(StyleSpan(style), sel.start, sel.end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        et.text = spannable
        et.setSelection(sel.start, sel.end)
    }

    fun toggleUnderline() {
        val et = getEditText() ?: return
        val sel = currentSelection()
        if (!sel.isValid() || sel.start == sel.end) return
        val spannable = et.text ?: return

        val existing = spannable.getSpans(sel.start, sel.end, UnderlineSpan::class.java)
        if (existing.isNotEmpty()) {
            existing.forEach { spannable.removeSpan(it) }
        } else {
            spannable.setSpan(UnderlineSpan(), sel.start, sel.end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        et.text = spannable
        et.setSelection(sel.start, sel.end)
    }

    fun setAlignment(alignment: Layout.Alignment) {
        val et = getEditText() ?: return
        val spannable = et.text ?: return
        val sel = currentSelection()

        val paraStart = findParagraphStart(spannable, sel.start)
        val paraEnd = findParagraphEnd(spannable, if (sel.end > sel.start) sel.end else sel.start)

        val existing = spannable.getSpans(paraStart, paraEnd, AlignmentSpan.Standard::class.java)
        existing.forEach { spannable.removeSpan(it) }
        spannable.setSpan(
            AlignmentSpan.Standard(alignment),
            paraStart,
            paraEnd.coerceAtLeast(paraStart + 1).coerceAtMost(spannable.length.coerceAtLeast(paraStart + 1)),
            Spannable.SPAN_INCLUSIVE_INCLUSIVE
        )
        et.text = spannable
        et.setSelection(sel.start, sel.end)
    }

    /**
     * يطبّق لون النص. إن لم يُمرَّر تحديد جاهز (capturedSelection)، يُعاد قراءته
     * من المحرر لحظتها — لكن الأفضل تمرير تحديد مُلتقط مسبقًا (قبل فتح أي
     * صندوق حواري قد يُفقد التركيز عن المحرر ويُلغي التحديد المرئي).
     */
    fun setTextColor(colorInt: Int, capturedSelection: SelectionRange? = null) {
        val et = getEditText() ?: return
        val sel = capturedSelection ?: currentSelection()
        if (!sel.isValid() || sel.start == sel.end) return
        val spannable = et.text ?: return

        spannable.getSpans(sel.start, sel.end, ForegroundColorSpan::class.java).forEach {
            spannable.removeSpan(it)
        }
        spannable.setSpan(ForegroundColorSpan(colorInt), sel.start, sel.end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        et.text = spannable
        et.setSelection(sel.start, sel.end)
    }

    fun setBackgroundColor(colorInt: Int, capturedSelection: SelectionRange? = null) {
        val et = getEditText() ?: return
        val sel = capturedSelection ?: currentSelection()
        if (!sel.isValid() || sel.start == sel.end) return
        val spannable = et.text ?: return

        spannable.getSpans(sel.start, sel.end, BackgroundColorSpan::class.java).forEach {
            spannable.removeSpan(it)
        }
        spannable.setSpan(BackgroundColorSpan(colorInt), sel.start, sel.end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        et.text = spannable
        et.setSelection(sel.start, sel.end)
    }

    fun setRelativeFontSize(scale: Float) {
        val et = getEditText() ?: return
        val sel = currentSelection()
        if (!sel.isValid() || sel.start == sel.end) return
        val spannable = et.text ?: return

        spannable.getSpans(sel.start, sel.end, RelativeSizeSpan::class.java).forEach {
            spannable.removeSpan(it)
        }
        spannable.setSpan(RelativeSizeSpan(scale), sel.start, sel.end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        et.text = spannable
        et.setSelection(sel.start, sel.end)
    }

    fun setBaseFontSizeSp(sizeSp: Float) {
        getEditText()?.textSize = sizeSp
    }

    fun setBaseTypeface(typeface: Typeface) {
        getEditText()?.typeface = typeface
    }

    /** يُدرج نصًا جاهزًا (مثل أسئلة اختبار أو جدول) عند موضع المؤشر الحالي. */
    fun insertTextAtCursor(text: String) {
        val et = getEditText() ?: return
        val sel = currentSelection()
        val position = if (sel.start >= 0) sel.start else (et.text?.length ?: 0)
        et.text?.insert(position, text)
        et.setSelection((position + text.length).coerceAtMost(et.text?.length ?: 0))
    }

    /** يُدرج جدولًا نصيًا بسيطًا (صفوف × أعمدة) بفواصل واضحة، جاهز للطباعة. */
    fun insertTable(rows: Int, cols: Int) {
        val builder = StringBuilder()
        val colWidth = 12
        repeat(rows) {
            val cells = (1..cols).joinToString(" | ") { "".padEnd(colWidth, '_') }
            builder.append("| $cells |\n")
        }
        insertTextAtCursor(builder.toString())
    }

    /** يُدرج صورة داخل النص في موضع المؤشر باستخدام ImageSpan. */
    fun insertImage(bitmap: android.graphics.Bitmap, maxWidthPx: Int) {
        val et = getEditText() ?: return
        val scale = if (bitmap.width > maxWidthPx) maxWidthPx.toFloat() / bitmap.width else 1f
        val scaledBitmap = if (scale < 1f) {
            android.graphics.Bitmap.createScaledBitmap(
                bitmap,
                (bitmap.width * scale).toInt().coerceAtLeast(1),
                (bitmap.height * scale).toInt().coerceAtLeast(1),
                true
            )
        } else bitmap

        val drawable = android.graphics.drawable.BitmapDrawable(et.resources, scaledBitmap)
        drawable.setBounds(0, 0, scaledBitmap.width, scaledBitmap.height)
        val span = android.text.style.ImageSpan(drawable, android.text.style.ImageSpan.ALIGN_BOTTOM)

        val sel = currentSelection()
        val position = if (sel.start >= 0) sel.start else (et.text?.length ?: 0)
        val spannable = et.text ?: return
        spannable.insert(position, "\uFFFC\n")
        spannable.setSpan(span, position, position + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        et.setSelection((position + 2).coerceAtMost(spannable.length))
    }

    fun undo(text: CharSequence, selection: Int) {
        val et = getEditText() ?: return
        et.setText(text)
        val safeSel = selection.coerceIn(0, et.text?.length ?: 0)
        et.setSelection(safeSel)
    }

    private fun findParagraphStart(text: CharSequence, from: Int): Int {
        var i = from.coerceIn(0, text.length)
        while (i > 0 && text[i - 1] != '\n') i--
        return i
    }

    private fun findParagraphEnd(text: CharSequence, from: Int): Int {
        var i = from.coerceIn(0, text.length)
        while (i < text.length && text[i] != '\n') i++
        return i
    }
}

/**
 * محرر نص غني حقيقي يعتمد على EditText تقليدي (عبر AndroidView) مع
 * Spannable لدعم تنسيقات حقيقية (عريض/مائل/تسطير/لون/محاذاة/حجم خط)
 * على أجزاء محددة من النص. هذا النهج مستقر ومختبر جيدًا في أندرويد،
 * بعكس محاولة بناء محرر غني من الصفر فوق BasicTextField.
 */
@Composable
fun RichTextEditorView(
    modifier: Modifier = Modifier,
    initialText: CharSequence,
    isRtl: Boolean,
    baseFontSizeSp: Float,
    baseFontFamily: com.alwsabi.editor.data.model.EditorFontFamily = com.alwsabi.editor.data.model.EditorFontFamily.DEFAULT,
    onTextChanged: (Editable) -> Unit,
    onSelectionChanged: (Int, Int) -> Unit,
    onControllerReady: (RichEditorController) -> Unit
) {
    val context = LocalContext.current
    val editTextRef = remember { mutableStateOf<EditText?>(null) }

    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = {
            EditText(context).apply {
                setText(initialText, android.widget.TextView.BufferType.SPANNABLE)
                textSize = baseFontSizeSp
                typeface = when (baseFontFamily) {
                    com.alwsabi.editor.data.model.EditorFontFamily.DEFAULT -> Typeface.DEFAULT
                    com.alwsabi.editor.data.model.EditorFontFamily.SERIF -> Typeface.SERIF
                    com.alwsabi.editor.data.model.EditorFontFamily.MONOSPACE -> Typeface.MONOSPACE
                    com.alwsabi.editor.data.model.EditorFontFamily.SANS_SERIF_CONDENSED ->
                        Typeface.create("sans-serif-condensed", Typeface.NORMAL)
                }
                gravity = if (isRtl) Gravity.START or Gravity.TOP else Gravity.START or Gravity.TOP
                textDirection = if (isRtl) android.view.View.TEXT_DIRECTION_RTL else android.view.View.TEXT_DIRECTION_LTR
                layoutDirection = if (isRtl) android.view.View.LAYOUT_DIRECTION_RTL else android.view.View.LAYOUT_DIRECTION_LTR
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setPadding(32, 24, 32, 24)
                isSingleLine = false
                setHorizontallyScrolling(false)
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                imeOptions = android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI

                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        s?.let { onTextChanged(it) }
                    }
                })

                setOnClickListener {
                    onSelectionChanged(selectionStart, selectionEnd)
                }

                editTextRef.value = this
                onControllerReady(RichEditorController { editTextRef.value })
            }
        },
        update = { editText ->
            editTextRef.value = editText
        }
    )
}
