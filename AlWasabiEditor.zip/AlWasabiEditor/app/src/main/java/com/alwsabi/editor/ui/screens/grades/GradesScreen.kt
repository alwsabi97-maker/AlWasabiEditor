package com.alwsabi.editor.ui.screens.grades

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alwsabi.editor.ui.components.AppTopBar

private val columnWidth = 70.dp
private val nameColumnWidth = 130.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GradesScreen(
    onNavigateBack: () -> Unit,
    viewModel: GradesViewModel = viewModel()
) {
    val students by viewModel.students.collectAsState()
    val grades by viewModel.grades.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            AppTopBar(title = "درجات الطلاب", showBackButton = true, onBackClick = onNavigateBack)
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "إضافة درجة")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (grades.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "لا توجد درجات مسجّلة بعد",
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            } else {
                Box(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    Column {
                        GradesTableHeaderRow()
                        HorizontalDivider()
                        LazyColumn {
                            items(grades) { grade ->
                                GradesTableRow(grade = grade, onDelete = { viewModel.removeGrade(grade) })
                                HorizontalDivider()
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddGradeDialog(
            students = students.map { it.name },
            onDismiss = { showAddDialog = false },
            onConfirm = { name, subject, hw, att, oral, written ->
                viewModel.addGrade(name, subject, hw, att, oral, written)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun GradesTableHeaderRow() {
    Row(
        modifier = Modifier.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        HeaderCell("اسم الطالب", nameColumnWidth)
        HeaderCell("المادة", columnWidth)
        HeaderCell("الواجبات", columnWidth)
        HeaderCell("المواظبة", columnWidth)
        HeaderCell("الشفوي", columnWidth)
        HeaderCell("التحريري", columnWidth)
        HeaderCell("المجموع", columnWidth)
        HeaderCell("", 48.dp)
    }
}

@Composable
private fun HeaderCell(text: String, width: androidx.compose.ui.unit.Dp) {
    Text(
        text,
        modifier = Modifier.width(width).padding(horizontal = 4.dp),
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.Bold,
        textAlign = androidx.compose.ui.text.style.TextAlign.Center
    )
}

@Composable
private fun DataCell(text: String, width: androidx.compose.ui.unit.Dp) {
    Text(
        text,
        modifier = Modifier.width(width).padding(horizontal = 4.dp),
        style = MaterialTheme.typography.bodyMedium,
        textAlign = androidx.compose.ui.text.style.TextAlign.Center
    )
}

@Composable
private fun GradesTableRow(grade: com.alwsabi.editor.data.model.GradeRecord, onDelete: () -> Unit) {
    Row(
        modifier = Modifier.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        DataCell(grade.studentName, nameColumnWidth)
        DataCell(grade.subject, columnWidth)
        DataCell(grade.homework, columnWidth)
        DataCell(grade.attendance, columnWidth)
        DataCell(grade.oral, columnWidth)
        DataCell(grade.written, columnWidth)
        DataCell(grade.total.toString(), columnWidth)
        IconButton(onClick = onDelete, modifier = Modifier.width(48.dp)) {
            Icon(Icons.Default.Close, contentDescription = "حذف")
        }
    }
}

@Composable
private fun AddGradeDialog(
    students: List<String>,
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, String, String, String) -> Unit
) {
    var selectedStudent by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("") }
    var homework by remember { mutableStateOf("") }
    var attendance by remember { mutableStateOf("") }
    var oral by remember { mutableStateOf("") }
    var written by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة درجة") },
        text = {
            Column {
                Box {
                    OutlinedTextField(
                        value = selectedStudent,
                        onValueChange = { selectedStudent = it },
                        label = { Text("اسم الطالب") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    DropdownMenu(expanded = expanded && students.isNotEmpty(), onDismissRequest = { expanded = false }) {
                        students.forEach { name ->
                            DropdownMenuItem(text = { Text(name) }, onClick = {
                                selectedStudent = name
                                expanded = false
                            })
                        }
                    }
                }
                if (students.isNotEmpty()) {
                    TextButton(onClick = { expanded = true }) { Text("اختر من القائمة") }
                }
                OutlinedTextField(
                    value = subject, onValueChange = { subject = it },
                    label = { Text("المادة") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Row {
                    OutlinedTextField(
                        value = homework, onValueChange = { homework = it.filter { c -> c.isDigit() } },
                        label = { Text("الواجبات") }, singleLine = true, modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = attendance, onValueChange = { attendance = it.filter { c -> c.isDigit() } },
                        label = { Text("المواظبة") }, singleLine = true, modifier = Modifier.weight(1f)
                    )
                }
                Row {
                    OutlinedTextField(
                        value = oral, onValueChange = { oral = it.filter { c -> c.isDigit() } },
                        label = { Text("الشفوي") }, singleLine = true, modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = written, onValueChange = { written = it.filter { c -> c.isDigit() } },
                        label = { Text("التحريري") }, singleLine = true, modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(selectedStudent, subject, homework, attendance, oral, written) }) {
                Text("إضافة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
