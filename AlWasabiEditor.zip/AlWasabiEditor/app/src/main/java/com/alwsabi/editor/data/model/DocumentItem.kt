package com.alwsabi.editor.data.model

/**
 * يمثل ملفًا محفوظًا في قائمة "المستندات الأخيرة".
 * يتم تخزين هذه القائمة داخل DataStore على شكل نصوص مفصولة.
 */
data class RecentDocument(
    val uriString: String,
    val displayName: String,
    val lastOpenedMillis: Long,
    val mimeType: String
)

/**
 * أنواع الملفات المدعومة في التطبيق.
 */
enum class SupportedFileType(val extension: String, val mimeType: String) {
    TXT("txt", "text/plain"),
    JSON("json", "application/json"),
    CSV("csv", "text/csv"),
    MD("md", "text/markdown"),
    XML("xml", "text/xml"),
    HTML("html", "text/html"),
    UNKNOWN("txt", "text/plain");

    companion object {
        fun fromExtension(ext: String): SupportedFileType {
            val normalized = ext.trim().lowercase()
            return entries.firstOrNull { it.extension == normalized } ?: UNKNOWN
        }

        fun fromMimeType(mime: String?): SupportedFileType {
            if (mime == null) return UNKNOWN
            return entries.firstOrNull { it.mimeType == mime } ?: UNKNOWN
        }
    }
}

/**
 * حالة نتيجة عملية على ملف (نجاح أو فشل مع رسالة).
 */
sealed class FileOperationResult {
    data class Success(val message: String? = null) : FileOperationResult()
    data class Failure(val message: String) : FileOperationResult()
}
