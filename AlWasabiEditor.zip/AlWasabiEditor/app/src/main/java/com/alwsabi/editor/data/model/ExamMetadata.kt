package com.alwsabi.editor.data.model

/**
 * بيانات ترويسة الاختبار — نصوص عادية بسيطة بدون أي تنسيق HTML، لتفادي
 * كل مشاكل الحفظ/المحاذاة/حجم الخط اللي صارت مع النظام القديم المعقّد.
 */
data class ExamMetadata(
    val schoolName: String = "",
    val governorate: String = "",
    val directorate: String = "",
    val subject: String = "",
    val grade: String = "",
    val semester: String = "",
    val year: String = ""
) {
    /** يبني نص الترويسة الجاهز للعرض والحفظ والتصدير — نفس الصيغة دائمًا، بسيطة ومضمونة. */
    fun toPlainText(): String {
        if (this == ExamMetadata()) return ""
        val b = StringBuilder()
        b.append("الجمهورية اليمنية\n")
        b.append("وزارة التربية والتعليم\n")
        if (governorate.isNotBlank()) b.append("محافظة: $governorate\n")
        if (directorate.isNotBlank()) b.append("مديرية: $directorate\n")
        if (schoolName.isNotBlank()) b.append("مدرسة: $schoolName\n")
        b.append("―――――――――――――――――――――――――――――――――\n")
        if (subject.isNotBlank()) b.append("المادة: $subject\n")
        if (grade.isNotBlank()) b.append("الصف: $grade\n")
        if (semester.isNotBlank()) b.append("الفصل الدراسي: $semester\n")
        if (year.isNotBlank()) b.append("العام الدراسي: $year\n")
        b.append("―――――――――――――――――――――――――――――――――\n\n")
        return b.toString()
    }
}
