package com.alwsabi.editor.ui.screens.editor

import android.app.Application
import android.net.Uri
import android.text.Editable
import android.text.SpannableStringBuilder
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.alwsabi.editor.data.model.FileOperationResult
import com.alwsabi.editor.data.model.RecentDocument
import com.alwsabi.editor.data.model.SupportedFileType
import com.alwsabi.editor.data.pdf.PdfExporter
import com.alwsabi.editor.data.repository.FileRepository
import com.alwsabi.editor.data.repository.RecentFilesRepository
import com.alwsabi.editor.util.RichTextConverter
import com.alwsabi.editor.util.TextStatsUtil
import com.alwsabi.editor.util.UndoRedoManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

/** حالة واجهة شاشة المحرر بالكامل. */
data class EditorUiState(
    val documentUri: String? = null,
    val fileName: String = "مستند بدون عنوان",
    val fileType: SupportedFileType = SupportedFileType.TXT,
    val wordCount: Int = 0,
    val charCount: Int = 0,
    val hasUnsavedChanges: Boolean = false,
    val isLoading: Boolean = false,
    val isSaving: Boolean = false,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val statusMessage: String? = null,
    val errorMessage: String? = null,
    val showFindReplace: Boolean = false,
    val findQuery: String = "",
    val replaceQuery: String = "",
    val findMatchCount: Int = 0,
    val pendingExitConfirmation: Boolean = false,
    val lastExportedPdfPath: String? = null
)

class EditorViewModel(application: Application) : AndroidViewModel(application) {

    private val fileRepository = FileRepository(application)
    private val recentFilesRepository = RecentFilesRepository(application)
    private val pdfExporter = PdfExporter(application)
    private val undoRedoManager = UndoRedoManager()

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    private var currentUri: Uri? = null
    private var currentEditable: CharSequence = ""
    private var autoSaveEnabled = true
    private var autoSaveJob: kotlinx.coroutines.Job? = null

    fun startNewDocument() {
        currentUri = null
        currentEditable = ""
        undoRedoManager.initialize("")
        _uiState.value = EditorUiState(
            fileName = "مستند بدون عنوان",
            fileType = SupportedFileType.TXT,
            wordCount = 0,
            charCount = 0
        )
    }

    fun openDocument(uri: Uri) {
        _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            val result = fileRepository.readTextFromUri(uri)
            result.fold(
                onSuccess = { text ->
                    currentUri = uri
                    currentEditable = text
                    undoRedoManager.initialize(text)
                    val name = fileRepository.queryDisplayName(uri)
                    val ext = name.substringAfterLast('.', "txt")
                    _uiState.value = _uiState.value.copy(
                        documentUri = uri.toString(),
                        fileName = name,
                        fileType = SupportedFileType.fromExtension(ext),
                        wordCount = TextStatsUtil.wordCount(text),
                        charCount = TextStatsUtil.charCount(text),
                        isLoading = false,
                        hasUnsavedChanges = false,
                        canUndo = false,
                        canRedo = false
                    )
                    recentFilesRepository.addOrUpdate(
                        RecentDocument(
                            uriString = uri.toString(),
                            displayName = name,
                            lastOpenedMillis = System.currentTimeMillis(),
                            mimeType = SupportedFileType.fromExtension(ext).mimeType
                        )
                    )
                },
                onFailure = {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = "تعذر فتح الملف، قد يكون تالفًا أو غير مدعوم"
                    )
                }
            )
        }
    }

    fun onTextChanged(editable: Editable) {
        currentEditable = SpannableStringBuilder(editable)
        undoRedoManager.push(currentEditable)
        _uiState.value = _uiState.value.copy(
            wordCount = TextStatsUtil.wordCount(editable),
            charCount = TextStatsUtil.charCount(editable),
            hasUnsavedChanges = true,
            canUndo = undoRedoManager.canUndo(),
            canRedo = undoRedoManager.canRedo()
        )
        if (autoSaveEnabled) scheduleAutoSave()
    }

    private fun scheduleAutoSave() {
        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch {
            delay(2500)
            val uri = currentUri
            if (uri != null) {
                performSave(uri, silent = true)
            }
        }
    }

    fun setAutoSaveEnabled(enabled: Boolean) {
        autoSaveEnabled = enabled
    }

    fun requestUndo(controller: RichEditorController) {
        val restored = undoRedoManager.undo() ?: return
        currentEditable = restored
        controller.setText(restored)
        _uiState.value = _uiState.value.copy(
            wordCount = TextStatsUtil.wordCount(restored),
            charCount = TextStatsUtil.charCount(restored),
            canUndo = undoRedoManager.canUndo(),
            canRedo = undoRedoManager.canRedo(),
            hasUnsavedChanges = true
        )
    }

    fun requestRedo(controller: RichEditorController) {
        val restored = undoRedoManager.redo() ?: return
        currentEditable = restored
        controller.setText(restored)
        _uiState.value = _uiState.value.copy(
            wordCount = TextStatsUtil.wordCount(restored),
            charCount = TextStatsUtil.charCount(restored),
            canUndo = undoRedoManager.canUndo(),
            canRedo = undoRedoManager.canRedo(),
            hasUnsavedChanges = true
        )
    }

    fun save() {
        val uri = currentUri
        if (uri == null) {
            _uiState.value = _uiState.value.copy(statusMessage = "اختر مكان الحفظ أولاً عبر (حفظ باسم)")
            return
        }
        performSave(uri, silent = false)
    }

    private fun performSave(uri: Uri, silent: Boolean) {
        _uiState.value = _uiState.value.copy(isSaving = true)
        viewModelScope.launch {
            val textToSave = currentEditable.toString()
            when (val result = fileRepository.writeTextToUri(uri, textToSave)) {
                is FileOperationResult.Success -> {
                    _uiState.value = _uiState.value.copy(
                        isSaving = false,
                        hasUnsavedChanges = false,
                        statusMessage = if (silent) "تم الحفظ التلقائي" else "تم الحفظ بنجاح"
                    )
                    recentFilesRepository.addOrUpdate(
                        RecentDocument(
                            uriString = uri.toString(),
                            displayName = _uiState.value.fileName,
                            lastOpenedMillis = System.currentTimeMillis(),
                            mimeType = _uiState.value.fileType.mimeType
                        )
                    )
                }
                is FileOperationResult.Failure -> {
                    _uiState.value = _uiState.value.copy(
                        isSaving = false,
                        errorMessage = "حدث خطأ أثناء الحفظ: ${result.message}"
                    )
                }
            }
        }
    }

    fun onSaveAsUriObtained(uri: Uri) {
        currentUri = uri
        val name = fileRepository.queryDisplayName(uri)
        val ext = name.substringAfterLast('.', "txt")
        _uiState.value = _uiState.value.copy(
            documentUri = uri.toString(),
            fileName = name,
            fileType = SupportedFileType.fromExtension(ext)
        )
        performSave(uri, silent = false)
    }

    fun renameCurrentDocument(newName: String) {
        val uri = currentUri ?: return
        viewModelScope.launch {
            when (val result = fileRepository.renameDocument(uri, newName)) {
                is FileOperationResult.Success -> {
                    _uiState.value = _uiState.value.copy(
                        fileName = newName,
                        statusMessage = "تم تغيير اسم الملف"
                    )
                }
                is FileOperationResult.Failure -> {
                    _uiState.value = _uiState.value.copy(errorMessage = result.message)
                }
            }
        }
    }

    fun deleteCurrentDocument(onDeleted: () -> Unit) {
        val uri = currentUri ?: return
        viewModelScope.launch {
            when (val result = fileRepository.deleteDocument(uri)) {
                is FileOperationResult.Success -> {
                    recentFilesRepository.remove(uri.toString())
                    onDeleted()
                }
                is FileOperationResult.Failure -> {
                    _uiState.value = _uiState.value.copy(errorMessage = result.message)
                }
            }
        }
    }

    fun shareCurrentDocument(onIntentReady: (android.content.Intent) -> Unit) {
        viewModelScope.launch {
            val name = _uiState.value.fileName.ifBlank { "مستند" }
            val safeName = if (name.contains('.')) name else "$name.${_uiState.value.fileType.extension}"
            val uri = fileRepository.createShareableFile(currentEditable.toString(), safeName)
            if (uri != null) {
                onIntentReady(fileRepository.buildShareIntent(uri, _uiState.value.fileType.mimeType))
            } else {
                _uiState.value = _uiState.value.copy(errorMessage = "تعذر تجهيز الملف للمشاركة")
            }
        }
    }

    fun exportToPdf(fontSizePx: Float, isRtl: Boolean, onReadyToShare: (android.content.Intent) -> Unit) {
        viewModelScope.launch {
            val baseName = _uiState.value.fileName.substringBeforeLast('.', _uiState.value.fileName)
            val outputName = "$baseName.pdf"
            val result = pdfExporter.exportToPdf(currentEditable, fontSizePx, isRtl, outputName)
            result.fold(
                onSuccess = { file ->
                    _uiState.value = _uiState.value.copy(
                        statusMessage = "تم تصدير المستند كملف PDF بنجاح",
                        lastExportedPdfPath = file.absolutePath
                    )
                    val uri = fileRepository.getUriForCacheFile(file)
                    onReadyToShare(fileRepository.buildShareIntent(uri, "application/pdf"))
                },
                onFailure = {
                    _uiState.value = _uiState.value.copy(errorMessage = "تعذر تصدير المستند إلى PDF")
                }
            )
        }
    }

    fun toggleFindReplace(show: Boolean) {
        _uiState.value = _uiState.value.copy(showFindReplace = show, findQuery = "", replaceQuery = "", findMatchCount = 0)
    }

    fun updateFindQuery(query: String) {
        val count = if (query.isEmpty()) 0 else {
            Regex(Regex.escape(query)).findAll(currentEditable).count()
        }
        _uiState.value = _uiState.value.copy(findQuery = query, findMatchCount = count)
    }

    fun updateReplaceQuery(query: String) {
        _uiState.value = _uiState.value.copy(replaceQuery = query)
    }

    fun replaceAll(controller: RichEditorController) {
        val query = _uiState.value.findQuery
        if (query.isEmpty()) return
        val replacement = _uiState.value.replaceQuery
        val newText = currentEditable.toString().replace(query, replacement)
        currentEditable = newText
        controller.setText(newText)
        undoRedoManager.push(newText)
        _uiState.value = _uiState.value.copy(
            wordCount = TextStatsUtil.wordCount(newText),
            charCount = TextStatsUtil.charCount(newText),
            hasUnsavedChanges = true,
            findMatchCount = 0,
            canUndo = undoRedoManager.canUndo()
        )
    }

    fun consumeStatusMessage() {
        _uiState.value = _uiState.value.copy(statusMessage = null)
    }

    fun consumeErrorMessage() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    fun requestExitConfirmation(show: Boolean) {
        _uiState.value = _uiState.value.copy(pendingExitConfirmation = show)
    }

    fun hasUnsavedChanges(): Boolean = _uiState.value.hasUnsavedChanges

    fun currentTextSnapshot(): CharSequence = currentEditable
}
