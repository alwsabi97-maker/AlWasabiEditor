package com.alwsabi.editor.data.model

/** سجل طالب أساسي (الاسم فقط، يُستخدم كمرجع في شاشة الدرجات). */
data class StudentRecord(val name: String)

/**
 * سجل درجة لطالب في مادة معيّنة، مقسّم لأربع فئات تقييم (زي دفتر الدرجات
 * التقليدي: واجبات، مواظبة، شفوي، تحريري)، مع مجموع يُحسب تلقائيًا.
 */
data class GradeRecord(
    val studentName: String,
    val subject: String,
    val homework: String = "",
    val attendance: String = "",
    val oral: String = "",
    val written: String = ""
) {
    val total: Int
        get() = listOf(homework, attendance, oral, written).sumOf { it.toIntOrNull() ?: 0 }
}
