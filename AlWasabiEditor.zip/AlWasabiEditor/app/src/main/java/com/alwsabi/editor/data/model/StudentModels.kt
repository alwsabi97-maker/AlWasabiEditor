package com.alwsabi.editor.data.model

/** سجل طالب أساسي (الاسم فقط، يُستخدم كمرجع في شاشة الدرجات). */
data class StudentRecord(val name: String)

/** سجل درجة لطالب في مادة معيّنة. */
data class GradeRecord(val studentName: String, val subject: String, val score: String)
