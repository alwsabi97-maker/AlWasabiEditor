package com.alwsabi.editor.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

/**
 * صندوق حواري لإدراج خاتمة الورقة في نهاية المستند: نص التمنيات يظهر جهة
 * اليسار، واسم أستاذ المادة جهة اليمين، على نفس السطر.
 */
@Composable
fun ExamFooterDialog(
    onDismiss: () -> Unit,
    onInsert: (String) -> Unit
) {
    var wish by remember { mutableStateOf("تمنياتي لكم بالتوفيق والنجاح") }
    var teacherName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("خاتمة الورقة") },
        text = {
            Column {
                OutlinedTextField(
                    value = teacherName, onValueChange = { teacherName = it },
                    label = { Text("أستاذ المادة (يظهر يمين السطر)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = wish, onValueChange = { wish = it },
                    label = { Text("نص التمنيات (يظهر يسار السطر)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onInsert(buildFooterLine(teacherName, wish))
            }) { Text("إدراج نهاية الورقة") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

/**
 * يبني سطر الخاتمة بحيث تظهر "أستاذ المادة" في أول السطر (يمين الورقة لأن
 * الاتجاه RTL) و"تمنياتي..." بعد مسافة فاصلة كبيرة (تظهر يسار السطر).
 */
private fun buildFooterLine(teacherName: String, wish: String): String {
    val teacherPart = "أستاذ المادة / ${teacherName.ifBlank { "...." }}"
    val spacing = "                    "
    return "\n―――――――――――――――――――――――――――――――――\n$teacherPart$spacing$wish\n"
}
