package com.alwsabi.editor.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.res.stringResource
import com.alwsabi.editor.R

@Composable
fun TableInsertDialog(
    onDismiss: () -> Unit,
    onInsert: (rows: Int, cols: Int) -> Unit
) {
    var rowsText by remember { mutableStateOf("3") }
    var colsText by remember { mutableStateOf("3") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.editor_insert_table)) },
        text = {
            Column {
                OutlinedTextField(
                    value = rowsText,
                    onValueChange = { rowsText = it.filter { c -> c.isDigit() } },
                    label = { Text(stringResource(R.string.table_rows_label)) },
                    singleLine = true
                )
                OutlinedTextField(
                    value = colsText,
                    onValueChange = { colsText = it.filter { c -> c.isDigit() } },
                    label = { Text(stringResource(R.string.table_cols_label)) },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val rows = rowsText.toIntOrNull()?.coerceIn(1, 20) ?: 3
                val cols = colsText.toIntOrNull()?.coerceIn(1, 10) ?: 3
                onInsert(rows, cols)
            }) {
                Text(stringResource(R.string.table_insert_confirm))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.editor_cancel)) }
        }
    )
}
