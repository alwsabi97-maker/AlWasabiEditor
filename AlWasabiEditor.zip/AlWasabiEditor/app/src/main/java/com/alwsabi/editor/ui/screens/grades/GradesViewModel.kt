package com.alwsabi.editor.ui.screens.grades

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.alwsabi.editor.data.model.GradeRecord
import com.alwsabi.editor.data.model.StudentRecord
import com.alwsabi.editor.data.repository.StudentsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GradesViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = StudentsRepository(application)

    val students: StateFlow<List<StudentRecord>> = repository.studentsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val grades: StateFlow<List<GradeRecord>> = repository.gradesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addGrade(
        studentName: String,
        subject: String,
        homework: String,
        attendance: String,
        oral: String,
        written: String
    ) {
        if (studentName.isBlank() || subject.isBlank()) return
        viewModelScope.launch {
            repository.addGrade(GradeRecord(studentName, subject, homework, attendance, oral, written))
        }
    }

    fun removeGrade(record: GradeRecord) {
        viewModelScope.launch { repository.removeGrade(record) }
    }
}
