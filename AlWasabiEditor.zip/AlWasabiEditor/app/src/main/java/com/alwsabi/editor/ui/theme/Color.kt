package com.alwsabi.editor.ui.theme

import androidx.compose.ui.graphics.Color

// هوية بنفسجية جديدة (خاصة بمحرر الوصابي، غير منسوخة من أي تطبيق آخر)
val WasabiGreen = Color(0xFF6A3FA0)
val WasabiGreenDark = Color(0xFF4A2A73)
val WasabiGreenLight = Color(0xFF9B7BC7)

val WasabiAccentGold = Color(0xFFD4A24C)

val WasabiBackgroundLight = Color(0xFFFAF8FC)
val WasabiSurfaceLight = Color(0xFFF1EAF8)
val WasabiOnBackgroundLight = Color(0xFF1F1A26)

val WasabiBackgroundDark = Color(0xFF16121C)
val WasabiSurfaceDark = Color(0xFF241E2E)
val WasabiOnBackgroundDark = Color(0xFFEDE7F2)

val WasabiError = Color(0xFFBA1A1A)
val WasabiErrorDark = Color(0xFFFFB4AB)

// ألوان مساعدة لشبكة الشاشة الرئيسية (بطاقات ملونة متنوعة)
val CardColor1 = Color(0xFF6A3FA0)
val CardColor2 = Color(0xFF2E7D5B)
val CardColor3 = Color(0xFFC0392B)
val CardColor4 = Color(0xFF1F6FB2)
val CardColor5 = Color(0xFFD4A24C)
val CardColor6 = Color(0xFF7A4FA0)
