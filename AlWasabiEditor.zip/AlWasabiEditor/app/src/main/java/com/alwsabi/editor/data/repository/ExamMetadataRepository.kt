package com.alwsabi.editor.data.repository

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.alwsabi.editor.data.model.ExamMetadata
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.examMetaDataStore by preferencesDataStore(name = "alwasabi_exam_meta")

/**
 * يحفظ آخر بيانات ترويسة استُخدمت (المادة/الصف/المدرسة...)، بحيث تكون
 * جاهزة تلقائيًا في المرة القادمة بدل ما يكتبها المستخدم من جديد كل مرة.
 */
class ExamMetadataRepository(private val context: Context) {

    private object Keys {
        val SCHOOL = stringPreferencesKey("school")
        val GOVERNORATE = stringPreferencesKey("governorate")
        val DIRECTORATE = stringPreferencesKey("directorate")
        val SUBJECT = stringPreferencesKey("subject")
        val GRADE = stringPreferencesKey("grade")
        val SEMESTER = stringPreferencesKey("semester")
        val YEAR = stringPreferencesKey("year")
    }

    val metadataFlow: Flow<ExamMetadata> = context.examMetaDataStore.data.map { p ->
        ExamMetadata(
            schoolName = p[Keys.SCHOOL] ?: "",
            governorate = p[Keys.GOVERNORATE] ?: "",
            directorate = p[Keys.DIRECTORATE] ?: "",
            subject = p[Keys.SUBJECT] ?: "",
            grade = p[Keys.GRADE] ?: "",
            semester = p[Keys.SEMESTER] ?: "",
            year = p[Keys.YEAR] ?: ""
        )
    }

    suspend fun save(meta: ExamMetadata) {
        context.examMetaDataStore.edit { p ->
            p[Keys.SCHOOL] = meta.schoolName
            p[Keys.GOVERNORATE] = meta.governorate
            p[Keys.DIRECTORATE] = meta.directorate
            p[Keys.SUBJECT] = meta.subject
            p[Keys.GRADE] = meta.grade
            p[Keys.SEMESTER] = meta.semester
            p[Keys.YEAR] = meta.year
        }
    }
}
