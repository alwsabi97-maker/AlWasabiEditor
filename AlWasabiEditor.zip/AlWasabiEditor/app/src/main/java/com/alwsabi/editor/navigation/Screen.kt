package com.alwsabi.editor.navigation

/**
 * جميع وجهات التنقل داخل التطبيق مع دوال بناء المسار مع المعاملات.
 */
sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Editor : Screen("editor?uri={uri}") {
        fun buildRoute(encodedUri: String? = null): String {
            return if (encodedUri.isNullOrEmpty()) "editor" else "editor?uri=$encodedUri"
        }
        const val baseRoute = "editor"
        const val argUri = "uri"
    }
    object Settings : Screen("settings")
    object About : Screen("about")
    object Students : Screen("students")
    object Grades : Screen("grades")
    object PdfViewer : Screen("pdf_viewer/{uri}") {
        fun buildRoute(encodedUri: String) = "pdf_viewer/$encodedUri"
        const val argUri = "uri"
    }
}
