package com.alwsabi.editor.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * معاينة كاملة الشاشة لمحتوى المستند الحالي قبل الحفظ أو الطباعة،
 * مع نفس الإطار الزخرفي المستخدم في المحرر.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentPreviewDialog(
    content: String,
    isRtl: Boolean,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = { TopAppBar(title = { Text("معاينة الورقة") }) }
        ) { padding ->
            Box(modifier = Modifier.fillMaxSize().padding(padding)) {
                DecorativePageBorder(
                    modifier = Modifier.fillMaxSize(),
                    color = androidx.compose.ui.graphics.Color(0xFF6A3FA0).copy(alpha = 0.4f)
                )
                Text(
                    text = content,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(28.dp)
                        .verticalScroll(rememberScrollState()),
                    textAlign = if (isRtl) androidx.compose.ui.text.style.TextAlign.Right else androidx.compose.ui.text.style.TextAlign.Left
                )
            }
        }
    }
}
