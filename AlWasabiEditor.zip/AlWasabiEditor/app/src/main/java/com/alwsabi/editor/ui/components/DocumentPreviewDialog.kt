package com.alwsabi.editor.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * معاينة كاملة الشاشة للورقة كاملة (ترويسة + محتوى) قبل الحفظ أو الطباعة،
 * بشكل ورقة A4 حقيقية (نسبة عرض إلى ارتفاع 1:1.414) مع نفس الإطار الزخرفي
 * والترويسة الفعلية المستخدمة في التصدير النهائي.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentPreviewDialog(
    content: String,
    isRtl: Boolean,
    headerBoxes: List<ExamHeaderBox>,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = { TopAppBar(title = { Text("معاينة الورقة (A4)") }) }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Color(0xFFE8E8E8))
                    .verticalScroll(rememberScrollState()),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                ) {
                    // نسبة A4 الحقيقية: العرض : الارتفاع = 1 : 1.414
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f / 1.414f)
                            .background(Color.White)
                    ) {
                        DecorativePageBorder(
                            modifier = Modifier.fillMaxSize(),
                            color = Color(0xFF6A3FA0).copy(alpha = 0.4f)
                        )
                        Column(modifier = Modifier.fillMaxSize().padding(18.dp)) {
                            ExamHeaderBoxes(
                                boxes = headerBoxes,
                                onEdit = { /* للمعاينة فقط، بدون تعديل */ }
                            )
                            Text(
                                text = content,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 12.dp),
                                textAlign = if (isRtl) TextAlign.Right else TextAlign.Left
                            )
                        }
                    }
                }
            }
        }
    }
}
