package com.alwsabi.editor

import android.app.Application

/**
 * صنف التطبيق الرئيسي. لا يقوم حاليًا بأي تهيئة خاصة، لكنه موجود
 * كنقطة مركزية لأي تهيئة مستقبلية (مثل WorkManager أو تسجيل أخطاء محلي)
 * دون التأثير على استقرار بدء تشغيل التطبيق.
 */
class AlWasabiApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
