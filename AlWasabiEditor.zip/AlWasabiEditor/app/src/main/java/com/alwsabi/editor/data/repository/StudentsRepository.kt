package com.alwsabi.editor.data.repository

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.alwsabi.editor.data.model.GradeRecord
import com.alwsabi.editor.data.model.StudentRecord
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.studentsDataStore by preferencesDataStore(name = "alwasabi_students")

/**
 * يخزّن قائمة أسماء الطلاب وقائمة الدرجات (اسم|||مادة|||درجة) عبر DataStore،
 * لاستخدامها في شاشتي "بيانات الطلاب" و"درجات الطلاب".
 */
class StudentsRepository(private val context: Context) {

    private object Keys {
        val STUDENTS = stringSetPreferencesKey("students")
        val GRADES = stringSetPreferencesKey("grades")
    }

    private val sep = "|||"

    val studentsFlow: Flow<List<StudentRecord>> = context.studentsDataStore.data.map { prefs ->
        (prefs[Keys.STUDENTS] ?: emptySet()).map { StudentRecord(it) }.sortedBy { it.name }
    }

    val gradesFlow: Flow<List<GradeRecord>> = context.studentsDataStore.data.map { prefs ->
        (prefs[Keys.GRADES] ?: emptySet()).mapNotNull { entry ->
            val parts = entry.split(sep)
            if (parts.size == 6) {
                GradeRecord(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5])
            } else null
        }
    }

    suspend fun addStudent(name: String) {
        context.studentsDataStore.edit { prefs ->
            val current = (prefs[Keys.STUDENTS] ?: emptySet()).toMutableSet()
            current.add(name)
            prefs[Keys.STUDENTS] = current
        }
    }

    suspend fun removeStudent(name: String) {
        context.studentsDataStore.edit { prefs ->
            val current = (prefs[Keys.STUDENTS] ?: emptySet()).toMutableSet()
            current.remove(name)
            prefs[Keys.STUDENTS] = current
            // إزالة درجاته المرتبطة أيضًا
            val grades = (prefs[Keys.GRADES] ?: emptySet()).filterNot { it.startsWith(name + sep) }.toSet()
            prefs[Keys.GRADES] = grades
        }
    }

    private fun encode(record: GradeRecord): String =
        "${record.studentName}$sep${record.subject}$sep${record.homework}$sep${record.attendance}$sep${record.oral}$sep${record.written}"

    suspend fun addGrade(record: GradeRecord) {
        context.studentsDataStore.edit { prefs ->
            val current = (prefs[Keys.GRADES] ?: emptySet()).toMutableSet()
            current.add(encode(record))
            prefs[Keys.GRADES] = current
        }
    }

    suspend fun removeGrade(record: GradeRecord) {
        context.studentsDataStore.edit { prefs ->
            val current = (prefs[Keys.GRADES] ?: emptySet()).toMutableSet()
            current.remove(encode(record))
            prefs[Keys.GRADES] = current
        }
    }
}
