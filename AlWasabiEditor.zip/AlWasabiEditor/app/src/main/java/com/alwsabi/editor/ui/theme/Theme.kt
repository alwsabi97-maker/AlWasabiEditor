package com.alwsabi.editor.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.alwsabi.editor.data.model.ThemeMode

private val LightColors = lightColorScheme(
    primary = WasabiGreen,
    onPrimary = Color.White,
    primaryContainer = WasabiGreenLight,
    background = WasabiBackgroundLight,
    surface = WasabiSurfaceLight,
    onBackground = WasabiOnBackgroundLight,
    onSurface = WasabiOnBackgroundLight,
    error = WasabiError
)

private val DarkColors = darkColorScheme(
    primary = WasabiGreenLight,
    onPrimary = WasabiOnBackgroundDark,
    primaryContainer = WasabiGreenDark,
    background = WasabiBackgroundDark,
    surface = WasabiSurfaceDark,
    onBackground = WasabiOnBackgroundDark,
    onSurface = WasabiOnBackgroundDark,
    error = WasabiErrorDark
)

@Composable
fun AlWasabiTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val useDark = when (themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> systemDark
    }

    val colorScheme = if (useDark) DarkColors else LightColors

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = colorScheme.primary.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !useDark
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        content = content
    )
}
