package com.alwsabi.editor.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

/**
 * صندوق حواري لإدراج ترويسة (بيانات المدرسة) في أعلى المستند، و/أو
 * خاتمة (تمنيات + اسم أستاذ المادة) في نهايته.
 */
@Composable
fun LetterheadDialog(
    onDismiss: () -> Unit,
    onInsertHeader: (String) -> Unit,
    onInsertFooter: (String) -> Unit
) {
    var schoolName by remember { mutableStateOf("") }
    var directorate by remember { mutableStateOf("") }
    var governorate by remember { mutableStateOf("") }

    var includeFooter by remember { mutableStateOf(true) }
    var closingWish by remember { mutableStateOf("تمنياتي للجميع بالتوفيق والنجاح") }
    var teacherName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("مصمم الترويسة") },
        text = {
            Column {
                Text("بيانات الترويسة (أعلى الورقة)")
                OutlinedTextField(
                    value = schoolName, onValueChange = { schoolName = it },
                    label = { Text("اسم المدرسة") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = directorate, onValueChange = { directorate = it },
                    label = { Text("المديرية") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = governorate, onValueChange = { governorate = it },
                    label = { Text("المحافظة") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                TextButton(onClick = {
                    onInsertHeader(buildHeader(schoolName, directorate, governorate))
                }) {
                    Text("إدراج الترويسة أعلى المستند")
                }

                Text("خاتمة الورقة (نهاية الورقة)")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = includeFooter, onCheckedChange = { includeFooter = it })
                    Text("إضافة خاتمة")
                }
                if (includeFooter) {
                    OutlinedTextField(
                        value = closingWish, onValueChange = { closingWish = it },
                        label = { Text("نص التمنيات") }, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = teacherName, onValueChange = { teacherName = it },
                        label = { Text("أستاذ المادة") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    TextButton(onClick = {
                        onInsertFooter(buildFooter(closingWish, teacherName))
                    }) {
                        Text("إدراج الخاتمة نهاية المستند")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("تم") }
        }
    )
}

private fun buildHeader(school: String, directorate: String, governorate: String): String {
    val builder = StringBuilder()
    builder.append("―――――――――――――――――――――――――――――――――\n")
    if (school.isNotBlank()) builder.append("المدرسة: $school\n")
    if (directorate.isNotBlank()) builder.append("المديرية: $directorate\n")
    if (governorate.isNotBlank()) builder.append("المحافظة: $governorate\n")
    builder.append("―――――――――――――――――――――――――――――――――\n\n")
    return builder.toString()
}

private fun buildFooter(wish: String, teacher: String): String {
    val builder = StringBuilder()
    builder.append("\n―――――――――――――――――――――――――――――――――\n")
    if (wish.isNotBlank()) builder.append("$wish\n")
    if (teacher.isNotBlank()) builder.append("أستاذ المادة / $teacher\n")
    return builder.toString()
}
