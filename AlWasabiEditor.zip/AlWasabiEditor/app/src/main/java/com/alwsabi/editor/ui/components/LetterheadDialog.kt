package com.alwsabi.editor.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

/**
 * صندوق حواري لإدراج ترويسة رسمية (بصيغة وزارة التربية والتعليم اليمنية)
 * أعلى المستند دائمًا، و/أو خاتمة (تمنيات + اسم أستاذ المادة) في نهايته.
 */
@Composable
fun LetterheadDialog(
    onDismiss: () -> Unit,
    onInsertHeader: (String) -> Unit,
    onInsertFooter: (String) -> Unit
) {
    var governorate by remember { mutableStateOf("") }
    var directorate by remember { mutableStateOf("") }
    var schoolName by remember { mutableStateOf("") }
    var examTitle by remember { mutableStateOf("امتحان نهاية الفصل الدراسي الأول") }
    var academicYear by remember { mutableStateOf("") }
    var grade by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("") }
    var examDate by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf("") }
    var period by remember { mutableStateOf("") }

    var includeFooter by remember { mutableStateOf(true) }
    var closingWish by remember { mutableStateOf("تمنياتي للجميع بالتوفيق والنجاح") }
    var teacherName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("مصمم الترويسة") },
        text = {
            Column {
                Text("بيانات الترويسة الرسمية (تُدرج دائمًا أعلى الورقة)")
                OutlinedTextField(
                    value = governorate, onValueChange = { governorate = it },
                    label = { Text("المحافظة") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = directorate, onValueChange = { directorate = it },
                    label = { Text("المديرية") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = schoolName, onValueChange = { schoolName = it },
                    label = { Text("اسم المدرسة") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = examTitle, onValueChange = { examTitle = it },
                    label = { Text("عنوان الامتحان") }, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = academicYear, onValueChange = { academicYear = it },
                    label = { Text("العام الدراسي (هـ)") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Row {
                    OutlinedTextField(
                        value = grade, onValueChange = { grade = it },
                        label = { Text("الصف") }, singleLine = true, modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = subject, onValueChange = { subject = it },
                        label = { Text("المادة") }, singleLine = true, modifier = Modifier.weight(1f)
                    )
                }
                Row {
                    OutlinedTextField(
                        value = examDate, onValueChange = { examDate = it },
                        label = { Text("التاريخ") }, singleLine = true, modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = duration, onValueChange = { duration = it },
                        label = { Text("الزمن") }, singleLine = true, modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = period, onValueChange = { period = it },
                    label = { Text("الفترة") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                TextButton(onClick = {
                    onInsertHeader(
                        buildOfficialHeader(
                            governorate, directorate, schoolName,
                            examTitle, academicYear, grade, subject, examDate, duration, period
                        )
                    )
                    onDismiss()
                }) {
                    Text("إدراج الترويسة أعلى المستند")
                }

                Text("خاتمة الورقة (نهاية الورقة)")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = includeFooter, onCheckedChange = { includeFooter = it })
                    Text("إضافة خاتمة")
                }
                if (includeFooter) {
                    OutlinedTextField(
                        value = closingWish, onValueChange = { closingWish = it },
                        label = { Text("نص التمنيات") }, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = teacherName, onValueChange = { teacherName = it },
                        label = { Text("أستاذ المادة") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    TextButton(onClick = {
                        onInsertFooter(buildFooter(closingWish, teacherName))
                        onDismiss()
                    }) {
                        Text("إدراج الخاتمة نهاية المستند")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        }
    )
}

/**
 * يبني نص الترويسة الرسمية كـ"جدول نصي" من ثلاثة أعمدة مفصولة بخط ( | )،
 * تقريبًا لشكل ثلاث مربعات منفصلة (بما إن المحرر الحالي لا يدعم جداول
 * حقيقية بخلايا مستقلة الحدود). كل سطر يمثّل صفًا من الأعمدة الثلاثة.
 */
private fun buildOfficialHeader(
    governorate: String, directorate: String, school: String,
    examTitle: String, academicYear: String,
    grade: String, subject: String, examDate: String, duration: String, period: String
): String {
    fun row(right: String, middle: String, left: String): String {
        val r = right.ifBlank { " " }
        val m = middle.ifBlank { " " }
        val l = left.ifBlank { " " }
        return "$r  |  $m  |  $l\n"
    }

    val builder = StringBuilder()
    builder.append("―――――――――――――――――――――――――――――――――――――――――――――――――――\n")
    builder.append(row("الجمهورية اليمنية", examTitle, "الصف : ${grade.ifBlank { "...." }}"))
    builder.append(row("وزارة التربية والتعليم", "", "المادة : ${subject.ifBlank { "...." }}"))
    builder.append(
        row(
            "مكتب التربية والتعليم محافظة ${governorate.ifBlank { "...." }}",
            "من العام الدراسي ${academicYear.ifBlank { "...." }}هـ",
            "التاريخ : ${examDate.ifBlank { "...." }}"
        )
    )
    builder.append(
        row(
            "مكتب التربية والتعليم بمديرية ${directorate.ifBlank { "...." }}",
            "",
            "الزمن : ${duration.ifBlank { "...." }}"
        )
    )
    builder.append(row("مدرسة ${school.ifBlank { "...." }}", "", "الفترة : ${period.ifBlank { "...." }}"))
    builder.append("―――――――――――――――――――――――――――――――――――――――――――――――――――\n\n")
    return builder.toString()
}

private fun buildFooter(wish: String, teacher: String): String {
    val builder = StringBuilder()
    builder.append("\n―――――――――――――――――――――――――――――――――\n")
    if (wish.isNotBlank()) builder.append("$wish\n")
    if (teacher.isNotBlank()) builder.append("أستاذ المادة / $teacher\n")
    return builder.toString()
}
