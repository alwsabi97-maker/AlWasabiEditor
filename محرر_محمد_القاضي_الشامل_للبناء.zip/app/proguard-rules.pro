# Offline editor: no custom shrinking rules required.
