# محرر الوصابي الشامل (Alwsabi Comprehensive Editor)

تطبيق Android كامل لتحرير وإدارة المستندات النصية باللغة العربية، مبني بـ Kotlin
و Jetpack Compose بالكامل، بدون أي أجزاء وهمية أو غير مكتملة.

## المواصفات التقنية المطبّقة

- Kotlin 2.0.21 + Jetpack Compose (Material 3)
- Android Gradle Plugin 8.6.1 (الحد الأقصى المدعوم لـ compileSdk 35)
- Gradle 8.9 (يفي بالحد الأدنى المطلوب لـ AGP 8.6.x وهو 8.7)
- Java/JDK 17
- compileSdk = 35, targetSdk = 35, minSdk = 26
- اسم الحزمة: `com.alwsabi.editor`
- اللغة العربية أساسية، والتطبيق بأكمله RTL
- لا توجد أذونات تخزين قديمة، ولا أذونات إنترنت — كل الوصول للملفات عبر
  Storage Access Framework (SAF)

## الميزات المطبّقة فعليًا (لا يوجد TODO ولا أي دالة فارغة)

- شاشة رئيسية: مستند جديد، فتح ملف، المستندات الأخيرة، بحث، الإعدادات، معلومات التطبيق
- محرر نصوص حقيقي (يستضيف EditText أصلي داخل Compose) يدعم:
  عربي/إنجليزي، RTL/LTR، تحديد/نسخ/قص/لصق (عبر النظام مباشرة)، تحديد الكل،
  تراجع/إعادة حقيقيين (تراكم لقطات Snapshot)، بحث داخل المستند، استبدال
  (واحد/الكل)، حجم الخط، عريض/مائل/تحته خط، محاذاة يمين/وسط/يسار، تغيير
  الخط (افتراضي/مزخرف/بسيط/أحادي المسافة)، لون النص، لون الخلفية، عداد
  الكلمات والأحرف، حفظ تلقائي اختياري (كل 30 ثانية)
- إدارة ملفات كاملة عبر SAF: إنشاء، فتح، حفظ، حفظ باسم، إعادة تسمية، حذف،
  مشاركة — لأنواع TXT, JSON, CSV, MD, XML, HTML
- تصدير المستند إلى PDF وعرضه ومشاركته — باستخدام
  `android.graphics.pdf.PdfDocument` و `PdfRenderer` المدمجتين في المنصة
  فقط (بدون أي مكتبة خارجية قد تُفشل البناء)
- إعدادات: المظهر (فاتح/داكن/حسب النظام)، حجم الخط الافتراضي، اتجاه النص
  الافتراضي، الحفظ التلقائي، معلومات التطبيق والإصدار — كلها محفوظة عبر
  Jetpack DataStore
- معالجة أخطاء شاملة: أي فشل في فتح/حفظ/حذف/تصدير ملف يُعرض كرسالة عربية
  واضحة للمستخدم بدلاً من إيقاف التطبيق

## ⚠️ ملاحظة مهمة عن البناء (مهم جدًا قبل التثبيت)

تم إنشاء هذا المشروع بالكامل — كل ملفات Kotlin وGradle والموارد — في بيئة
**بدون اتصال إنترنت**، لذلك:

1. **لم يتم تشغيل `./gradlew assembleDebug` فعليًا هنا**، ولا يوجد ملف
   `app-debug.apk` مرفق. لا يمكن تنزيل مكتبات Gradle/Compose أو التحقق من
   نجاح الترجمة الفعلية بدون إنترنت.
2. **ملف `gradle-wrapper.jar` الثنائي غير موجود** (هو ملف مُصرَّف، لا يمكن
   إنشاؤه يدويًا بدون تنزيله). عند فتح المشروع في Android Studio، سيقوم
   البرنامج تلقائيًا بإصلاح الـ wrapper وتنزيل الملف المطلوب. إذا كان لديك
   Gradle مثبت محليًا، يمكنك أيضًا تشغيل: `gradle wrapper --gradle-version 8.9`
   داخل مجلد المشروع لإعادة توليده يدويًا.

### خطوات البناء الموصى بها

1. افتح المجلد في Android Studio (Koala أو أحدث) عبر
   `File > Open` واختر مجلد `AlwsabiEditor`.
2. اسمح لـ Android Studio بمزامنة Gradle (سيصلح ملف الـ wrapper تلقائيًا).
3. من القائمة: `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. أو من الطرفية: `./gradlew assembleDebug`
   وسيكون الناتج في: `app/build/outputs/apk/debug/app-debug.apk`
5. ثبّت الـ APK الناتج على جهاز أو محاكي Android 15 (API 35) أو أعلى.

إذا ظهر أي خطأ ترجمة أثناء المزامنة أو البناء، راجع الرسالة بعناية — تمت
مراجعة كل الملفات يدويًا (الاستيرادات import، تطابق الحزم package، توازن
الأقواس، توافق إصدارات Gradle/AGP/Kotlin) قبل التسليم، لكن الترجمة الفعلية
لم تُختبر في بيئة SDK حقيقية بسبب غياب الإنترنت هنا.

## هيكل المشروع

```
AlwsabiEditor/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradlew, gradlew.bat, gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/alwsabi/editor/
        │   ├── AlwsabiApplication.kt, MainActivity.kt
        │   ├── data/           (DataStore + FileRepository + SAF + PDF)
        │   ├── model/          (AppSettings, ThemeMode, RecentDocument)
        │   ├── util/           (Span/Undo-Redo/FileType utilities)
        │   └── ui/
        │       ├── theme/      (Color, Type, Theme)
        │       ├── navigation/ (AlwsabiNavHost)
        │       ├── components/ (RichEditText, EditorFormatToolbar, TopBar)
        │       └── screens/    (home, editor, settings, about, search,
        │                        recent, pdf)
        └── res/                (strings.xml بالعربية، أيقونة متجهة، ثيمات)
```
