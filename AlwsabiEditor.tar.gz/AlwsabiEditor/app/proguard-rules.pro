# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.

# Keep line numbers for stack traces
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Jetpack Compose keeps its own consumer ProGuard rules bundled in the AAR,
# no extra rules are required for Compose runtime/UI classes.

# Keep our data/model classes used for DataStore serialization
-keep class com.alwsabi.editor.model.** { *; }
