package com.alwsabi.editor.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.alwsabi.editor.model.RecentDocument
import com.alwsabi.editor.model.serializeAll
import com.alwsabi.editor.model.toRecentDocumentList
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Persists the list of recently opened/saved documents, newest first.
 * Only the document's content Uri, display name and timestamp are stored —
 * never the file's actual content.
 */
class RecentFilesRepository(private val context: Context) {

    private object Keys {
        val RECENT_LIST = stringPreferencesKey("recent_documents")
    }

    private val maxEntries = 30

    val recentDocumentsFlow: Flow<List<RecentDocument>> = context.alwsabiDataStore.data.map { prefs ->
        (prefs[Keys.RECENT_LIST] ?: "").toRecentDocumentList()
            .sortedByDescending { it.lastOpenedMillis }
    }

    suspend fun addOrUpdate(document: RecentDocument) {
        context.alwsabiDataStore.edit { prefs ->
            val current = (prefs[Keys.RECENT_LIST] ?: "").toRecentDocumentList()
                .filterNot { it.uriString == document.uriString }
                .toMutableList()
            current.add(0, document)
            val trimmed = current.sortedByDescending { it.lastOpenedMillis }.take(maxEntries)
            prefs[Keys.RECENT_LIST] = trimmed.serializeAll()
        }
    }

    suspend fun remove(uriString: String) {
        context.alwsabiDataStore.edit { prefs ->
            val current = (prefs[Keys.RECENT_LIST] ?: "").toRecentDocumentList()
                .filterNot { it.uriString == uriString }
            prefs[Keys.RECENT_LIST] = current.serializeAll()
        }
    }

    suspend fun clear() {
        context.alwsabiDataStore.edit { prefs ->
            prefs[Keys.RECENT_LIST] = ""
        }
    }
}
