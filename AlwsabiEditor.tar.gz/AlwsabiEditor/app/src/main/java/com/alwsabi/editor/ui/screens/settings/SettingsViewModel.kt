package com.alwsabi.editor.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.alwsabi.editor.AlwsabiApplication
import com.alwsabi.editor.model.AppSettings
import com.alwsabi.editor.model.TextDirectionPreference
import com.alwsabi.editor.model.ThemeMode
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(private val app: AlwsabiApplication) : ViewModel() {

    val settings: StateFlow<AppSettings> = app.settingsRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { app.settingsRepository.setThemeMode(mode) }
    }

    fun setFontSize(sizeSp: Int) {
        viewModelScope.launch { app.settingsRepository.setDefaultFontSize(sizeSp) }
    }

    fun setTextDirection(direction: TextDirectionPreference) {
        viewModelScope.launch { app.settingsRepository.setTextDirection(direction) }
    }

    fun setAutoSaveEnabled(enabled: Boolean) {
        viewModelScope.launch { app.settingsRepository.setAutoSaveEnabled(enabled) }
    }

    class Factory(private val app: AlwsabiApplication) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = SettingsViewModel(app) as T
    }
}
