package com.alwsabi.editor.ui.theme

import androidx.compose.ui.graphics.Color

// Brand palette — a calm teal/green identity fitting an Arabic writing tool.
val TealPrimary = Color(0xFF1F6F5C)
val TealPrimaryDark = Color(0xFF6FBFAA)
val TealSecondary = Color(0xFF4A8577)
val TealContainerLight = Color(0xFFCBEFE3)
val TealContainerDark = Color(0xFF0F3D33)

val BackgroundLight = Color(0xFFFBFDFB)
val BackgroundDark = Color(0xFF101413)
val SurfaceLight = Color(0xFFF3F6F4)
val SurfaceDark = Color(0xFF1A1F1D)

val OnLight = Color(0xFF161D1B)
val OnDark = Color(0xFFE1E7E4)

val ErrorRed = Color(0xFFBA1A1A)
val ErrorContainerLight = Color(0xFFFFDAD6)
