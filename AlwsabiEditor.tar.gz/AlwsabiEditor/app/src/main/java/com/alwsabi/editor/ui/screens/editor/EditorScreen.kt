package com.alwsabi.editor.ui.screens.editor

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.weight
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.FindReplace
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alwsabi.editor.AlwsabiApplication
import com.alwsabi.editor.R
import com.alwsabi.editor.ui.components.AlwsabiTopBar
import com.alwsabi.editor.ui.components.EditorFormatToolbar
import com.alwsabi.editor.ui.components.RichEditText
import com.alwsabi.editor.ui.components.rememberRichEditorController
import com.alwsabi.editor.util.FileTypeUtils
import kotlinx.coroutines.launch

@Composable
fun EditorScreen(
    initialUriString: String?,
    app: AlwsabiApplication,
    onBack: () -> Unit,
    onOpenPdfViewer: (String) -> Unit
) {
    val viewModel: EditorViewModel = viewModel(factory = EditorViewModel.Factory(app))
    val uiState by viewModel.uiState.collectAsState()
    val contentToLoad by viewModel.contentToLoad.collectAsState()
    val controller = rememberRichEditorController()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var pendingShareAfterSaveAs by remember { mutableStateOf(false) }
    var showFindReplace by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showUnsavedDialog by remember { mutableStateOf(false) }
    var menuExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(initialUriString) {
        if (initialUriString != null) {
            viewModel.openDocument(Uri.parse(initialUriString))
        } else {
            viewModel.startNewDocument()
        }
    }

    LaunchedEffect(contentToLoad) {
        contentToLoad?.let {
            controller.loadContent(it)
            viewModel.consumeContentToLoad()
        }
    }

    LaunchedEffect(uiState.statusMessage) {
        uiState.statusMessage?.let { message ->
            snackbarHostState.showSnackbar(message)
            viewModel.clearStatusMessage()
        }
    }

    LaunchedEffect(uiState.pendingPdfUriToView) {
        uiState.pendingPdfUriToView?.let {
            onOpenPdfViewer(it)
            viewModel.consumePendingPdfView()
        }
    }

    LaunchedEffect(uiState.uri, pendingShareAfterSaveAs) {
        if (pendingShareAfterSaveAs && uiState.uri != null) {
            shareDocument(context, uiState.uri!!, uiState.fileName)
            pendingShareAfterSaveAs = false
        }
    }

    LaunchedEffect(uiState.saveVersion) {
        controller.markSaved()
    }

    LaunchedEffect(Unit) {
        viewModel.startAutosaveLoop { controller.currentContent() }
    }

    val saveAsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("*/*")
    ) { uri -> if (uri != null) viewModel.completeSaveAs(uri, controller.currentContent()) }

    val pdfExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(FileTypeUtils.PDF_MIME_TYPE)
    ) { uri -> if (uri != null) viewModel.exportToPdf(uri, controller.currentContent()) }

    fun launchSaveAs() {
        val suggested = FileTypeUtils.ensureExtension(
            uiState.fileName.ifBlank { context.getString(R.string.editor_untitled) }
        )
        saveAsLauncher.launch(suggested)
    }

    fun requestBack() {
        if (controller.isModified) showUnsavedDialog = true else onBack()
    }

    BackHandler(onBack = ::requestBack)

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Column {
                AlwsabiTopBar(
                    title = uiState.fileName.ifEmpty { stringResource(R.string.editor_untitled) },
                    onBack = ::requestBack,
                    actions = {
                        IconButton(onClick = {
                            viewModel.save(controller.currentContent()) { launchSaveAs() }
                        }) {
                            Icon(Icons.Filled.Save, contentDescription = stringResource(R.string.editor_save))
                        }
                        IconButton(onClick = {
                            val uri = uiState.uri
                            if (uri != null) {
                                shareDocument(context, uri, uiState.fileName)
                            } else {
                                pendingShareAfterSaveAs = true
                                launchSaveAs()
                            }
                        }) {
                            Icon(Icons.Filled.Share, contentDescription = stringResource(R.string.editor_share))
                        }
                        IconButton(onClick = { showFindReplace = true }) {
                            Icon(Icons.Filled.FindReplace, contentDescription = stringResource(R.string.editor_find_replace))
                        }
                        IconButton(onClick = { menuExpanded = true }) {
                            Icon(Icons.Filled.MoreVert, contentDescription = stringResource(R.string.action_more))
                        }
                        DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.editor_save_as)) },
                                onClick = { menuExpanded = false; launchSaveAs() }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.editor_export_pdf)) },
                                leadingIcon = { Icon(Icons.Filled.PictureAsPdf, contentDescription = null) },
                                onClick = {
                                    menuExpanded = false
                                    val suggested = FileTypeUtils.nameWithoutExtension(
                                        uiState.fileName.ifBlank { context.getString(R.string.editor_untitled) }
                                    ) + ".pdf"
                                    pdfExportLauncher.launch(suggested)
                                }
                            )
                            if (uiState.uri != null) {
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.editor_rename)) },
                                    leadingIcon = { Icon(Icons.Filled.DriveFileRenameOutline, contentDescription = null) },
                                    onClick = { menuExpanded = false; showRenameDialog = true }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.editor_delete)) },
                                    leadingIcon = { Icon(Icons.Filled.Delete, contentDescription = null) },
                                    onClick = { menuExpanded = false; showDeleteConfirm = true }
                                )
                            }
                        }
                    }
                )
                EditorFormatToolbar(controller = controller)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            RichEditText(
                controller = controller,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                isRtl = uiState.isRtl,
                baseFontSizeSp = uiState.fontSizeSp,
                hint = stringResource(R.string.editor_hint)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = stringResource(R.string.editor_words_count, controller.wordCount),
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    text = stringResource(R.string.editor_chars_count, controller.charCount),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }

    if (showFindReplace) {
        FindReplaceDialog(
            controller = controller,
            onDismiss = { showFindReplace = false }
        )
    }

    if (showRenameDialog) {
        RenameDialog(
            currentName = uiState.fileName,
            onDismiss = { showRenameDialog = false },
            onConfirm = { newName ->
                showRenameDialog = false
                viewModel.renameCurrentDocument(newName)
            }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text(stringResource(R.string.editor_delete)) },
            text = { Text(uiState.fileName) },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirm = false
                    viewModel.deleteCurrentDocument(onDeleted = onBack)
                }) { Text(stringResource(R.string.editor_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text(stringResource(R.string.editor_cancel))
                }
            }
        )
    }

    if (showUnsavedDialog) {
        AlertDialog(
            onDismissRequest = { showUnsavedDialog = false },
            title = { Text(stringResource(R.string.editor_unsaved_changes_title)) },
            text = { Text(stringResource(R.string.editor_unsaved_changes_message)) },
            confirmButton = {
                TextButton(onClick = {
                    showUnsavedDialog = false
                    if (uiState.uri != null) {
                        scope.launch {
                            viewModel.saveBlocking(controller.currentContent())
                            onBack()
                        }
                    } else {
                        // No destination yet: open the picker and let the user
                        // press back again once the save-as completes.
                        launchSaveAs()
                    }
                }) { Text(stringResource(R.string.editor_save)) }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        showUnsavedDialog = false
                        onBack()
                    }) { Text(stringResource(R.string.editor_discard)) }
                    TextButton(onClick = { showUnsavedDialog = false }) {
                        Text(stringResource(R.string.editor_cancel))
                    }
                }
            }
        )
    }
}

private fun shareDocument(context: android.content.Context, uri: Uri, fileName: String) {
    val mime = FileTypeUtils.mimeTypeForFileName(fileName)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, fileName))
}

@Composable
private fun RenameDialog(
    currentName: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var text by remember { mutableStateOf(FileTypeUtils.nameWithoutExtension(currentName)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.editor_rename)) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                label = { Text(stringResource(R.string.editor_new_name_hint)) }
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) {
                Text(stringResource(R.string.editor_confirm))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.editor_cancel)) }
        }
    )
}

@Composable
private fun FindReplaceDialog(
    controller: com.alwsabi.editor.ui.components.RichEditorController,
    onDismiss: () -> Unit
) {
    var findText by remember { mutableStateOf("") }
    var replaceText by remember { mutableStateOf("") }
    var matches by remember { mutableStateOf(listOf<Int>()) }
    var currentIndex by remember { mutableIntStateOf(-1) }
    var infoMessage by remember { mutableStateOf<String?>(null) }

    fun refreshMatches(select: Boolean) {
        matches = controller.findAll(findText)
        currentIndex = if (matches.isEmpty()) -1 else 0
        infoMessage = null
        if (select && matches.isNotEmpty()) {
            controller.highlightAndScrollTo(matches[0], findText.length)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.editor_find_replace)) },
        text = {
            Column {
                OutlinedTextField(
                    value = findText,
                    onValueChange = {
                        findText = it
                        refreshMatches(select = false)
                    },
                    singleLine = true,
                    label = { Text(stringResource(R.string.editor_find_hint)) },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = replaceText,
                    onValueChange = { replaceText = it },
                    singleLine = true,
                    label = { Text(stringResource(R.string.editor_replace_hint)) },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
                if (findText.isNotEmpty() && matches.isEmpty()) {
                    Text(
                        text = stringResource(R.string.editor_no_matches),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                Row(modifier = Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = {
                        if (matches.isEmpty()) {
                            refreshMatches(select = true)
                        } else {
                            currentIndex = (currentIndex + 1) % matches.size
                            controller.highlightAndScrollTo(matches[currentIndex], findText.length)
                        }
                    }, enabled = findText.isNotEmpty()) {
                        Text(stringResource(R.string.editor_find_next))
                    }
                    TextButton(onClick = {
                        if (currentIndex in matches.indices) {
                            controller.replaceRange(
                                matches[currentIndex],
                                matches[currentIndex] + findText.length,
                                replaceText
                            )
                            refreshMatches(select = true)
                        }
                    }, enabled = currentIndex in matches.indices) {
                        Text(stringResource(R.string.editor_replace_one))
                    }
                    TextButton(onClick = {
                        val count = controller.replaceAllOccurrences(findText, replaceText)
                        matches = emptyList()
                        currentIndex = -1
                        infoMessage = "$count"
                    }, enabled = findText.isNotEmpty()) {
                        Text(stringResource(R.string.editor_replace_all))
                    }
                }
                infoMessage?.let { msg ->
                    Text(
                        text = "${stringResource(R.string.editor_replace_all)}: $msg",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_close)) }
        }
    )
}
