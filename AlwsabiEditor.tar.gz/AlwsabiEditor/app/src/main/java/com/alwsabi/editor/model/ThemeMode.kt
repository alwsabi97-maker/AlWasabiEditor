package com.alwsabi.editor.model

/**
 * User-selectable app theme preference, persisted via [com.alwsabi.editor.data.AppSettingsRepository].
 */
enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK;

    companion object {
        fun fromName(name: String?): ThemeMode =
            entries.firstOrNull { it.name == name } ?: SYSTEM
    }
}

/**
 * Default text direction applied when opening/creating a document.
 */
enum class TextDirectionPreference {
    AUTO,
    RTL,
    LTR;

    companion object {
        fun fromName(name: String?): TextDirectionPreference =
            entries.firstOrNull { it.name == name } ?: AUTO
    }
}
