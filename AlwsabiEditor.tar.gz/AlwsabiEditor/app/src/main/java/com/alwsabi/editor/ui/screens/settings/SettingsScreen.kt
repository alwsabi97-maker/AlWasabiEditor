package com.alwsabi.editor.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alwsabi.editor.AlwsabiApplication
import com.alwsabi.editor.BuildConfig
import com.alwsabi.editor.R
import com.alwsabi.editor.model.TextDirectionPreference
import com.alwsabi.editor.model.ThemeMode
import com.alwsabi.editor.ui.components.AlwsabiTopBar

@Composable
fun SettingsScreen(app: AlwsabiApplication, onBack: () -> Unit) {
    val viewModel: SettingsViewModel = viewModel(factory = SettingsViewModel.Factory(app))
    val settings by viewModel.settings.collectAsState()

    Scaffold(
        topBar = { AlwsabiTopBar(title = stringResource(R.string.settings_title), onBack = onBack) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            SectionTitle(stringResource(R.string.settings_theme))
            Column(Modifier.selectableGroup()) {
                ThemeOptionRow(
                    label = stringResource(R.string.settings_theme_system),
                    selected = settings.themeMode == ThemeMode.SYSTEM,
                    onClick = { viewModel.setThemeMode(ThemeMode.SYSTEM) }
                )
                ThemeOptionRow(
                    label = stringResource(R.string.settings_theme_light),
                    selected = settings.themeMode == ThemeMode.LIGHT,
                    onClick = { viewModel.setThemeMode(ThemeMode.LIGHT) }
                )
                ThemeOptionRow(
                    label = stringResource(R.string.settings_theme_dark),
                    selected = settings.themeMode == ThemeMode.DARK,
                    onClick = { viewModel.setThemeMode(ThemeMode.DARK) }
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            SectionTitle(stringResource(R.string.settings_font_size))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Slider(
                    value = settings.defaultFontSizeSp.toFloat(),
                    onValueChange = { viewModel.setFontSize(it.toInt()) },
                    valueRange = 12f..32f,
                    steps = 19,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "${settings.defaultFontSizeSp}",
                    modifier = Modifier.padding(start = 12.dp)
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            SectionTitle(stringResource(R.string.settings_text_direction))
            Column(Modifier.selectableGroup()) {
                ThemeOptionRow(
                    label = stringResource(R.string.settings_direction_auto),
                    selected = settings.textDirection == TextDirectionPreference.AUTO,
                    onClick = { viewModel.setTextDirection(TextDirectionPreference.AUTO) }
                )
                ThemeOptionRow(
                    label = stringResource(R.string.settings_direction_rtl),
                    selected = settings.textDirection == TextDirectionPreference.RTL,
                    onClick = { viewModel.setTextDirection(TextDirectionPreference.RTL) }
                )
                ThemeOptionRow(
                    label = stringResource(R.string.settings_direction_ltr),
                    selected = settings.textDirection == TextDirectionPreference.LTR,
                    onClick = { viewModel.setTextDirection(TextDirectionPreference.LTR) }
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.settings_autosave), style = MaterialTheme.typography.titleMedium)
                    Text(
                        stringResource(R.string.settings_autosave_description),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                Switch(
                    checked = settings.autoSaveEnabled,
                    onCheckedChange = { viewModel.setAutoSaveEnabled(it) }
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            SectionTitle(stringResource(R.string.settings_app_info))
            Text(
                text = stringResource(R.string.settings_version, BuildConfig.VERSION_NAME),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun ThemeOptionRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .selectable(selected = selected, onClick = onClick, role = Role.RadioButton)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = null)
        Text(text = label, modifier = Modifier.padding(start = 12.dp))
    }
}
