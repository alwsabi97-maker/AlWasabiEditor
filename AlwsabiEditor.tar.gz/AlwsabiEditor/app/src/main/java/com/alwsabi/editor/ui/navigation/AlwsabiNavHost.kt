package com.alwsabi.editor.ui.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.alwsabi.editor.AlwsabiApplication
import com.alwsabi.editor.ui.screens.about.AboutScreen
import com.alwsabi.editor.ui.screens.editor.EditorScreen
import com.alwsabi.editor.ui.screens.home.HomeScreen
import com.alwsabi.editor.ui.screens.pdf.PdfViewerScreen
import com.alwsabi.editor.ui.screens.recent.RecentDocumentsScreen
import com.alwsabi.editor.ui.screens.search.SearchScreen
import com.alwsabi.editor.ui.screens.settings.SettingsScreen
import java.net.URLDecoder
import java.net.URLEncoder

object Routes {
    const val HOME = "home"
    const val SETTINGS = "settings"
    const val ABOUT = "about"
    const val SEARCH = "search"
    const val RECENT = "recent"
    const val EDITOR_ARG_URI = "uri"
    const val EDITOR = "editor?$EDITOR_ARG_URI={$EDITOR_ARG_URI}"
    const val PDF_VIEWER_ARG_URI = "uri"
    const val PDF_VIEWER = "pdfViewer/{$PDF_VIEWER_ARG_URI}"

    fun editorRoute(uriString: String? = null): String {
        if (uriString.isNullOrEmpty()) return "editor"
        val encoded = URLEncoder.encode(uriString, "UTF-8")
        return "editor?$EDITOR_ARG_URI=$encoded"
    }

    fun pdfViewerRoute(uriString: String): String {
        val encoded = URLEncoder.encode(uriString, "UTF-8")
        return "pdfViewer/$encoded"
    }

    fun decode(value: String?): String? =
        value?.let { runCatching { URLDecoder.decode(it, "UTF-8") }.getOrNull() }
}

@Composable
fun AlwsabiNavHost(app: AlwsabiApplication, externalUri: Uri? = null) {
    val navController: NavHostController = rememberNavController()

    LaunchedEffect(externalUri) {
        if (externalUri != null) {
            navController.navigate(Routes.editorRoute(externalUri.toString()))
        }
    }

    NavHost(navController = navController, startDestination = Routes.HOME) {

        composable(Routes.HOME) {
            HomeScreen(
                onNewDocument = { navController.navigate(Routes.editorRoute()) },
                onOpenExisting = { uriString ->
                    navController.navigate(Routes.editorRoute(uriString))
                },
                onOpenRecent = { navController.navigate(Routes.RECENT) },
                onOpenSearch = { navController.navigate(Routes.SEARCH) },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) },
                onOpenAbout = { navController.navigate(Routes.ABOUT) },
                app = app
            )
        }

        composable(
            route = Routes.EDITOR,
            arguments = listOf(
                navArgument(Routes.EDITOR_ARG_URI) {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                }
            )
        ) { backStackEntry ->
            val rawUri = backStackEntry.arguments?.getString(Routes.EDITOR_ARG_URI)
            EditorScreen(
                initialUriString = Routes.decode(rawUri),
                app = app,
                onBack = { navController.popBackStack() },
                onOpenPdfViewer = { pdfUri -> navController.navigate(Routes.pdfViewerRoute(pdfUri)) }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(app = app, onBack = { navController.popBackStack() })
        }

        composable(Routes.ABOUT) {
            AboutScreen(onBack = { navController.popBackStack() })
        }

        composable(Routes.SEARCH) {
            SearchScreen(
                app = app,
                onBack = { navController.popBackStack() },
                onOpenDocument = { uriString -> navController.navigate(Routes.editorRoute(uriString)) }
            )
        }

        composable(Routes.RECENT) {
            RecentDocumentsScreen(
                app = app,
                onBack = { navController.popBackStack() },
                onOpenDocument = { uriString -> navController.navigate(Routes.editorRoute(uriString)) }
            )
        }

        composable(
            route = Routes.PDF_VIEWER,
            arguments = listOf(navArgument(Routes.PDF_VIEWER_ARG_URI) { type = NavType.StringType })
        ) { backStackEntry ->
            val rawUri = backStackEntry.arguments?.getString(Routes.PDF_VIEWER_ARG_URI)
            PdfViewerScreen(
                uriString = Routes.decode(rawUri) ?: "",
                app = app,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
