package com.alwsabi.editor.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.alwsabi.editor.model.AppSettings
import com.alwsabi.editor.model.TextDirectionPreference
import com.alwsabi.editor.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Persists and exposes the user's app-wide settings using Jetpack DataStore
 * (the modern, recommended replacement for SharedPreferences).
 */
class AppSettingsRepository(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val FONT_SIZE = intPreferencesKey("default_font_size_sp")
        val TEXT_DIRECTION = stringPreferencesKey("text_direction")
        val AUTOSAVE = booleanPreferencesKey("autosave_enabled")
    }

    val settingsFlow: Flow<AppSettings> = context.alwsabiDataStore.data.map { prefs ->
        AppSettings(
            themeMode = ThemeMode.fromName(prefs[Keys.THEME_MODE]),
            defaultFontSizeSp = prefs[Keys.FONT_SIZE] ?: 18,
            textDirection = TextDirectionPreference.fromName(prefs[Keys.TEXT_DIRECTION]),
            autoSaveEnabled = prefs[Keys.AUTOSAVE] ?: false
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.alwsabiDataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setDefaultFontSize(sizeSp: Int) {
        context.alwsabiDataStore.edit { it[Keys.FONT_SIZE] = sizeSp }
    }

    suspend fun setTextDirection(direction: TextDirectionPreference) {
        context.alwsabiDataStore.edit { it[Keys.TEXT_DIRECTION] = direction.name }
    }

    suspend fun setAutoSaveEnabled(enabled: Boolean) {
        context.alwsabiDataStore.edit { it[Keys.AUTOSAVE] = enabled }
    }
}
