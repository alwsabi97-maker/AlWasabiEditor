package com.alwsabi.editor

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.alwsabi.editor.model.ThemeMode
import com.alwsabi.editor.ui.navigation.AlwsabiNavHost
import com.alwsabi.editor.ui.theme.AlwsabiEditorTheme

/**
 * This app deliberately never crashes on startup: MainActivity itself has
 * no logic beyond wiring the theme and the navigation graph together, and
 * every screen/viewmodel below it defends against null/invalid state.
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as AlwsabiApplication
        val incomingUri: Uri? = intent?.data

        setContent {
            AlwsabiRoot(app = app, incomingUri = incomingUri)
        }
    }
}

@Composable
private fun AlwsabiRoot(app: AlwsabiApplication, incomingUri: Uri?) {
    val settings by app.settingsRepository.settingsFlow.collectAsState(initial = null)
    val themeMode = settings?.themeMode ?: ThemeMode.SYSTEM

    AlwsabiEditorTheme(themeMode = themeMode) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Box(modifier = Modifier.fillMaxSize()) {
                AlwsabiNavHost(app = app, externalUri = incomingUri)
            }
        }
    }
}
