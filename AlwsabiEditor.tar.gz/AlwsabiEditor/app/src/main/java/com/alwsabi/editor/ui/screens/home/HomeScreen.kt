package com.alwsabi.editor.ui.screens.home

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.alwsabi.editor.AlwsabiApplication
import com.alwsabi.editor.R
import com.alwsabi.editor.model.RecentDocument
import com.alwsabi.editor.util.FileTypeUtils
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    onNewDocument: () -> Unit,
    onOpenExisting: (String) -> Unit,
    onOpenRecent: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenAbout: () -> Unit,
    app: AlwsabiApplication
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            app.fileRepository.takePersistablePermission(uri)
            val name = app.fileRepository.displayNameOf(uri)
            scope.launch {
                app.recentFilesRepository.addOrUpdate(
                    RecentDocument(
                        uriString = uri.toString(),
                        displayName = name,
                        lastOpenedMillis = System.currentTimeMillis()
                    )
                )
            }
            onOpenExisting(uri.toString())
        }
    }

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Description,
                contentDescription = null,
                modifier = Modifier.size(72.dp),
                tint = MaterialTheme.colorScheme.primary
            )

            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
            )
            Text(
                text = stringResource(R.string.app_description),
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(bottom = 32.dp)
            )

            HomeActionButton(
                text = stringResource(R.string.home_new_document),
                icon = Icons.Filled.NoteAdd,
                onClick = onNewDocument,
                isPrimary = true
            )
            HomeActionButton(
                text = stringResource(R.string.home_open_file),
                icon = Icons.Filled.FolderOpen,
                onClick = { openDocumentLauncher.launch(FileTypeUtils.OPEN_MIME_TYPES) }
            )
            HomeActionButton(
                text = stringResource(R.string.home_recent_documents),
                icon = Icons.Filled.History,
                onClick = onOpenRecent
            )
            HomeActionButton(
                text = stringResource(R.string.home_search),
                icon = Icons.Filled.Search,
                onClick = onOpenSearch
            )
            HomeActionButton(
                text = stringResource(R.string.home_settings),
                icon = Icons.Filled.Settings,
                onClick = onOpenSettings
            )
            HomeActionButton(
                text = stringResource(R.string.home_about),
                icon = Icons.Filled.Info,
                onClick = onOpenAbout
            )
        }
    }
}

@Composable
private fun HomeActionButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    isPrimary: Boolean = false
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .padding(vertical = 6.dp),
        colors = if (isPrimary) {
            ButtonDefaults.buttonColors()
        } else {
            ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
            )
        }
    ) {
        Icon(imageVector = icon, contentDescription = null)
        Text(
            text = text,
            modifier = Modifier.padding(start = 12.dp),
            style = MaterialTheme.typography.titleMedium
        )
    }
}
