package com.alwsabi.editor.model

/**
 * Immutable snapshot of all user-configurable app settings.
 * Persisted through DataStore Preferences by AppSettingsRepository.
 */
data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val defaultFontSizeSp: Int = 18,
    val textDirection: TextDirectionPreference = TextDirectionPreference.AUTO,
    val autoSaveEnabled: Boolean = false
)
