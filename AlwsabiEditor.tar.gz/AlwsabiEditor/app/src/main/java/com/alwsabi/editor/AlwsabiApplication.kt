package com.alwsabi.editor

import android.app.Application
import com.alwsabi.editor.data.AppSettingsRepository
import com.alwsabi.editor.data.FileRepository
import com.alwsabi.editor.data.RecentFilesRepository

/**
 * Application-scoped container. Deliberately avoids a full DI framework
 * (Hilt/Koin) to keep the Gradle build small, fast and free of extra
 * moving parts that could fail to resolve — the app is simple enough that
 * a few lazily-created singletons are the more stable, robust choice.
 */
class AlwsabiApplication : Application() {

    val settingsRepository: AppSettingsRepository by lazy { AppSettingsRepository(this) }
    val recentFilesRepository: RecentFilesRepository by lazy { RecentFilesRepository(this) }
    val fileRepository: FileRepository by lazy { FileRepository(this) }
}
