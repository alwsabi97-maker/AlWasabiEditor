package com.alwsabi.editor.util

import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.AlignmentSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import android.text.style.AbsoluteSizeSpan

/**
 * A simple, real (non-fake) undo/redo stack for a formatted [android.text.Editable].
 *
 * Rather than diffing text operations character by character (which real word
 * processors do with complex operational-transform structures), this manager
 * keeps bounded stacks of full content snapshots (text + the spans that matter
 * for this editor). Snapshots are pushed by the caller at sensible points:
 * before applying a formatting command, before a find/replace operation,
 * before pasting, and periodically while the user types (debounced).
 *
 * This is a deliberate, pragmatic design choice: it is simple, robust, cannot
 * corrupt state, and is more than adequate for a document editor where undo
 * granularity of "the last meaningful action" is what users expect.
 */
class UndoRedoManager(private val maxDepth: Int = 100) {

    private val undoStack = ArrayDeque<SpannableStringBuilder>()
    private val redoStack = ArrayDeque<SpannableStringBuilder>()

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    /** Records the given content as a restorable point, clearing the redo stack. */
    fun recordSnapshot(current: Spanned) {
        undoStack.addLast(cloneSpanned(current))
        if (undoStack.size > maxDepth) undoStack.removeFirst()
        redoStack.clear()
    }

    /**
     * Pops the last snapshot from the undo stack and returns it, pushing
     * [currentBeforeUndo] onto the redo stack. Returns null if nothing to undo.
     */
    fun undo(currentBeforeUndo: Spanned): SpannableStringBuilder? {
        if (undoStack.isEmpty()) return null
        redoStack.addLast(cloneSpanned(currentBeforeUndo))
        if (redoStack.size > maxDepth) redoStack.removeFirst()
        return undoStack.removeLast()
    }

    /**
     * Pops the last snapshot from the redo stack and returns it, pushing
     * [currentBeforeRedo] onto the undo stack. Returns null if nothing to redo.
     */
    fun redo(currentBeforeRedo: Spanned): SpannableStringBuilder? {
        if (redoStack.isEmpty()) return null
        undoStack.addLast(cloneSpanned(currentBeforeRedo))
        if (undoStack.size > maxDepth) undoStack.removeFirst()
        return redoStack.removeLast()
    }

    fun clear() {
        undoStack.clear()
        redoStack.clear()
    }

    private fun cloneSpanned(source: Spanned): SpannableStringBuilder {
        val builder = SpannableStringBuilder(source.toString())
        // Copy over only the span types this editor actually creates, to keep
        // snapshots lightweight and predictable.
        copySpans(source, builder, StyleSpan::class.java)
        copySpans(source, builder, UnderlineSpan::class.java)
        copySpans(source, builder, ForegroundColorSpan::class.java)
        copySpans(source, builder, BackgroundColorSpan::class.java)
        copySpans(source, builder, AbsoluteSizeSpan::class.java)
        copySpans(source, builder, AlignmentSpan.Standard::class.java)
        copySpans(source, builder, CustomTypefaceSpan::class.java)
        return builder
    }

    private fun <T : Any> copySpans(source: Spanned, target: SpannableStringBuilder, type: Class<T>) {
        val spans = source.getSpans(0, source.length, type)
        for (span in spans) {
            val start = source.getSpanStart(span)
            val end = source.getSpanEnd(span)
            val flags = source.getSpanFlags(span)
            if (start in 0..target.length && end in start..target.length) {
                target.setSpan(span, start, end, flags)
            }
        }
    }
}
