package com.alwsabi.editor.ui.screens.pdf

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alwsabi.editor.AlwsabiApplication
import com.alwsabi.editor.R
import com.alwsabi.editor.ui.components.AlwsabiTopBar
import com.alwsabi.editor.util.FileTypeUtils

@Composable
fun PdfViewerScreen(
    uriString: String,
    app: AlwsabiApplication,
    onBack: () -> Unit
) {
    val viewModel: PdfViewerViewModel = viewModel(factory = PdfViewerViewModel.Factory(app))
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val failureMessage = stringResource(R.string.pdf_load_failed)

    LaunchedEffect(uriString) {
        if (uriString.isNotEmpty()) {
            viewModel.load(Uri.parse(uriString), failureMessage)
        }
    }

    Scaffold(
        topBar = {
            AlwsabiTopBar(
                title = stringResource(R.string.pdf_viewer_title),
                onBack = onBack,
                actions = {
                    IconButton(onClick = {
                        val uri = Uri.parse(uriString)
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = FileTypeUtils.PDF_MIME_TYPE
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(intent, null))
                    }) {
                        Icon(Icons.Filled.Share, contentDescription = stringResource(R.string.pdf_share))
                    }
                }
            )
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when {
                uiState.isLoading -> {
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                }
                uiState.errorMessage != null -> {
                    Text(
                        text = uiState.errorMessage.orEmpty(),
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.align(Alignment.Center).padding(24.dp)
                    )
                }
                else -> {
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(uiState.pages.size) { index ->
                            val bitmap = uiState.pages[index]
                            Text(
                                text = stringResource(R.string.pdf_page_of, index + 1, uiState.pages.size),
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(top = 12.dp, start = 16.dp)
                            )
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = null,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
