package com.alwsabi.editor.ui.screens.editor

import android.app.Application
import android.net.Uri
import android.text.SpannableStringBuilder
import android.text.Spanned
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.alwsabi.editor.AlwsabiApplication
import com.alwsabi.editor.R
import com.alwsabi.editor.model.RecentDocument
import com.alwsabi.editor.model.TextDirectionPreference
import com.alwsabi.editor.util.FileTypeUtils
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class EditorUiState(
    val uri: Uri? = null,
    val fileName: String = "",
    val isNewDocument: Boolean = true,
    val isLoading: Boolean = false,
    val isRtl: Boolean = true,
    val fontSizeSp: Int = 18,
    val autoSaveEnabled: Boolean = false,
    val statusMessage: String? = null,
    val pendingPdfUriToView: String? = null,
    /** Incremented on every successful write (manual save, save-as, or autosave). */
    val saveVersion: Int = 0
)

class EditorViewModel(private val app: AlwsabiApplication) : AndroidViewModel(app) {

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    /** Exposes the currently loaded plain text once, for the UI to push into the controller. */
    private val _contentToLoad = MutableStateFlow<Spanned?>(null)
    val contentToLoad: StateFlow<Spanned?> = _contentToLoad.asStateFlow()

    private var autosaveContentProvider: (() -> Spanned)? = null

    init {
        viewModelScope.launch {
            app.settingsRepository.settingsFlow.collect { settings ->
                _uiState.update {
                    val resolvedRtl = when (settings.textDirection) {
                        TextDirectionPreference.RTL -> true
                        TextDirectionPreference.LTR -> false
                        TextDirectionPreference.AUTO -> it.isRtl
                    }
                    it.copy(
                        fontSizeSp = if (it.uri == null && it.isNewDocument) settings.defaultFontSizeSp else it.fontSizeSp,
                        isRtl = if (it.uri == null && it.isNewDocument) resolvedRtl else it.isRtl,
                        autoSaveEnabled = settings.autoSaveEnabled
                    )
                }
            }
        }
    }

    fun startNewDocument() {
        _uiState.update {
            it.copy(
                uri = null,
                fileName = getApplication<Application>().getString(R.string.editor_untitled),
                isNewDocument = true
            )
        }
        _contentToLoad.value = SpannableStringBuilder("")
    }

    fun openDocument(uri: Uri) {
        _uiState.update { it.copy(isLoading = true) }
        viewModelScope.launch {
            val result = app.fileRepository.readText(uri)
            result.onSuccess { text ->
                val name = app.fileRepository.displayNameOf(uri)
                _uiState.update {
                    it.copy(
                        uri = uri,
                        fileName = name,
                        isNewDocument = false,
                        isLoading = false,
                        statusMessage = null
                    )
                }
                app.fileRepository.takePersistablePermission(uri)
                app.recentFilesRepository.addOrUpdate(
                    RecentDocument(uri.toString(), name, System.currentTimeMillis())
                )
                _contentToLoad.value = SpannableStringBuilder(text)
            }.onFailure {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        statusMessage = getApplication<Application>().getString(R.string.editor_open_failed)
                    )
                }
            }
        }
    }

    fun consumeContentToLoad() {
        _contentToLoad.value = null
    }

    fun clearStatusMessage() {
        _uiState.update { it.copy(statusMessage = null) }
    }

    fun setDirection(isRtl: Boolean) {
        _uiState.update { it.copy(isRtl = isRtl) }
    }

    fun setFontSize(sp: Int) {
        _uiState.update { it.copy(fontSizeSp = sp) }
    }

    /**
     * Core write operation, awaited to completion. Used directly by callers that
     * need to know the save has actually finished before doing something else
     * (e.g. navigating back), and internally by the fire-and-forget [save].
     */
    suspend fun saveBlocking(content: Spanned): Boolean {
        val uri = _uiState.value.uri ?: return false
        val result = app.fileRepository.writeText(uri, content.toString())
        val message = getApplication<Application>().getString(
            if (result.isSuccess) R.string.editor_saved_success else R.string.editor_save_failed
        )
        _uiState.update {
            it.copy(
                statusMessage = message,
                saveVersion = if (result.isSuccess) it.saveVersion + 1 else it.saveVersion
            )
        }
        if (result.isSuccess) {
            app.recentFilesRepository.addOrUpdate(
                RecentDocument(uri.toString(), _uiState.value.fileName, System.currentTimeMillis())
            )
        }
        return result.isSuccess
    }

    /** Fire-and-forget save for the toolbar Save button; falls back to Save As if there's no Uri yet. */
    fun save(content: Spanned, onNeedsSaveAs: () -> Unit) {
        if (_uiState.value.uri == null) {
            onNeedsSaveAs()
            return
        }
        viewModelScope.launch { saveBlocking(content) }
    }

    /** Called once the user picked a destination Uri via the SAF "create document" picker. */
    fun completeSaveAs(newUri: Uri, content: Spanned) {
        app.fileRepository.takePersistablePermission(newUri)
        val name = app.fileRepository.displayNameOf(newUri)
        viewModelScope.launch {
            val result = app.fileRepository.writeText(newUri, content.toString())
            val message = getApplication<Application>().getString(
                if (result.isSuccess) R.string.editor_saved_success else R.string.editor_save_failed
            )
            _uiState.update {
                it.copy(
                    uri = if (result.isSuccess) newUri else it.uri,
                    fileName = if (result.isSuccess) name else it.fileName,
                    isNewDocument = if (result.isSuccess) false else it.isNewDocument,
                    statusMessage = message,
                    saveVersion = if (result.isSuccess) it.saveVersion + 1 else it.saveVersion
                )
            }
            if (result.isSuccess) {
                app.recentFilesRepository.addOrUpdate(
                    RecentDocument(newUri.toString(), name, System.currentTimeMillis())
                )
            }
        }
    }

    fun renameCurrentDocument(newName: String) {
        val uri = _uiState.value.uri ?: return
        val finalName = FileTypeUtils.ensureExtension(newName)
        viewModelScope.launch {
            val result = app.fileRepository.renameDocument(uri, finalName)
            result.onSuccess { newUri ->
                app.fileRepository.takePersistablePermission(newUri)
                val displayName = app.fileRepository.displayNameOf(newUri)
                _uiState.update {
                    it.copy(
                        uri = newUri,
                        fileName = displayName,
                        statusMessage = getApplication<Application>().getString(R.string.editor_rename_success)
                    )
                }
                app.recentFilesRepository.remove(uri.toString())
                app.recentFilesRepository.addOrUpdate(
                    RecentDocument(newUri.toString(), displayName, System.currentTimeMillis())
                )
            }.onFailure {
                _uiState.update {
                    it.copy(statusMessage = getApplication<Application>().getString(R.string.editor_rename_failed))
                }
            }
        }
    }

    fun deleteCurrentDocument(onDeleted: () -> Unit) {
        val uri = _uiState.value.uri ?: return
        viewModelScope.launch {
            val result = app.fileRepository.deleteDocument(uri)
            result.onSuccess {
                app.recentFilesRepository.remove(uri.toString())
                onDeleted()
            }.onFailure {
                _uiState.update {
                    it.copy(statusMessage = getApplication<Application>().getString(R.string.editor_delete_failed))
                }
            }
        }
    }

    fun exportToPdf(destinationUri: Uri, content: Spanned) {
        viewModelScope.launch {
            val result = app.fileRepository.exportToPdf(
                uri = destinationUri,
                content = content,
                baseTextSizeSp = _uiState.value.fontSizeSp.toFloat(),
                isRtl = _uiState.value.isRtl
            )
            val message = getApplication<Application>().getString(
                if (result.isSuccess) R.string.editor_pdf_export_success else R.string.editor_pdf_export_failed
            )
            _uiState.update {
                it.copy(
                    statusMessage = message,
                    pendingPdfUriToView = if (result.isSuccess) destinationUri.toString() else null
                )
            }
        }
    }

    fun consumePendingPdfView() {
        _uiState.update { it.copy(pendingPdfUriToView = null) }
    }

    /**
     * Starts an autosave loop that, every 30 seconds while auto-save is enabled
     * and the document already has a destination Uri, writes the latest content
     * (pulled lazily via [provider], to avoid the ViewModel holding a View).
     */
    fun startAutosaveLoop(provider: () -> Spanned) {
        autosaveContentProvider = provider
        viewModelScope.launch {
            while (isActive) {
                delay(30_000L)
                val state = _uiState.value
                val uri = state.uri
                if (state.autoSaveEnabled && uri != null) {
                    val content = autosaveContentProvider?.invoke() ?: continue
                    val result = app.fileRepository.writeText(uri, content.toString())
                    if (result.isSuccess) {
                        _uiState.update {
                            it.copy(
                                statusMessage = getApplication<Application>().getString(R.string.editor_autosaved),
                                saveVersion = it.saveVersion + 1
                            )
                        }
                    }
                }
            }
        }
    }

    class Factory(private val app: AlwsabiApplication) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return EditorViewModel(app) as T
        }
    }
}
