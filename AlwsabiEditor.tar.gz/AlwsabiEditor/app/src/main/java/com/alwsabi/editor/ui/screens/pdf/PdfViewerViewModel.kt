package com.alwsabi.editor.ui.screens.pdf

import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.alwsabi.editor.AlwsabiApplication
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PdfViewerUiState(
    val isLoading: Boolean = true,
    val pages: List<Bitmap> = emptyList(),
    val errorMessage: String? = null
)

class PdfViewerViewModel(private val app: AlwsabiApplication) : ViewModel() {

    private val _uiState = MutableStateFlow(PdfViewerUiState())
    val uiState: StateFlow<PdfViewerUiState> = _uiState.asStateFlow()

    fun load(uri: Uri, failureMessage: String) {
        _uiState.update { it.copy(isLoading = true, errorMessage = null) }
        viewModelScope.launch {
            val result = app.fileRepository.renderPdfPages(uri)
            result.onSuccess { bitmaps ->
                _uiState.update { it.copy(isLoading = false, pages = bitmaps, errorMessage = null) }
            }.onFailure {
                _uiState.update { it.copy(isLoading = false, pages = emptyList(), errorMessage = failureMessage) }
            }
        }
    }

    class Factory(private val app: AlwsabiApplication) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = PdfViewerViewModel(app) as T
    }
}
