package com.alwsabi.editor.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.alwsabi.editor.model.ThemeMode

private val LightColors = lightColorScheme(
    primary = TealPrimary,
    onPrimary = Color.White,
    primaryContainer = TealContainerLight,
    secondary = TealSecondary,
    background = BackgroundLight,
    surface = SurfaceLight,
    onBackground = OnLight,
    onSurface = OnLight,
    error = ErrorRed,
    errorContainer = ErrorContainerLight
)

private val DarkColors = darkColorScheme(
    primary = TealPrimaryDark,
    onPrimary = OnDark,
    primaryContainer = TealContainerDark,
    secondary = TealSecondary,
    background = BackgroundDark,
    surface = SurfaceDark,
    onBackground = OnDark,
    onSurface = OnDark,
    error = ErrorRed
)

@Composable
fun AlwsabiEditorTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val useDark = when (themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val colorScheme = if (useDark) DarkColors else LightColors

    // The whole app is Arabic-first, so layout direction is forced RTL
    // regardless of the device's own locale, per the product requirement.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AlwsabiTypography,
            content = content
        )
    }
}
