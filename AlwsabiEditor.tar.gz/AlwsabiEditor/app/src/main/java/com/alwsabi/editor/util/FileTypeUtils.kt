package com.alwsabi.editor.util

/**
 * Central place describing which document types the editor supports,
 * and how they map to MIME types / SAF picker filters.
 */
object FileTypeUtils {

    /** MIME types accepted when opening an existing text document. */
    val OPEN_MIME_TYPES: Array<String> = arrayOf(
        "text/plain",
        "application/json",
        "text/csv",
        "text/markdown",
        "text/xml",
        "application/xml",
        "text/html"
    )

    /** Default MIME type used when creating a brand-new plain text document. */
    const val DEFAULT_MIME_TYPE = "text/plain"

    const val PDF_MIME_TYPE = "application/pdf"

    private val extensionToMime = mapOf(
        "txt" to "text/plain",
        "json" to "application/json",
        "csv" to "text/csv",
        "md" to "text/markdown",
        "markdown" to "text/markdown",
        "xml" to "text/xml",
        "html" to "text/html",
        "htm" to "text/html"
    )

    fun mimeTypeForFileName(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return extensionToMime[ext] ?: DEFAULT_MIME_TYPE
    }

    fun isSupportedTextFile(name: String): Boolean {
        val ext = name.substringAfterLast('.', "").lowercase()
        return extensionToMime.containsKey(ext)
    }

    /** Ensures a user-provided file name has a valid supported extension, defaulting to .txt */
    fun ensureExtension(name: String): String {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return "مستند جديد.txt"
        val ext = trimmed.substringAfterLast('.', "")
        return if (ext.isNotEmpty() && extensionToMime.containsKey(ext.lowercase())) {
            trimmed
        } else {
            "$trimmed.txt"
        }
    }

    fun nameWithoutExtension(name: String): String =
        name.substringBeforeLast('.', name)
}
