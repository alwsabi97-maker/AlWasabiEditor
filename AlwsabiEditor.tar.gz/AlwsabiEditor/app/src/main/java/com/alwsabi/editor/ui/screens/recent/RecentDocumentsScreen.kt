package com.alwsabi.editor.ui.screens.recent

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.alwsabi.editor.AlwsabiApplication
import com.alwsabi.editor.R
import com.alwsabi.editor.ui.components.AlwsabiTopBar
import kotlinx.coroutines.launch

@Composable
fun RecentDocumentsScreen(
    app: AlwsabiApplication,
    onBack: () -> Unit,
    onOpenDocument: (String) -> Unit
) {
    val recentDocuments by app.recentFilesRepository.recentDocumentsFlow.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = { AlwsabiTopBar(title = stringResource(R.string.recent_title), onBack = onBack) }
    ) { padding ->
        if (recentDocuments.isEmpty()) {
            Box(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(R.string.recent_empty),
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        } else {
            LazyColumn(modifier = Modifier.padding(padding).fillMaxSize()) {
                items(recentDocuments, key = { it.uriString }) { doc ->
                    ListItem(
                        headlineContent = { Text(doc.displayName) },
                        leadingContent = { Icon(Icons.Filled.Description, contentDescription = null) },
                        trailingContent = {
                            IconButton(onClick = {
                                scope.launch { app.recentFilesRepository.remove(doc.uriString) }
                            }) {
                                Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.recent_remove))
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenDocument(doc.uriString) }
                            .padding(horizontal = 4.dp)
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}
