package com.alwsabi.editor.ui.components

import android.graphics.Typeface
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatAlignLeft
import androidx.compose.material.icons.filled.FormatAlignRight
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatColorFill
import androidx.compose.material.icons.filled.FormatColorText
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.FormatUnderlined
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import android.text.Layout
import com.alwsabi.editor.R

private data class ColorOption(val nameRes: Int, val color: Color?)

private val COLOR_OPTIONS = listOf(
    ColorOption(R.string.color_none, null),
    ColorOption(R.string.color_black, Color(0xFF000000)),
    ColorOption(R.string.color_red, Color(0xFFD32F2F)),
    ColorOption(R.string.color_green, Color(0xFF2E7D32)),
    ColorOption(R.string.color_blue, Color(0xFF1565C0)),
    ColorOption(R.string.color_orange, Color(0xFFEF6C00)),
    ColorOption(R.string.color_purple, Color(0xFF6A1B9A)),
    ColorOption(R.string.color_yellow, Color(0xFFF9A825)),
    ColorOption(R.string.color_white, Color(0xFFFFFFFF))
)

private val FONT_SIZES = listOf(14, 16, 18, 20, 24, 28, 32)

/**
 * Toolbar of formatting actions bound directly to a [RichEditorController].
 * Every button performs a real, working operation on the underlying Editable.
 */
@Composable
fun EditorFormatToolbar(controller: RichEditorController, modifier: Modifier = Modifier) {
    var fontSizeMenuOpen by remember { mutableStateOf(false) }
    var textColorMenuOpen by remember { mutableStateOf(false) }
    var bgColorMenuOpen by remember { mutableStateOf(false) }
    var fontFamilyMenuOpen by remember { mutableStateOf(false) }

    Surface(tonalElevation = 2.dp, modifier = modifier) {
        Row(
            modifier = Modifier
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 4.dp, vertical = 4.dp)
        ) {
            IconButton(onClick = { controller.undo() }, enabled = controller.canUndo) {
                Icon(Icons.Filled.Undo, contentDescription = stringResource(R.string.editor_undo))
            }
            IconButton(onClick = { controller.redo() }, enabled = controller.canRedo) {
                Icon(Icons.Filled.Redo, contentDescription = stringResource(R.string.editor_redo))
            }

            IconButton(onClick = { controller.toggleBold() }) {
                Icon(Icons.Filled.FormatBold, contentDescription = stringResource(R.string.editor_bold))
            }
            IconButton(onClick = { controller.toggleItalic() }) {
                Icon(Icons.Filled.FormatItalic, contentDescription = stringResource(R.string.editor_italic))
            }
            IconButton(onClick = { controller.toggleUnderline() }) {
                Icon(Icons.Filled.FormatUnderlined, contentDescription = stringResource(R.string.editor_underline))
            }

            IconButton(onClick = { controller.applyAlignment(Layout.Alignment.ALIGN_NORMAL) }) {
                Icon(Icons.Filled.FormatAlignRight, contentDescription = stringResource(R.string.editor_align_right))
            }
            IconButton(onClick = { controller.applyAlignment(Layout.Alignment.ALIGN_CENTER) }) {
                Icon(Icons.Filled.FormatAlignCenter, contentDescription = stringResource(R.string.editor_align_center))
            }
            IconButton(onClick = { controller.applyAlignment(Layout.Alignment.ALIGN_OPPOSITE) }) {
                Icon(Icons.Filled.FormatAlignLeft, contentDescription = stringResource(R.string.editor_align_left))
            }

            Spacer(modifier = Modifier.width(4.dp))

            Box {
                IconButton(onClick = { fontSizeMenuOpen = true }) {
                    Icon(Icons.Filled.FormatSize, contentDescription = stringResource(R.string.editor_font_size))
                }
                DropdownMenu(expanded = fontSizeMenuOpen, onDismissRequest = { fontSizeMenuOpen = false }) {
                    FONT_SIZES.forEach { size ->
                        DropdownMenuItem(
                            text = { Text("$size") },
                            onClick = {
                                controller.applyFontSize(size)
                                fontSizeMenuOpen = false
                            }
                        )
                    }
                }
            }

            Box {
                IconButton(onClick = { fontFamilyMenuOpen = true }) {
                    Icon(Icons.Filled.TextFields, contentDescription = stringResource(R.string.editor_font_family))
                }
                DropdownMenu(expanded = fontFamilyMenuOpen, onDismissRequest = { fontFamilyMenuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.font_default)) },
                        onClick = {
                            controller.applyFontFamily(Typeface.DEFAULT)
                            fontFamilyMenuOpen = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.font_serif)) },
                        onClick = {
                            controller.applyFontFamily(Typeface.SERIF)
                            fontFamilyMenuOpen = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.font_sans_serif)) },
                        onClick = {
                            controller.applyFontFamily(Typeface.SANS_SERIF)
                            fontFamilyMenuOpen = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.font_monospace)) },
                        onClick = {
                            controller.applyFontFamily(Typeface.MONOSPACE)
                            fontFamilyMenuOpen = false
                        }
                    )
                }
            }

            Box {
                IconButton(onClick = { textColorMenuOpen = true }) {
                    Icon(Icons.Filled.FormatColorText, contentDescription = stringResource(R.string.editor_text_color))
                }
                DropdownMenu(expanded = textColorMenuOpen, onDismissRequest = { textColorMenuOpen = false }) {
                    COLOR_OPTIONS.forEach { option ->
                        DropdownMenuItem(
                            text = { ColorMenuRow(option) },
                            onClick = {
                                controller.applyTextColor(option.color?.toArgb())
                                textColorMenuOpen = false
                            }
                        )
                    }
                }
            }

            Box {
                IconButton(onClick = { bgColorMenuOpen = true }) {
                    Icon(Icons.Filled.FormatColorFill, contentDescription = stringResource(R.string.editor_background_color))
                }
                DropdownMenu(expanded = bgColorMenuOpen, onDismissRequest = { bgColorMenuOpen = false }) {
                    COLOR_OPTIONS.forEach { option ->
                        DropdownMenuItem(
                            text = { ColorMenuRow(option) },
                            onClick = {
                                controller.applyBackgroundColor(option.color?.toArgb())
                                bgColorMenuOpen = false
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ColorMenuRow(option: ColorOption) {
    Row {
        if (option.color != null) {
            Surface(
                color = option.color,
                shape = CircleShape,
                modifier = Modifier
                    .size(18.dp)
                    .clip(CircleShape)
            ) {}
            Spacer(modifier = Modifier.width(8.dp))
        }
        Text(stringResource(option.nameRes))
    }
}
