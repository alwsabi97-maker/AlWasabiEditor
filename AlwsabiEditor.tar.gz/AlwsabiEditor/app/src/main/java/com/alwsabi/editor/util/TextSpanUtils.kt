package com.alwsabi.editor.util

import android.graphics.Paint
import android.graphics.Typeface
import android.text.Editable
import android.text.Layout
import android.text.Spanned
import android.text.style.AlignmentSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import android.text.style.AbsoluteSizeSpan
import android.text.style.MetricAffectingSpan

/**
 * A portable typeface span that works on every API level supported by this app
 * (the built-in android.text.style.TypefaceSpan(Typeface) constructor only exists
 * from API 28 onward, so we implement the classic MetricAffectingSpan approach
 * which has worked since API 1).
 */
class CustomTypefaceSpan(val typeface: Typeface) : MetricAffectingSpan() {
    override fun updateMeasureState(paint: Paint) = apply(paint)
    override fun updateDrawState(paint: android.text.TextPaint) = apply(paint)

    private fun apply(paint: Paint) {
        val old = paint.typeface
        val oldStyle = old?.style ?: 0
        val fakeStyle = oldStyle and typeface.style.inv()

        if (fakeStyle and Typeface.BOLD != 0) paint.isFakeBoldText = true
        if (fakeStyle and Typeface.ITALIC != 0) paint.textSkewX = -0.25f

        paint.typeface = typeface
    }
}

/** Returns true if any part of [start, end) already carries a span of type [T]. */
inline fun <reified T> Spanned.hasSpanIn(start: Int, end: Int): Boolean {
    if (start == end) {
        // No selection: check the span at the cursor position (look one char back if possible).
        val pos = if (start > 0) start - 1 else start
        return getSpans(pos, pos + 1, T::class.java).isNotEmpty()
    }
    return getSpans(start, end, T::class.java).isNotEmpty()
}

/** Toggles a StyleSpan(style) over the given range: removes if fully present, otherwise adds. */
fun Editable.toggleStyleSpan(start: Int, end: Int, style: Int) {
    if (start == end) return
    val existing = getSpans(start, end, StyleSpan::class.java).filter { it.style == style }
    if (existing.isNotEmpty()) {
        existing.forEach { removeSpan(it) }
    } else {
        setSpan(StyleSpan(style), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
}

fun Editable.toggleUnderline(start: Int, end: Int) {
    if (start == end) return
    val existing = getSpans(start, end, UnderlineSpan::class.java)
    if (existing.isNotEmpty()) {
        existing.forEach { removeSpan(it) }
    } else {
        setSpan(UnderlineSpan(), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
}

fun Editable.applyForegroundColor(start: Int, end: Int, color: Int?) {
    if (start == end) return
    getSpans(start, end, ForegroundColorSpan::class.java).forEach { removeSpan(it) }
    if (color != null) {
        setSpan(ForegroundColorSpan(color), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
}

fun Editable.applyBackgroundColor(start: Int, end: Int, color: Int?) {
    if (start == end) return
    getSpans(start, end, BackgroundColorSpan::class.java).forEach { removeSpan(it) }
    if (color != null) {
        setSpan(BackgroundColorSpan(color), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
}

fun Editable.applyFontSize(start: Int, end: Int, sizeSp: Int) {
    if (start == end) return
    getSpans(start, end, AbsoluteSizeSpan::class.java).forEach { removeSpan(it) }
    setSpan(AbsoluteSizeSpan(sizeSp, true), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
}

fun Editable.applyTypeface(start: Int, end: Int, typeface: Typeface) {
    if (start == end) return
    getSpans(start, end, CustomTypefaceSpan::class.java).forEach { removeSpan(it) }
    setSpan(CustomTypefaceSpan(typeface), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
}

/**
 * Applies paragraph alignment to every paragraph touched by [start, end).
 * A "paragraph" is the run of text between newline characters.
 */
fun Editable.applyAlignment(start: Int, end: Int, alignment: Layout.Alignment) {
    val text = this
    var paraStart = start
    while (paraStart > 0 && text[paraStart - 1] != '\n') paraStart--
    var paraEnd = if (end > start) end else start
    while (paraEnd < text.length && text[paraEnd] != '\n') paraEnd++

    // Walk through all paragraphs within [paraStart, paraEnd]
    var cursor = paraStart
    while (cursor <= paraEnd) {
        var lineEnd = cursor
        while (lineEnd < text.length && text[lineEnd] != '\n') lineEnd++
        val safeLineEnd = lineEnd.coerceAtMost(text.length)
        val safeCursor = cursor.coerceAtMost(safeLineEnd)

        getSpans(safeCursor, safeLineEnd, AlignmentSpan.Standard::class.java).forEach { removeSpan(it) }
        setSpan(
            AlignmentSpan.Standard(alignment),
            safeCursor,
            safeLineEnd.coerceAtLeast(safeCursor),
            Spanned.SPAN_INCLUSIVE_INCLUSIVE
        )
        cursor = lineEnd + 1
        if (lineEnd == text.length) break
    }
}

fun countWords(text: CharSequence): Int {
    val trimmed = text.trim()
    if (trimmed.isEmpty()) return 0
    return trimmed.split(Regex("\\s+")).count { it.isNotBlank() }
}
