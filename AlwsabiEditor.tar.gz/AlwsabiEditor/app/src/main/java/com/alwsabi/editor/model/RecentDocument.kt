package com.alwsabi.editor.model

/**
 * A single entry in the "recent documents" list.
 *
 * [uriString] is the persisted content:// Uri (as a string) of the document,
 * obtained through the Storage Access Framework. [lastOpenedMillis] is used
 * to sort the list newest-first.
 */
data class RecentDocument(
    val uriString: String,
    val displayName: String,
    val lastOpenedMillis: Long
)

/** Field/record separators used to serialize a list of [RecentDocument] into one DataStore string. */
internal const val RECENT_FIELD_SEPARATOR = "\u0001"
internal const val RECENT_RECORD_SEPARATOR = "\u0002"

fun RecentDocument.serialize(): String =
    listOf(uriString, displayName, lastOpenedMillis.toString()).joinToString(RECENT_FIELD_SEPARATOR)

fun String.toRecentDocumentOrNull(): RecentDocument? {
    val parts = split(RECENT_FIELD_SEPARATOR)
    if (parts.size != 3) return null
    val millis = parts[2].toLongOrNull() ?: return null
    return RecentDocument(uriString = parts[0], displayName = parts[1], lastOpenedMillis = millis)
}

fun List<RecentDocument>.serializeAll(): String =
    joinToString(RECENT_RECORD_SEPARATOR) { it.serialize() }

fun String.toRecentDocumentList(): List<RecentDocument> {
    if (isBlank()) return emptyList()
    return split(RECENT_RECORD_SEPARATOR).mapNotNull { it.toRecentDocumentOrNull() }
}
