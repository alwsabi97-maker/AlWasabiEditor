package com.alwsabi.editor.data

import android.content.Context
import androidx.datastore.preferences.preferencesDataStore

/** Single DataStore instance shared by settings and recent-files persistence. */
val Context.alwsabiDataStore by preferencesDataStore(name = "alwsabi_editor_prefs")
