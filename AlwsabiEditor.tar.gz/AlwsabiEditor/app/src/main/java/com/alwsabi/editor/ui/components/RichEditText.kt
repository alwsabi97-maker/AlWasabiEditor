package com.alwsabi.editor.ui.components

import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import android.util.TypedValue
import android.view.View
import android.widget.EditText
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.alwsabi.editor.util.UndoRedoManager
import com.alwsabi.editor.util.applyAlignment
import com.alwsabi.editor.util.applyBackgroundColor
import com.alwsabi.editor.util.applyFontSize
import com.alwsabi.editor.util.applyForegroundColor
import com.alwsabi.editor.util.applyTypeface
import com.alwsabi.editor.util.countWords
import com.alwsabi.editor.util.toggleStyleSpan
import com.alwsabi.editor.util.toggleUnderline

/**
 * Owns the live [EditText] instance and all formatting/undo-redo operations
 * performed on it. Created once per editor screen and survives recomposition
 * via `remember`. Deliberately not a ViewModel: it holds a View reference,
 * which must never outlive the Composable that created it.
 */
class RichEditorController {

    internal var editText: EditText? = null
    internal val undoRedo = UndoRedoManager()

    var wordCount by mutableIntStateOf(0)
        internal set
    var charCount by mutableIntStateOf(0)
        internal set
    var canUndo by mutableStateOf(false)
        internal set
    var canRedo by mutableStateOf(false)
        internal set
    var isModified by mutableStateOf(false)
        internal set

    /** Clears the modified flag after a successful save; does not touch undo history. */
    fun markSaved() {
        isModified = false
    }

    private var snapshotHandler: Handler? = null
    private var pendingSnapshot: Runnable? = null
    private var suppressWatcher = false
    var onUserEdit: (() -> Unit)? = null

    /** Replaces the whole document content, resetting undo history and modified flag. */
    fun loadContent(content: Spanned) {
        val et = editText ?: return
        suppressWatcher = true
        et.text = SpannableStringBuilder(content)
        suppressWatcher = false
        undoRedo.clear()
        isModified = false
        updateCounts()
        updateUndoRedoFlags()
    }

    fun currentContent(): Editable = editText?.text ?: SpannableStringBuilder()

    fun currentPlainText(): String = editText?.text?.toString() ?: ""

    fun selectAll() {
        editText?.let { it.setSelection(0, it.text.length) }
    }

    private fun selectionRange(): Pair<Int, Int>? {
        val et = editText ?: return null
        val start = et.selectionStart.coerceAtLeast(0)
        val end = et.selectionEnd.coerceAtLeast(0)
        return if (start <= end) start to end else end to start
    }

    private fun recordSnapshot() {
        val et = editText ?: return
        undoRedo.recordSnapshot(et.text)
        updateUndoRedoFlags()
    }

    fun toggleBold() = withSelection { start, end ->
        recordSnapshot()
        currentContent().toggleStyleSpan(start, end, Typeface.BOLD)
    }

    fun toggleItalic() = withSelection { start, end ->
        recordSnapshot()
        currentContent().toggleStyleSpan(start, end, Typeface.ITALIC)
    }

    fun toggleUnderline() = withSelection { start, end ->
        recordSnapshot()
        currentContent().toggleUnderline(start, end)
    }

    fun isBoldActive(): Boolean {
        val (start, end) = selectionRange() ?: return false
        val checkPos = if (start == end && start > 0) start - 1 else start
        return currentContent().getSpans(checkPos, end.coerceAtLeast(checkPos), StyleSpan::class.java)
            .any { it.style == Typeface.BOLD }
    }

    fun isItalicActive(): Boolean {
        val (start, end) = selectionRange() ?: return false
        val checkPos = if (start == end && start > 0) start - 1 else start
        return currentContent().getSpans(checkPos, end.coerceAtLeast(checkPos), StyleSpan::class.java)
            .any { it.style == Typeface.ITALIC }
    }

    fun isUnderlineActive(): Boolean {
        val (start, end) = selectionRange() ?: return false
        val checkPos = if (start == end && start > 0) start - 1 else start
        return currentContent().getSpans(checkPos, end.coerceAtLeast(checkPos), UnderlineSpan::class.java)
            .isNotEmpty()
    }

    fun applyAlignment(alignment: Layout.Alignment) = withSelection { start, end ->
        recordSnapshot()
        currentContent().applyAlignment(start, end, alignment)
    }

    fun applyFontSize(sizeSp: Int) = withSelection { start, end ->
        recordSnapshot()
        currentContent().applyFontSize(start, end, sizeSp)
    }

    fun applyTextColor(colorArgb: Int?) = withSelection { start, end ->
        recordSnapshot()
        currentContent().applyForegroundColor(start, end, colorArgb)
    }

    fun applyBackgroundColor(colorArgb: Int?) = withSelection { start, end ->
        recordSnapshot()
        currentContent().applyBackgroundColor(start, end, colorArgb)
    }

    fun applyFontFamily(typeface: Typeface) = withSelection { start, end ->
        recordSnapshot()
        currentContent().applyTypeface(start, end, typeface)
    }

    /**
     * Runs [block] with the current selection range. Character-level formatting
     * (bold/italic/underline/color/size/font) is a no-op when nothing is
     * selected — each of those span helpers already guards on start == end.
     * Paragraph-level formatting (alignment) works fine from the caret alone,
     * since it only needs a position to find the enclosing paragraph.
     */
    private inline fun withSelection(block: (start: Int, end: Int) -> Unit) {
        val (start, end) = selectionRange() ?: return
        block(start, end)
    }

    fun undo() {
        val et = editText ?: return
        val restored = undoRedo.undo(et.text) ?: return
        suppressWatcher = true
        et.text = restored
        suppressWatcher = false
        et.setSelection(restored.length)
        isModified = true
        updateCounts()
        updateUndoRedoFlags()
    }

    fun redo() {
        val et = editText ?: return
        val restored = undoRedo.redo(et.text) ?: return
        suppressWatcher = true
        et.text = restored
        suppressWatcher = false
        et.setSelection(restored.length)
        isModified = true
        updateCounts()
        updateUndoRedoFlags()
    }

    /** Returns the start index of every occurrence of [query] (case-insensitive). */
    fun findAll(query: String): List<Int> {
        if (query.isEmpty()) return emptyList()
        val text = currentPlainText()
        val results = mutableListOf<Int>()
        var index = text.indexOf(query, 0, ignoreCase = true)
        while (index >= 0) {
            results.add(index)
            index = text.indexOf(query, index + 1, ignoreCase = true)
        }
        return results
    }

    fun highlightAndScrollTo(start: Int, length: Int) {
        val et = editText ?: return
        et.setSelection(start, (start + length).coerceAtMost(et.text.length))
        et.requestFocus()
    }

    fun replaceRange(start: Int, end: Int, replacement: String) {
        recordSnapshot()
        currentContent().replace(start, end, replacement)
        isModified = true
        updateCounts()
    }

    /** Replaces every occurrence of [query] with [replacement]; returns the count replaced. */
    fun replaceAllOccurrences(query: String, replacement: String): Int {
        if (query.isEmpty()) return 0
        recordSnapshot()
        val editable = currentContent()
        var count = 0
        var searchFrom = 0
        while (true) {
            val text = editable.toString()
            val idx = text.indexOf(query, searchFrom, ignoreCase = true)
            if (idx < 0) break
            editable.replace(idx, idx + query.length, replacement)
            count++
            searchFrom = idx + replacement.length
        }
        if (count > 0) {
            isModified = true
            updateCounts()
        }
        return count
    }

    internal fun updateCounts() {
        val text = currentPlainText()
        wordCount = countWords(text)
        charCount = text.length
    }

    internal fun updateUndoRedoFlags() {
        canUndo = undoRedo.canUndo
        canRedo = undoRedo.canRedo
    }

    internal fun attach(editText: EditText) {
        this.editText = editText
        if (snapshotHandler == null) snapshotHandler = Handler(Looper.getMainLooper())

        editText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (suppressWatcher) return
                isModified = true
                updateCounts()
                onUserEdit?.invoke()
                scheduleDebouncedSnapshot()
            }
        })
    }

    private fun scheduleDebouncedSnapshot() {
        pendingSnapshot?.let { snapshotHandler?.removeCallbacks(it) }
        val runnable = Runnable {
            val et = editText ?: return@Runnable
            undoRedo.recordSnapshot(et.text)
            updateUndoRedoFlags()
        }
        pendingSnapshot = runnable
        snapshotHandler?.postDelayed(runnable, 900L)
    }

    fun detach() {
        pendingSnapshot?.let { snapshotHandler?.removeCallbacks(it) }
        snapshotHandler = null
        editText = null
    }
}

@Composable
fun rememberRichEditorController(): RichEditorController = remember { RichEditorController() }

/**
 * Hosts a classic [EditText] inside Compose. A real EditText is used (instead
 * of BasicTextField) because it has full native support for Arabic/RTL text
 * shaping, text selection handles, the system copy/cut/paste action bar, and
 * — critically — [android.text.Spannable] formatting (bold/italic/underline/
 * color/alignment), none of which Compose's text APIs expose per-range yet.
 */
@Composable
fun RichEditText(
    controller: RichEditorController,
    modifier: Modifier = Modifier,
    isRtl: Boolean,
    baseFontSizeSp: Int,
    hint: String
) {
    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = { context ->
            EditText(context).apply {
                setTextSize(TypedValue.COMPLEX_UNIT_SP, baseFontSizeSp.toFloat())
                background = null
                setPadding(32, 32, 32, 32)
                gravity = if (isRtl) android.view.Gravity.RIGHT or android.view.Gravity.TOP
                else android.view.Gravity.LEFT or android.view.Gravity.TOP
                textDirection = if (isRtl) View.TEXT_DIRECTION_RTL else View.TEXT_DIRECTION_LTR
                isSingleLine = false
                setHorizontallyScrolling(false)
                this.hint = hint
                imeOptions = android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI
                controller.attach(this)
            }
        },
        update = { editText ->
            editText.textDirection = if (isRtl) View.TEXT_DIRECTION_RTL else View.TEXT_DIRECTION_LTR
            editText.gravity = if (isRtl) android.view.Gravity.RIGHT or android.view.Gravity.TOP
            else android.view.Gravity.LEFT or android.view.Gravity.TOP
        }
    )
}
