package com.alwsabi.editor.data

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import android.text.Layout
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets

/**
 * Handles all real file I/O for the editor. Every operation runs on
 * [Dispatchers.IO], returns a [Result] instead of throwing, and never
 * crashes the app on a malformed or unreadable document — errors are
 * surfaced to the caller as a localized message to show the user.
 */
class FileRepository(private val context: Context) {

    private val resolver: ContentResolver get() = context.contentResolver

    /** Grants persistable read/write permission so the Uri survives app restarts. */
    fun takePersistablePermission(uri: Uri) {
        try {
            val flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
                android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            resolver.takePersistableUriPermission(uri, flags)
        } catch (_: SecurityException) {
            // Some providers do not support persistable permissions; the document
            // will still work for this session, it simply may not survive a restart.
        }
    }

    suspend fun readText(uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        try {
            val input = resolver.openInputStream(uri)
                ?: return@withContext Result.failure(IllegalStateException("cannot open input stream"))
            input.use { stream ->
                val reader = BufferedReader(InputStreamReader(stream, StandardCharsets.UTF_8))
                Result.success(reader.readText())
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun writeText(uri: Uri, content: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val output = resolver.openOutputStream(uri, "wt")
                ?: return@withContext Result.failure(IllegalStateException("cannot open output stream"))
            output.use { stream ->
                OutputStreamWriter(stream, StandardCharsets.UTF_8).use { writer ->
                    writer.write(content)
                    writer.flush()
                }
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun displayNameOf(uri: Uri): String =
        try {
            DocumentFile.fromSingleUri(context, uri)?.name ?: uri.lastPathSegment ?: "مستند"
        } catch (_: Exception) {
            uri.lastPathSegment ?: "مستند"
        }

    suspend fun renameDocument(uri: Uri, newName: String): Result<Uri> = withContext(Dispatchers.IO) {
        try {
            val newUri = DocumentsContract.renameDocument(resolver, uri, newName)
                ?: return@withContext Result.failure(IllegalStateException("provider returned no uri"))
            Result.success(newUri)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteDocument(uri: Uri): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val deleted = DocumentsContract.deleteDocument(resolver, uri)
            if (deleted) Result.success(Unit)
            else Result.failure(IllegalStateException("provider refused deletion"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Renders [content] (with all its formatting spans: bold, italic, underline,
     * colors, per-paragraph alignment) into a paginated PDF and writes it to [uri].
     * Uses only the platform's built-in android.graphics.pdf.PdfDocument — no
     * external PDF library — which keeps this feature stable across builds.
     */
    suspend fun exportToPdf(
        uri: Uri,
        content: Spanned,
        baseTextSizeSp: Float,
        isRtl: Boolean
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val density = context.resources.displayMetrics.density
            val pageWidthPx = (PDF_PAGE_WIDTH_DP * density).toInt()
            val pageHeightPx = (PDF_PAGE_HEIGHT_DP * density).toInt()
            val marginPx = (PDF_MARGIN_DP * density).toInt()
            val contentWidthPx = (pageWidthPx - 2 * marginPx).coerceAtLeast(1)
            val contentHeightPx = (pageHeightPx - 2 * marginPx).coerceAtLeast(1)

            val textPaint = TextPaint().apply {
                isAntiAlias = true
                color = Color.BLACK
                textSize = baseTextSizeSp * context.resources.displayMetrics.scaledDensity
            }

            val safeText = if (content.isEmpty()) " " else content

            val layout = StaticLayout.Builder
                .obtain(safeText, 0, safeText.length, textPaint, contentWidthPx)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setTextDirection(if (isRtl) TextDirectionHeuristics.RTL else TextDirectionHeuristics.LTR)
                .setLineSpacing(1.15f, 1f)
                .setIncludePad(false)
                .build()

            val pdfDocument = PdfDocument()
            var pageStartLine = 0
            var pageStartTop = if (layout.lineCount > 0) layout.getLineTop(0) else 0
            var pageNumber = 1

            fun emitPage(fromTop: Int) {
                val pageInfo = PdfDocument.PageInfo.Builder(pageWidthPx, pageHeightPx, pageNumber).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas
                canvas.save()
                canvas.translate(marginPx.toFloat(), (marginPx - fromTop).toFloat())
                layout.draw(canvas)
                canvas.restore()
                pdfDocument.finishPage(page)
                pageNumber++
            }

            if (layout.lineCount == 0) {
                emitPage(0)
            } else {
                for (line in 0 until layout.lineCount) {
                    val bottom = layout.getLineBottom(line)
                    if (bottom - pageStartTop > contentHeightPx && line > pageStartLine) {
                        emitPage(pageStartTop)
                        pageStartLine = line
                        pageStartTop = layout.getLineTop(line)
                    }
                }
                // Final page with whatever lines remain
                emitPage(pageStartTop)
            }

            val output = resolver.openOutputStream(uri, "wt")
                ?: return@withContext Result.failure(IllegalStateException("cannot open output stream"))
            output.use { pdfDocument.writeTo(it) }
            pdfDocument.close()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Renders every page of the PDF at [uri] into bitmaps for on-screen preview,
     * using the platform's built-in [PdfRenderer].
     */
    suspend fun renderPdfPages(uri: Uri): Result<List<Bitmap>> = withContext(Dispatchers.IO) {
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        try {
            pfd = resolver.openFileDescriptor(uri, "r")
                ?: return@withContext Result.failure(IllegalStateException("cannot open pdf"))
            renderer = PdfRenderer(pfd)
            val density = context.resources.displayMetrics.density
            val bitmaps = mutableListOf<Bitmap>()
            for (i in 0 until renderer.pageCount) {
                renderer.openPage(i).use { page ->
                    val width = (page.width * density).toInt().coerceAtLeast(1)
                    val height = (page.height * density).toInt().coerceAtLeast(1)
                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bitmaps.add(bitmap)
                }
            }
            Result.success(bitmaps)
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            try {
                renderer?.close()
            } catch (_: Exception) {
            }
            try {
                pfd?.close()
            } catch (_: Exception) {
            }
        }
    }

    companion object {
        private const val PDF_PAGE_WIDTH_DP = 595 // A4 at 72dpi-equivalent points
        private const val PDF_PAGE_HEIGHT_DP = 842
        private const val PDF_MARGIN_DP = 36
    }
}
