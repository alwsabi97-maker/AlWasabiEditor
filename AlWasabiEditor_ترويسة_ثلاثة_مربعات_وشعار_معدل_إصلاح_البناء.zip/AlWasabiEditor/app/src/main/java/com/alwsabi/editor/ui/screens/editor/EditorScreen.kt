package com.alwsabi.editor.ui.screens.editor

import android.net.Uri
import android.text.Layout
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Preview
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alwsabi.editor.R
import com.alwsabi.editor.data.model.AppSettings
import com.alwsabi.editor.data.model.TextDirectionSetting
import com.alwsabi.editor.ui.components.AppTopBar
import com.alwsabi.editor.ui.components.ColorPickerDialog
import com.alwsabi.editor.ui.components.ConfirmDialog
import com.alwsabi.editor.ui.components.DecorativePageBorder
import com.alwsabi.editor.ui.components.EditorToolbar
import com.alwsabi.editor.ui.components.ExamGeneratorDialog
import com.alwsabi.editor.ui.components.ExamHeaderBox
import com.alwsabi.editor.ui.components.ExamHeaderBoxes
import com.alwsabi.editor.ui.components.HeaderBoxEditDialog
import com.alwsabi.editor.ui.components.defaultExamHeaderBoxes
import com.alwsabi.editor.ui.components.TableInsertDialog
import com.alwsabi.editor.ui.components.TextInputDialog
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    documentUriToOpen: String?,
    appSettings: AppSettings,
    onNavigateBack: () -> Unit,
    editorViewModel: EditorViewModel = viewModel()
) {
    val context = LocalContext.current
    val uiState by editorViewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var controller by remember { mutableStateOf<RichEditorController?>(null) }
    var showMenu by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var showTextColorDialog by remember { mutableStateOf(false) }
    var showBgColorDialog by remember { mutableStateOf(false) }
    var capturedSelection by remember { mutableStateOf<SelectionRange?>(null) }
    var showExamDialog by remember { mutableStateOf(false) }
    var showTableDialog by remember { mutableStateOf(false) }
    var showPreviewDialog by remember { mutableStateOf(false) }
    var lastLoadedUri by remember { mutableStateOf<String?>(null) }
    var headerBoxes by remember { mutableStateOf(defaultExamHeaderBoxes()) }
    var editingHeaderBox by remember { mutableStateOf<ExamHeaderBox?>(null) }

    val headerPrefs = remember {
        context.getSharedPreferences("exam_header_boxes", android.content.Context.MODE_PRIVATE)
    }
    val headerKey = documentUriToOpen ?: "new_document"

    val isRtl = appSettings.textDirection == TextDirectionSetting.RTL

    editorViewModel.setAutoSaveEnabled(appSettings.autoSaveEnabled)

    LaunchedEffect(documentUriToOpen) {
        if (documentUriToOpen != null && documentUriToOpen != lastLoadedUri) {
            editorViewModel.openDocument(Uri.parse(documentUriToOpen))
            lastLoadedUri = documentUriToOpen
        } else if (documentUriToOpen == null && lastLoadedUri == null) {
            editorViewModel.startNewDocument()
        }
    }
    LaunchedEffect(headerKey) {
        val loaded = listOf("right", "middle", "left").mapNotNull { id ->
            val html = headerPrefs.getString("${headerKey}_$id", null) ?: return@mapNotNull null
            ExamHeaderBox(id, html)
        }
        headerBoxes = if (loaded.size == 3) loaded else defaultExamHeaderBoxes()
    }

    LaunchedEffect(uiState.statusMessage) {
        uiState.statusMessage?.let {
            snackbarHostState.showSnackbar(it)
            editorViewModel.consumeStatusMessage()
        }
    }

    LaunchedEffect(uiState.errorMessage) {
        uiState.errorMessage?.let {
            snackbarHostState.showSnackbar(it)
            editorViewModel.consumeErrorMessage()
        }
    }

    val createDocumentLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) editorViewModel.onSaveAsUriObtained(uri)
    }

    val shareLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val bitmap = android.graphics.BitmapFactory.decodeStream(stream)
                    if (bitmap != null) {
                        controller?.insertImage(bitmap, maxWidthPx = 800)
                    }
                }
            } catch (_: Exception) {
                scope.launch { snackbarHostState.showSnackbar("تعذر إدراج الصورة") }
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Column {
                AppTopBar(
                    title = uiState.fileName,
                    showBackButton = true,
                    onBackClick = {
                        if (uiState.hasUnsavedChanges) {
                            editorViewModel.requestExitConfirmation(true)
                        } else {
                            onNavigateBack()
                        }
                    },
                    actions = {
                        IconButton(onClick = { showPreviewDialog = true }) {
                            Icon(Icons.Default.Preview, contentDescription = "معاينة الورقة")
                        }
                        IconButton(onClick = { editorViewModel.toggleFindReplace(!uiState.showFindReplace) }) {
                            Icon(Icons.Default.Search, contentDescription = stringResource(R.string.editor_find))
                        }
                        IconButton(onClick = { editorViewModel.save() }) {
                            Icon(Icons.Default.Save, contentDescription = stringResource(R.string.editor_save))
                        }
                        IconButton(onClick = {
                            editorViewModel.shareCurrentDocument { intent ->
                                shareLauncher.launch(android.content.Intent.createChooser(intent, "مشاركة الملف"))
                            }
                        }) {
                            Icon(Icons.Default.Share, contentDescription = stringResource(R.string.editor_share))
                        }
                        IconButton(onClick = { showMenu = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = stringResource(R.string.general_menu))
                        }
                        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.editor_save_as)) },
                                onClick = {
                                    showMenu = false
                                    val name = uiState.fileName.ifBlank { "مستند جديد.txt" }
                                    createDocumentLauncher.launch(if (name.contains('.')) name else "$name.txt")
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.editor_rename)) },
                                leadingIcon = { Icon(Icons.Default.DriveFileRenameOutline, null) },
                                onClick = { showMenu = false; showRenameDialog = true }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.editor_delete)) },
                                leadingIcon = { Icon(Icons.Default.Delete, null) },
                                onClick = { showMenu = false; showDeleteDialog = true }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.editor_export_pdf)) },
                                leadingIcon = { Icon(Icons.Default.PictureAsPdf, null) },
                                onClick = {
                                    showMenu = false
                                    editorViewModel.exportToPdf(
                                        fontSizePx = appSettings.defaultFontSize.toFloat() * 1.3f,
                                        isRtl = isRtl,
                                        headerBoxes = headerBoxes.associate { it.id to it.html }
                                    ) { intent ->
                                        shareLauncher.launch(android.content.Intent.createChooser(intent, "مشاركة PDF"))
                                    }
                                }
                            )
                        }
                    }
                )
                if (uiState.showFindReplace) {
                    FindReplaceBar(
                        query = uiState.findQuery,
                        replacement = uiState.replaceQuery,
                        matchCount = uiState.findMatchCount,
                        onQueryChange = editorViewModel::updateFindQuery,
                        onReplacementChange = editorViewModel::updateReplaceQuery,
                        onReplaceAll = { controller?.let { editorViewModel.replaceAll(it) } },
                        onClose = { editorViewModel.toggleFindReplace(false) }
                    )
                }
            }
        },
        bottomBar = {
            Column {
                EditorToolbar(
                    canUndo = uiState.canUndo,
                    canRedo = uiState.canRedo,
                    onUndo = { controller?.let { editorViewModel.requestUndo(it) } },
                    onRedo = { controller?.let { editorViewModel.requestRedo(it) } },
                    onBold = { controller?.toggleBold() },
                    onItalic = { controller?.toggleItalic() },
                    onUnderline = { controller?.toggleUnderline() },
                    onAlignRight = { controller?.setAlignment(Layout.Alignment.ALIGN_NORMAL) },
                    onAlignCenter = { controller?.setAlignment(Layout.Alignment.ALIGN_CENTER) },
                    onAlignLeft = { controller?.setAlignment(Layout.Alignment.ALIGN_OPPOSITE) },
                    onTextColor = {
                        capturedSelection = controller?.currentSelection()
                        showTextColorDialog = true
                    },
                    onBackgroundColor = {
                        capturedSelection = controller?.currentSelection()
                        showBgColorDialog = true
                    },
                    onIncreaseFont = { controller?.setRelativeFontSize(1.15f) },
                    onDecreaseFont = { controller?.setRelativeFontSize(0.87f) },
                    onInsertExam = { showExamDialog = true },
                    onInsertTable = { showTableDialog = true },
                    onInsertImage = { imagePickerLauncher.launch("image/*") },
                    onLetterhead = {
                        val defaults = defaultExamHeaderBoxes()
                        headerBoxes = defaults
                        defaults.forEach { box ->
                            headerPrefs.edit().putString("${headerKey}_${box.id}", box.html).apply()
                        }
                        scope.launch { snackbarHostState.showSnackbar("تم تجهيز مربعات ترويسة الاختبار الثلاثة") }
                    }
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${stringResource(R.string.editor_word_count)}: ${uiState.wordCount}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "${stringResource(R.string.editor_char_count)}: ${uiState.charCount}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (uiState.isLoading) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator()
                }
            } else {
                androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize()) {
                    DecorativePageBorder(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
                    )

                    ExamHeaderBoxes(
                        boxes = headerBoxes,
                        onEdit = { editingHeaderBox = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 20.dp, end = 20.dp, top = 20.dp)
                    )

                    RichTextEditorView(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(start = 20.dp, end = 20.dp, top = 178.dp, bottom = 20.dp),
                        initialText = editorViewModel.currentTextSnapshot(),
                        isRtl = isRtl,
                        baseFontSizeSp = appSettings.defaultFontSize.toFloat(),
                        baseFontFamily = appSettings.fontFamily,
                        onTextChanged = { editable -> editorViewModel.onTextChanged(editable) },
                        onSelectionChanged = { _, _ -> },
                        onControllerReady = { controller = it }
                    )
                }
            }
        }
    }

    if (uiState.pendingExitConfirmation) {
        ConfirmDialog(
            title = stringResource(R.string.editor_unsaved_changes_title),
            message = stringResource(R.string.editor_unsaved_changes_message),
            confirmLabel = stringResource(R.string.editor_save),
            dismissLabel = stringResource(R.string.editor_discard),
            onConfirm = {
                editorViewModel.requestExitConfirmation(false)
                editorViewModel.save()
                onNavigateBack()
            },
            onDismiss = {
                editorViewModel.requestExitConfirmation(false)
                onNavigateBack()
            }
        )
    }

    if (showRenameDialog) {
        TextInputDialog(
            title = stringResource(R.string.editor_rename),
            label = stringResource(R.string.editor_rename_hint),
            initialValue = uiState.fileName,
            confirmLabel = stringResource(R.string.editor_confirm),
            dismissLabel = stringResource(R.string.editor_cancel),
            onConfirm = {
                editorViewModel.renameCurrentDocument(it)
                showRenameDialog = false
            },
            onDismiss = { showRenameDialog = false }
        )
    }

    if (showDeleteDialog) {
        ConfirmDialog(
            title = stringResource(R.string.editor_delete_confirm_title),
            message = stringResource(R.string.editor_delete_confirm_message),
            confirmLabel = stringResource(R.string.editor_delete),
            dismissLabel = stringResource(R.string.editor_cancel),
            onConfirm = {
                showDeleteDialog = false
                editorViewModel.deleteCurrentDocument { onNavigateBack() }
            },
            onDismiss = { showDeleteDialog = false }
        )
    }

    if (showTextColorDialog) {
        ColorPickerDialog(
            title = stringResource(R.string.editor_text_color),
            onColorSelected = { color ->
                val sel = capturedSelection
                if (sel != null && sel.start != sel.end) {
                    controller?.setTextColor(color, sel)
                } else {
                    scope.launch { snackbarHostState.showSnackbar("حدّد نصًا أولاً قبل اختيار اللون") }
                }
                showTextColorDialog = false
            },
            onDismiss = { showTextColorDialog = false }
        )
    }

    if (showBgColorDialog) {
        ColorPickerDialog(
            title = stringResource(R.string.editor_bg_color),
            onColorSelected = { color ->
                val sel = capturedSelection
                if (sel != null && sel.start != sel.end) {
                    controller?.setBackgroundColor(color, sel)
                } else {
                    scope.launch { snackbarHostState.showSnackbar("حدّد نصًا أولاً قبل اختيار اللون") }
                }
                showBgColorDialog = false
            },
            onDismiss = { showBgColorDialog = false }
        )
    }

    if (showExamDialog) {
        ExamGeneratorDialog(
            onDismiss = { showExamDialog = false },
            onInsertSequence = { ops ->
                ops.forEach { op ->
                    when (op) {
                        is com.alwsabi.editor.ui.components.ExamInsertOp.Txt ->
                            controller?.insertTextAtCursor(op.text)
                        is com.alwsabi.editor.ui.components.ExamInsertOp.Img -> {
                            try {
                                context.contentResolver.openInputStream(op.uri)?.use { stream ->
                                    val bitmap = android.graphics.BitmapFactory.decodeStream(stream)
                                    if (bitmap != null) controller?.insertImage(bitmap, maxWidthPx = op.maxWidthPx)
                                }
                            } catch (_: Exception) {
                                // نتجاهل صورة واحدة فشلت بدل تعطيل بقية الإدراج
                            }
                        }
                    }
                }
                showExamDialog = false
            }
        )
    }

    if (showTableDialog) {
        TableInsertDialog(
            onDismiss = { showTableDialog = false },
            onInsert = { rows, cols ->
                controller?.insertTable(rows, cols)
                showTableDialog = false
            }
        )
    }

    if (showPreviewDialog) {
        com.alwsabi.editor.ui.components.DocumentPreviewDialog(
            content = editorViewModel.currentTextSnapshot().toString(),
            isRtl = isRtl,
            onDismiss = { showPreviewDialog = false }
        )
    }

    editingHeaderBox?.let { box ->
        HeaderBoxEditDialog(
            box = box,
            onDismiss = { editingHeaderBox = null },
            onSave = { updated ->
                headerBoxes = headerBoxes.map { if (it.id == updated.id) updated else it }
                headerPrefs.edit().putString("${headerKey}_${updated.id}", updated.html).apply()
                editingHeaderBox = null
                scope.launch { snackbarHostState.showSnackbar("تم حفظ مربع الترويسة") }
            }
        )
    }
}

@Composable
private fun FindReplaceBar(
    query: String,
    replacement: String,
    matchCount: Int,
    onQueryChange: (String) -> Unit,
    onReplacementChange: (String) -> Unit,
    onReplaceAll: () -> Unit,
    onClose: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier.weight(1f),
                label = { Text(stringResource(R.string.editor_find_hint)) },
                singleLine = true
            )
            IconButton(onClick = onClose) {
                Text("✕")
            }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = replacement,
                onValueChange = onReplacementChange,
                modifier = Modifier.weight(1f),
                label = { Text(stringResource(R.string.editor_replace_hint)) },
                singleLine = true
            )
            TextButton(onClick = onReplaceAll) {
                Text(stringResource(R.string.editor_replace_all))
            }
        }
        val matchText = if (query.isEmpty()) "" else if (matchCount == 0) stringResource(R.string.editor_no_matches) else String.format(stringResource(R.string.editor_matches_found), matchCount)
        if (matchText.isNotEmpty()) {
            Text(matchText, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Start)
        }
    }
}

